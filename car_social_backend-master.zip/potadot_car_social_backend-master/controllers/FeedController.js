const PostService = require('../services/FeedService');

module.exports = {
  getList: async (req, res) => {
    const data = {
      userId: req.user.userId,
      page: req.query.page,
    };

    const result = await PostService.getPostList(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },

  create: async (req, res) => {
    const data = {
      userId: req.user.userId,
      message: req.body.message,
      files: req.files.media,
    };

    const result = await PostService.createPost(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },

  delete: async (req, res) => {
    const data = {
      id: req.params.id,
    };

    const result = await PostService.deletePost(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },

  update: async (req, res) => {
    const data = {
      id: req.params.id,
      message: req.body.message,
    };

    const result = await PostService.updatePost(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },

  like: async (req, res) => {
    const data = {
      postId: req.params.id,
      userId: req.user.userId,
    };

    const result = await PostService.likePost(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },

  unlike: async (req, res) => {
    const data = {
      postId: req.params.id,
      userId: req.user.userId,
    };

    const result = await PostService.unlikePost(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },

  getSinglePost: async (req, res) => {
    const data = {
      userId: req.user.userId,
      id: req.params.id,
    };

    const result = await PostService.getSinglePost(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },

  getCommentList: async (req, res) => {
    const data = {
      postId: req.params.id,
      page: req.query.page,
    };
    const result = await PostService.getCommentList(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },

  createComment: async (req, res) => {
    const data = {
      userId: req.user.userId,
      postId: req.params.id,
      content: req.body.content,
    };
    const result = await PostService.createComment(data);
    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },

  getFollowedUserPostList: async (req, res) => {
    const data = {
      userId: req.user.userId,
      page: req.query.page,
    };
    const result = await PostService.getFollowedUserPostList(data);
    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },

  getSavedPostList: async (req, res) => {
    const data = {
      userId: req.user.userId,
      page: req.query.page,
    };

    const result = await PostService.getSavedPostList(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },

  save: async (req, res) => {
    const data = {
      postId: req.params.id,
      userId: req.user.userId,
    };

    const result = await PostService.savePost(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },

  unsave: async (req, res) => {
    const data = {
      postId: req.params.id,
      userId: req.user.userId,
    };

    const result = await PostService.unsavePost(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },
};
