const EventService = require('../services/EventService');

module.exports = {
  create: async (req, res) => {
    const data = {
      title: req.body.title,
      description: req.body.description,
      location: req.body.location,
      start_date: req.body.start_date,
      end_date: req.body.end_date,
      cover_photo: null,
      userId: req.user.userId,
    };

    if (req.files != null) {
      data.cover_photo = req.files.cover_photo;
    }

    const result = await EventService.createEvent(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },

  getMyEventList: async (req, res) => {
    const data = {
      userId: req.user.userId,
      page: req.query.page,
    };

    const result = await EventService.getMyEventList(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },

  getSingleEvent: async (req, res) => {
    const data = {
      id: req.params.id,
      userId: req.user.userId,
    };

    const result = await EventService.getSingleEvent(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },

  getNearMeEventList: async (req, res) => {
    const data = {
      userId: req.user.userId,
      page: req.query.page,
    };

    const result = await EventService.getNearMeEventList(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },
};
