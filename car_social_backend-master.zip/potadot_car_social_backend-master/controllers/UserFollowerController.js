const UserFollowerService = require('../services/UserFollowerService');

module.exports = {
  getFollowerList: async (req, res) => {
    const data = {
      userId: req.user.userId,
      page: req.query.page,
    };

    const result = await UserFollowerService.getFollowerList(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },
  getFollowingList: async (req, res) => {
    const data = {
      userId: req.user.userId,
      page: req.query.page,
    };
    const result = await UserFollowerService.getFollowingList(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },
};
