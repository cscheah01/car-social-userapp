const UserGarageService = require('../services/UserGarageService');

module.exports = {
  create: async (req, res) => {
    const data = {
      userId: req.user.userId,
      carModelId: req.body.car_model_id,
      carYear: req.body.year,
      image: req.files.image,
    };

    const result = await UserGarageService.createVehicle(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },

  update: async (req, res) => {
    const data = {
      id: req.params.id,
      carModelId: req.body.car_model_id,
      image: req.files.image,
    };

    const result = await UserGarageService.updateVehicle(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },

  getList: async (req, res) => {
    const data = {
      userId: req.user.userId,
      page: req.query.page,
    };

    const result = await UserGarageService.getUserGarageList(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },
};
