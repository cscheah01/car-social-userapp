const ProfileService = require('../services/ProfileService');

module.exports = {
  getProfileDetails: async (req, res) => {
    const data = {
      id: req.user.userId,
    };

    const result = await ProfileService.getProfileDetails(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },

  update: async (req, res) => {
    const data = {
      id: req.user.userId,
      username: req.body.username ?? null,
      email: req.body.email ?? null,
      phone_no: req.body.phone_no ?? null,
      dob: req.body.dob ?? null,
      bio: req.body.bio ?? null,
      profile_image: null,
      background_image: null,
    };

    if (req.files != null) {
      if (req.files.profile_image != null) {
        data.profile_image = req.files.profile_image;
      } else if (req.files.background_image != null) {
        data.background_image = req.files.background_image;
      }
    }
    const result = await ProfileService.update(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },
};
