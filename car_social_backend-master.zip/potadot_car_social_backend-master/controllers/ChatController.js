const ChatService = require('../services/ChatService');

module.exports = {
  getChatList: async (req, res) => {
    const data = {
      userId: req.user.userId,
      page: req.query.page,
    };

    const result = await ChatService.getChatList(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },
  getChatContent: async (req, res) => {
    const data = {
      chatSessionId: req.params.chatSessionId,
      userId: req.user.userId,
      page: req.query.page,
    };

    const result = await ChatService.getChatContent(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },
  create: async (req, res) => {
    const data = {
      userId: req.user.userId,
      chatSessionId: req.params.chatSessionId,
      content: req.body.content,
    };

    const result = await ChatService.createChatMessage(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },
  getChatUser: async (req, res) => {
    const data = {
      id: req.user.userId,
      username: req.query.username,
    };
    const result = await ChatService.getChatUser(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },

  getChatSession: async (req, res) => {
    const data = {
      userId: req.user.userId,
      receiverUserId: req.query.receiverUserId,
    };

    const result = await ChatService.getChatSession(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },
};
