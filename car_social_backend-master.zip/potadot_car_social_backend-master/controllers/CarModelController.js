const CarModelService = require('../services/CarModelService');

module.exports = {
  getCarModelList: async (req, res) => {
    const data = {
      carBrandId: req.params.carBrandId,
    };

    const result = await CarModelService.getCarModelList(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },
};
