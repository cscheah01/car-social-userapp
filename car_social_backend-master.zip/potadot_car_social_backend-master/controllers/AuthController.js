const AuthService = require('../services/AuthService');

module.exports = {
  login: async (req, res) => {
    const result = await AuthService.login(req.body);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },

  register: async (req, res) => {
    const result = await AuthService.register(req.body);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },
};
