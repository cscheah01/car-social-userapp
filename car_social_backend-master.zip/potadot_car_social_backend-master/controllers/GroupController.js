const GroupService = require('../services/GroupService');

module.exports = {
  create: async (req, res) => {
    const data = {
      description: req.body.description,
      country: req.body.country,
      name: req.body.name,
      is_private: req.body.is_private,
      group_image: null,
      background_image: null,
      userId: req.user.userId,
    };

    if (req.files != null) {
      if (req.files.group_image != null) {
        data.group_image = req.files.group_image;
      } else if (req.files.background_image != null) {
        data.background_image = req.files.background_image;
      }
    }

    const result = await GroupService.createGroup(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },

  getMyGroupList: async (req, res) => {
    const data = {
      userId: req.user.userId,
      page: req.query.page,
    };

    const result = await GroupService.getMyGroupList(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },

  getNearMeGroupList: async (req, res) => {
    const data = {
      userId: req.user.userId,
      page: req.query.page,
    };

    const result = await GroupService.getNearMeGroupList(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },

  getSingleGroup: async (req, res) => {
    const data = {
      id: req.params.id,
      userId: req.user.userId,
    };

    const result = await GroupService.getSingleGroup(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },

  delete: async (req, res) => {
    const data = {
      id: req.params.id,
    };

    const result = await GroupService.deleteGroup(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },

  getMemberRequestList: async (req, res) => {
    const data = {
      groupId: req.params.groupId,
      page: req.query.page,
    };

    const result = await GroupService.getMemberRequestList(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },

  acceptRequest: async (req, res) => {
    const data = {
      updatedBy: req.user.userId,
      groupId: req.query.groupId,
      userId: req.params.userId,
      isApproved: true,
      isWaiting: false,
    };

    const result = await GroupService.acceptRequest(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },

  declineRequest: async (req, res) => {
    const data = {
      updatedBy: req.user.userId,
      groupId: req.query.groupId,
      userId: req.params.userId,
      isApproved: false,
      isWaiting: false,
    };

    const result = await GroupService.declineRequest(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },
  getGroupSettingDetails: async (req, res) => {
    const data = {
      id: req.params.id,
    };

    const result = await GroupService.getGroupSettingDetails(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },
  update: async (req, res) => {
    const data = {
      id: req.params.id,
      name: req.body.name ?? null,
      description: req.body.description ?? null,
      country: req.body.country ?? null,
      is_private: req.body.is_private ?? null,
      group_image: null,
      background_image: null,
    };

    if (req.files != null) {
      if (req.files.group_image != null) {
        data.group_image = req.files.group_image;
      } else if (req.files.background_image != null) {
        data.background_image = req.files.background_image;
      }
    }
    const result = await GroupService.update(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },
  getTotalMemberRequest: async (req, res) => {
    const data = {
      groupId: req.params.groupId,
    };

    const result = await GroupService.getTotalMemberRequest(data);

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },
};
