const CarBrandService = require('../services/CarBrandService');

module.exports = {
  getCarBrandList: async (req, res) => {
    const result = await CarBrandService.getCarBrandList();

    if (result.error) {
      return res.status(500).send(result);
    } else {
      return res.send(result);
    }
  },
};
