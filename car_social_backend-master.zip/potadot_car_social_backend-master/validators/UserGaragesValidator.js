const {} = require('express');
const { body, param, validationResult } = require('express-validator');

module.exports = {
  create: [
    body('car_model_id')
      .notEmpty()
      .withMessage('Car model id is required.')
      .bail(),
    body('year').notEmpty().withMessage('Car year is required.').bail(),
  ],

  edit: [
    param('id').notEmpty().withMessage('Garage id is required.'),
    body('car_model_id')
      .notEmpty()
      .withMessage('Car model id is required.')
      .bail(),
  ],

  result: (req, res, next) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
      return res.status(422).json({ success: false, error: errors.array() });
    }
    next();
  },
};
