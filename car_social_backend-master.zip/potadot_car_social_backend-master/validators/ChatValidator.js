const {} = require('express');
const { body, param, validationResult } = require('express-validator');

module.exports = {
  create: [
    param('chatSessionId')
      .notEmpty()
      .withMessage('Chat session id is required.'),
    body('content')
      .notEmpty()
      .withMessage('Content is required.')
      .bail()
      .isLength({ max: 65535 })
      .withMessage('Content length must less than 65535.'),
  ],

  result: (req, res, next) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
      return res.status(422).json({ success: false, error: errors.array() });
    }
    next();
  },
};
