const { body, param, validationResult } = require('express-validator');
const moment = require('moment');
const User = require('../models/UserModel');
const { pool } = require('../db');

module.exports = {
  update: [
    body('username')
      .optional({ nullable: true })
      .isLength({ max: 24 })
      .withMessage('Username length must less than 24.')
      .bail()
      .custom(async (val) => {
        const connection = await pool.getConnection();
        try {
          let user = await User.getByUsername(connection, val);

          if (user) {
            throw new Error('Username is already in use.');
          }
        } finally {
          connection.release();
        }
      })
      .bail(),
    body('email')
      .optional({ nullable: true })
      .isEmail()
      .withMessage('Invalid email format.')
      .bail(),
    body('phone_no')
      .optional({ nullable: true })
      .isMobilePhone()
      .withMessage('Invalid phone number format.')
      .bail()
      .custom(async (val) => {
        const connection = await pool.getConnection();
        try {
          let user = await User.getByPhoneNumber(connection, val);
          if (user) {
            throw new Error('Phone number is already in use.');
          }
        } finally {
          connection.release();
        }
      })
      .bail(),

    body('dob')
      .optional({ nullable: true })
      .custom(async (dob, { req }) => {
        if (!moment(dob).isValid()) {
          throw new Error('Invalid date format.');
        }
      })
      .bail(),

    body('bio')
      .optional({ nullable: true })
      .isLength({ max: 255 })
      .withMessage('bio length must less than 255.')
      .bail(),
  ],
  result: (req, res, next) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
      return res.status(422).json({ success: false, error: errors.array() });
    }
    next();
  },
};
