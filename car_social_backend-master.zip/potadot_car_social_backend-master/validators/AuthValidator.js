const { body, validationResult } = require('express-validator');
const moment = require('moment');
const User = require('../models/UserModel');
const { pool } = require('../db');

module.exports = {
  login: [
    body('email').notEmpty().withMessage('Email is required.').bail(),

    body('password').notEmpty().withMessage('Password is required.').bail(),
  ],

  register: [
    body('email')
      .notEmpty()
      .withMessage('Email is required.')
      .bail()
      .isEmail()
      .withMessage('Invalid email format.')
      .bail()
      .custom(async (val) => {
        const connection = await pool.getConnection();
        try {
          let user = await User.getByEmail(connection, val);
          if (user) {
            throw new Error('Email is already in use.');
          }
        } finally {
          connection.release();
        }
      })
      .bail(),

    body('username')
      .notEmpty()
      .withMessage('Username is required.')
      .bail()
      .custom(async (val) => {
        const connection = await pool.getConnection();
        try {
          let user = await User.getByUsername(connection, val);
          if (user) {
            throw new Error('Username is already in use.');
          }
        } catch {
          throw new Error('Fail to validate username.');
        } finally {
          connection.release();
        }
      })
      .bail(),

    body('password')
      .notEmpty()
      .withMessage('Password is required.')
      .bail()
      .isLength({ min: 8 })
      .withMessage('At least 8 characters is required.'),
    body('country').notEmpty().withMessage('Country is required.').bail(),
    body('dob')
      .notEmpty()
      .withMessage('Birthday is required.')
      .bail()
      .custom(async (dob, { req }) => {
        if (!moment(dob).isValid()) {
          throw new Error('Invalid date format.');
        }
      }),

    body('phone_no')
      .notEmpty()
      .withMessage('Phone number is required.')
      .bail()
      .isMobilePhone()
      .withMessage('Invalid phone number format.')
      .bail()
      .custom(async (val) => {
        const connection = await pool.getConnection();
        try {
          let user = await User.getByPhoneNumber(connection, val);
          if (user) {
            throw new Error('Phone number is already in use.');
          }
        } catch {
          throw new Error('Fail to validate phone number.');
        } finally {
          connection.release();
        }
      })
      .bail(),

    body('confirm_password')
      .custom(async (confirm_password, { req }) => {
        const password = req.body.password;
        if (password !== confirm_password) {
          throw new Error('Password not match.');
        }
      })
      .bail(),
  ],

  result: (req, res, next) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
      return res.status(422).json({ success: false, error: errors.array() });
    }
    next();
  },
};
