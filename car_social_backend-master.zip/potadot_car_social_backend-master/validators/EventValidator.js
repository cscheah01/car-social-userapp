const {} = require('express');
const { body, validationResult } = require('express-validator');
const moment = require('moment');
const Event = require('../models/EventModel');
const { pool } = require('../db');

module.exports = {
  create: [
    body('title')
      .notEmpty()
      .withMessage('Title is required.')
      .bail()
      .isLength({ max: 255 })
      .withMessage('Title length must less than 255.')
      .bail()
      .custom(async (val) => {
        const connection = await pool.getConnection();
        try {
          let event = await Event.getByTitle(connection, val);
          if (event) {
            throw new Error('Event title is already in use.');
          }
        } finally {
          connection.release();
        }
      })
      .bail(),
    body('description')
      .optional({ nullable: true })
      .isLength({ max: 255 })
      .withMessage('Description length must less than 255.'),
    body('location').notEmpty().withMessage('Location is required.').bail(),
    body('start_date')
      .notEmpty()
      .withMessage('Start date is required.')
      .bail()
      .custom(async (dob, { req }) => {
        if (!moment(dob).isValid()) {
          throw new Error('Invalid date format.');
        }
      }),
    body('end_date')
      .notEmpty()
      .withMessage('End date is required.')
      .bail()
      .custom(async (dob, { req }) => {
        if (!moment(dob).isValid()) {
          throw new Error('Invalid date format.');
        }
      }),
  ],

  result: (req, res, next) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
      return res.status(422).json({ success: false, error: errors.array() });
    }
    next();
  },
};
