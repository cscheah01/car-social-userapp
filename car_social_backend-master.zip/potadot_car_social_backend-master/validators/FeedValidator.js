const {} = require('express');
const { body, param, validationResult } = require('express-validator');
const Post = require('../models/PostModel');
const { pool } = require('../db');

module.exports = {
  create: [
    body('message')
      .notEmpty()
      .withMessage('Message is required.')
      .bail()
      .isLength({ max: 255 })
      .withMessage('Message length must less than 255.'),
  ],

  edit: [
    param('id')
      .notEmpty()
      .withMessage('Post id is required.')
      .bail()
      .custom(async (val, { req }) => {
        const connection = await pool.getConnection();
        try {
          let post = await Post.getById(connection, val);

          if (post.user_id != req.user.userId) {
            throw new Error('This post is not belong to you.');
          }
        } finally {
          connection.release();
        }
      })
      .bail(),
    body('message')
      .notEmpty()
      .withMessage('Message is required.')
      .bail()
      .isLength({ max: 255 })
      .withMessage('Message length must less than 255.'),
  ],

  result: (req, res, next) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
      return res.status(422).json({ success: false, error: errors.array() });
    }
    next();
  },
};
