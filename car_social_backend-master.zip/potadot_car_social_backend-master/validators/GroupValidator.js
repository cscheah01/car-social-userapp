const {} = require('express');
const { body, validationResult } = require('express-validator');
const Group = require('../models/GroupModel');
const { pool } = require('../db');

module.exports = {
  create: [
    body('description')
      .optional({ nullable: true })
      .isLength({ max: 255 })
      .withMessage('Description length must less than 255.'),
    body('country').notEmpty().withMessage('Country is required.').bail(),
    body('name')
      .notEmpty()
      .withMessage('Name is required.')
      .bail()
      .isLength({ max: 255 })
      .withMessage('Message length must less than 255.')
      .bail()
      .custom(async (val) => {
        const connection = await pool.getConnection();
        try {
          let group = await Group.getByName(connection, val);
          if (group) {
            throw new Error('Group name is already in use.');
          }
        } finally {
          connection.release();
        }
      })
      .bail(),
    body('is_private')
      .notEmpty()
      .withMessage('Privacy is required.')
      .bail()
      .trim()
      .isBoolean()
      .withMessage('Privacy must be a boolean true or false'),
  ],

  update: [
    body('description')
      .optional({ nullable: true })
      .isLength({ max: 255 })
      .withMessage('Description length must less than 255.'),
    body('country')
      .optional({ nullable: true })
      .notEmpty()
      .withMessage('Country is required.')
      .bail(),
    body('name')
      .optional({ nullable: true })
      .notEmpty()
      .withMessage('Name is required.')
      .bail()
      .isLength({ max: 255 })
      .withMessage('Message length must less than 255.')
      .bail()
      .custom(async (val) => {
        const connection = await pool.getConnection();
        try {
          let group = await Group.getByName(connection, val);

          if (group) {
            throw new Error('Group name is already in use.');
          }
        } finally {
          connection.release();
        }
      })
      .bail(),
    body('is_private')
      .optional({ nullable: true })
      .notEmpty()
      .withMessage('Privacy is required.')
      .bail()
      .trim()
      .isBoolean()
      .withMessage('Privacy must be a boolean true or false'),
  ],

  result: (req, res, next) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
      return res.status(422).json({ success: false, error: errors.array() });
    }
    next();
  },
};
