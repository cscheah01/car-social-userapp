'use strict';

var dbm;
var type;
var seed;

/**
 * We receive the dbmigrate dependency from dbmigrate initially.
 * This enables us to not have to rely on NODE_PATH.
 */
exports.setup = function (options, seedLink) {
  dbm = options.dbmigrate;
  type = dbm.dataType;
  seed = seedLink;
};

exports.up = function (db, callback) {
  db.createTable(
    'events',
    {
      id: {
        type: 'int',
        unsigned: true,
        notNull: true,
        primaryKey: true,
        autoIncrement: true,
      },
      cover_image: {
        type: 'string',
        length: 255,
      },
      title: {
        type: 'string',
        length: 255,
        notNull: true,
      },
      description: {
        type: 'string',
        length: 255,
      },
      location: {
        type: 'string',
        length: 255,
        notNull: true,
      },
      start_date: {
        type: 'timestamp',
        defaultValue: 'CURRENT_TIMESTAMP',
      },
      end_date: {
        type: 'timestamp',
        defaultValue: 'CURRENT_TIMESTAMP',
      },
      created_at: {
        type: 'timestamp',
        defaultValue: 'CURRENT_TIMESTAMP',
      },
      updated_at: {
        type: 'timestamp',
        defaultValue: 'CURRENT_TIMESTAMP',
      },
    },
    function (err) {
      if (err) return callback(err);
      return callback();
    }
  );
};

exports.down = function (db, callback) {
  db.dropTable('events', callback);
};

exports._meta = {
  version: 1,
};
