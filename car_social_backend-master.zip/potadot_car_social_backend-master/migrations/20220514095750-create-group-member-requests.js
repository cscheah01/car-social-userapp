'use strict';

var dbm;
var type;
var seed;

/**
 * We receive the dbmigrate dependency from dbmigrate initially.
 * This enables us to not have to rely on NODE_PATH.
 */
exports.setup = function (options, seedLink) {
  dbm = options.dbmigrate;
  type = dbm.dataType;
  seed = seedLink;
};

exports.up = function (db, callback) {
  db.createTable(
    'group_member_requests',
    {
      id: {
        type: 'int',
        unsigned: true,
        notNull: true,
        primaryKey: true,
        autoIncrement: true,
      },
      group_id: {
        type: 'int',
        unsigned: true,
        notNull: true,
        foreignKey: {
          name: 'group_member_requests_group_id_foreign',
          table: 'groups',
          rules: {
            onDelete: 'CASCADE',
            onUpdate: 'RESTRICT',
          },
          mapping: 'id',
        },
      },
      user_id: {
        type: 'int',
        unsigned: true,
        notNull: true,
        foreignKey: {
          name: 'group_member_requests_user_id_foreign',
          table: 'users',
          rules: {
            onDelete: 'CASCADE',
            onUpdate: 'RESTRICT',
          },
          mapping: 'id',
        },
      },
      is_waiting: {
        type: 'boolean',
        notNull: true,
      },
      is_approved: {
        type: 'boolean',
        notNull: true,
      },
      updated_by: {
        type: 'int',
        unsigned: true,
        foreignKey: {
          name: 'group_member_requests_updated_by_foreign',
          table: 'users',
          rules: {
            onDelete: 'CASCADE',
            onUpdate: 'RESTRICT',
          },
          mapping: 'id',
        },
      },
      created_at: {
        type: 'timestamp',
        defaultValue: 'CURRENT_TIMESTAMP',
      },
      updated_at: {
        type: 'timestamp',
        defaultValue: 'CURRENT_TIMESTAMP',
      },
    },
    function (err) {
      if (err) return callback(err);
      return callback();
    }
  );
};

exports.down = function (db, callback) {
  db.dropTable('group_member_requests', callback);
};

exports._meta = {
  version: 1,
};
