'use strict';

var dbm;
var type;
var seed;

/**
 * We receive the dbmigrate dependency from dbmigrate initially.
 * This enables us to not have to rely on NODE_PATH.
 */
exports.setup = function (options, seedLink) {
  dbm = options.dbmigrate;
  type = dbm.dataType;
  seed = seedLink;
};

exports.up = function (db, callback) {
  db.createTable(
    'user_garages',
    {
      id: {
        type: 'int',
        unsigned: true,
        notNull: true,
        primaryKey: true,
        autoIncrement: true,
      },
      user_id: {
        type: 'int',
        unsigned: true,
        notNull: true,
        foreignKey: {
          name: 'user_garages_user_id_foreign',
          table: 'users',
          rules: {
            onDelete: 'CASCADE',
            onUpdate: 'RESTRICT',
          },
          mapping: 'id',
        },
      },
      car_model_id: {
        type: 'int',
        unsigned: true,
        notNull: true,
        foreignKey: {
          name: 'user_garages_car_model_id_foreign',
          table: 'car_brand_models',
          rules: {
            onDelete: 'CASCADE',
            onUpdate: 'RESTRICT',
          },
          mapping: 'id',
        },
      },
      image: {
        type: 'string',
        length: 255,
        notNull: true,
      },
      year: {
        type: 'year',
      },
      created_at: {
        type: 'timestamp',
        defaultValue: 'CURRENT_TIMESTAMP',
      },
      updated_at: {
        type: 'timestamp',
        defaultValue: 'CURRENT_TIMESTAMP',
      },
    },
    function (err) {
      if (err) return callback(err);
      return callback();
    }
  );
};

exports.down = function (db, callback) {
  db.dropTable('user_garages', callback);
};

exports._meta = {
  version: 1,
};
