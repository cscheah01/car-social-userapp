const CarModel = require('../models/CarModelModel');
const { pool } = require('../db');

module.exports = {
  getCarModelList: async (data) => {
    const connection = await pool.getConnection();
    try {
      const carModels = await CarModel.getAllByCarBrandId(
        connection,
        data.carBrandId
      );
      return { success: true, data: carModels };
    } catch (error) {
      return { error: true, message: 'Fail to get car model list.' };
    } finally {
      connection.release();
    }
  },
};
