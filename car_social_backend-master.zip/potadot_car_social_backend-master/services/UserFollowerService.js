const UserFollower = require('../models/UserFollowerModel');

module.exports = {
  getFollowerList: async (data) => {
    const connection = await pool.getConnection();
    try {
      data.limit = 10;
      data.offset = ((data.page ?? 1) - 1) * data.limit;

      let followers = await UserFollower.getFollowerList(connection, data);

      let followerList = [];
      followers.forEach((follower) => {
        followerList.push({
          id: follower.id,
          username: follower.username,
          bio: follower.bio,
          profile_image:
            process.env.APP_URL + '/' + follower.profile_image ?? null,
          profile_image_name: follower.profile_image,
        });
      });
      return { success: true, data: followerList };
    } catch (error) {
      return { error: true, message: 'Fail to get follower list.' };
    } finally {
      connection.release();
    }
  },
  getFollowingList: async (data) => {
    const connection = await pool.getConnection();
    try {
      data.limit = 10;
      data.offset = ((data.page ?? 1) - 1) * data.limit;

      let followings = await UserFollower.getFollowingList(connection, data);

      let followingList = [];
      followings.forEach((following) => {
        followingList.push({
          id: following.id,
          username: following.username,
          bio: following.bio,
          profile_image:
            process.env.APP_URL + '/' + following.profile_image ?? null,
          profile_image_name: following.profile_image,
        });
      });
      return { success: true, data: followingList };
    } catch (error) {
      return { error: true, message: 'Fail to get following list.' };
    } finally {
      connection.release();
    }
  },
};
