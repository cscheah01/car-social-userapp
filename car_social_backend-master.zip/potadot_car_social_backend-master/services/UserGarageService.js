const UserGarage = require('../models/UserGarageModel');
const fs = require('fs');
const path = require('path');
const { pool } = require('../db');

module.exports = {
  createVehicle: async (data) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();
      var garageDir = path.dirname(__dirname) + '/storage/garage';

      if (!fs.existsSync(garageDir)) {
        fs.mkdirSync(garageDir);
      }
      data.image.mv(
        path.dirname(__dirname) + '/storage/garage/' + data.image.name
      );

      let garage = await UserGarage.insert(connection, data);

      await connection.commit();

      return { success: true, data: garage };
    } catch (error) {
      await connection.rollback();

      return { error: true, message: 'Fail to add vehicle.' };
    } finally {
      connection.release();
    }
  },
  updateVehicle: async (data) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      let garageData = await UserGarage.getById(connection, data.id);
      fs.unlinkSync(
        path.dirname(__dirname) + '/storage/garage/' + garageData.image
      );
      data.image.mv(
        path.dirname(__dirname) + '/storage/garage/' + data.image.name
      );
      let garage = await UserGarage.updateById(connection, data);

      await connection.commit();

      return { success: true, data: garage };
    } catch (error) {
      await connection.rollback();

      return { error: true, message: 'Fail to update vehicle.' };
    } finally {
      connection.release();
    }
  },

  getUserGarageList: async (data) => {
    const connection = await pool.getConnection();
    try {
      let limit = 5;
      let offset = ((data.page ?? 1) - 1) * limit;

      let garage = await UserGarage.getList(
        connection,
        data.userId,
        limit,
        offset
      );

      let garageList = [];

      garage.forEach((vehicle) => {
        garageList.push({
          id: vehicle.id,
          user_id: vehicle.user_id,
          car_name: vehicle.vehicle_name,
          car_brand: vehicle.vehicle_brand_name,
          car_image: process.env.APP_URL + '/' + vehicle.image,
          car_year: vehicle.year,
        });
      });

      return { success: true, data: garageList };
    } catch (error) {
      return { error: true, message: 'Fail to get user garage list.' };
    } finally {
      connection.release();
    }
  },
};
