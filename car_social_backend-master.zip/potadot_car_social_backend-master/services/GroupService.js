const Group = require('../models/GroupModel');
const GroupMember = require('../models/GroupMemberModel');
const GroupMemberRequest = require('../models/GroupMemberRequestModel');
const User = require('../models/UserModel');
const path = require('path');
const fs = require('fs');
const { pool } = require('../db');

module.exports = {
  createGroup: async (data) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();
      var groupDir = path.dirname(__dirname) + '/storage/group/';

      if (!fs.existsSync(groupDir)) {
        fs.mkdirSync(groupDir);
      }

      if (data.group_image != null) {
        data.group_image.mv(
          path.dirname(__dirname) + '/storage/group/' + data.group_image.name
        );
      }
      if (data.background_image != null) {
        data.background_image.mv(
          path.dirname(__dirname) +
            '/storage/group/' +
            data.background_image.name
        );
      }

      data.group_image =
        data.group_image != null ? data.group_image.name : null;
      data.background_image =
        data.background_image != null ? data.background_image.name : null;

      const group = await Group.insert(connection, data);

      const groupMemberData = {
        groupId: group.id,
        userId: data.userId,
        isAdmin: true,
      };
      await GroupMember.insert(connection, groupMemberData);

      await connection.commit();

      return { success: true, data: group };
    } catch (error) {
      await connection.rollback();
      return { error: true, message: 'Fail to create group.' };
    } finally {
      connection.release();
    }
  },

  getMyGroupList: async (data) => {
    const connection = await pool.getConnection();
    try {
      data.limit = 5;
      data.offset = ((data.page ?? 1) - 1) * data.limit;

      let myGroups = await GroupMember.getList(connection, data);

      let groupList = [];
      myGroups.forEach((myGroup) => {
        groupList.push({
          id: myGroup.id,
          group_id: myGroup.group_id,
          name: myGroup.name,
          total_member: myGroup.total_member,
          background_image:
            process.env.APP_URL + '/' + myGroup.background_image,
        });
      });

      return { success: true, data: groupList };
    } catch (error) {
      return { error: true, message: 'Fail to get my group.' };
    } finally {
      connection.release();
    }
  },

  getNearMeGroupList: async (data) => {
    const connection = await pool.getConnection();
    try {
      let userDetails = await User.getById(connection, data.userId);

      data.limit = 5;
      data.offset = ((data.page ?? 1) - 1) * data.limit;
      data.country = userDetails.country;
      data.userId = userDetails.id;

      let nearMeGroups = await Group.getNearMeGroupList(connection, data);

      let groupList = [];

      nearMeGroups.forEach((nearMeGroup) => {
        groupList.push({
          id: nearMeGroup.id,
          name: nearMeGroup.name,
          total_member: nearMeGroup.total_member,
          background_image:
            process.env.APP_URL + '/' + nearMeGroup.background_image,
          is_joined: nearMeGroup.is_joined,
        });
      });

      return { success: true, data: groupList };
    } catch (error) {
      return { error: true, message: 'Fail to get near me group.' };
    } finally {
      connection.release();
    }
  },

  getSingleGroup: async (data) => {
    const connection = await pool.getConnection();
    try {
      const singleGroup = await Group.getByIdAndUserId(
        connection,
        data.id,
        data.userId
      );

      const singleGroupDetails = {
        id: singleGroup.id,
        name: singleGroup.name,
        total_member: singleGroup.total_member,
        description: singleGroup.description,
        group_image:
          singleGroup.group_image != null
            ? process.env.APP_URL + '/' + singleGroup.group_image
            : null,
        background_image:
          singleGroup.background_image != null
            ? process.env.APP_URL + '/' + singleGroup.background_image
            : null,
        is_private: singleGroup.is_private,
        is_admin: singleGroup.is_admin,
      };
      return { success: true, data: singleGroupDetails };
    } catch (error) {
      return { error: true, message: 'Fail to get single group.' };
    } finally {
      connection.release();
    }
  },
  deleteGroup: async (data) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      let groupMembers = await GroupMember.deleteByGroupId(connection, data.id);
      let group = await Group.deleteById(connection, data.id);

      await connection.commit();

      return { success: true, data: group };
    } catch (error) {
      await connection.rollback();

      return { error: true, message: 'Fail to delete group.' };
    } finally {
      connection.release();
    }
  },
  getMemberRequestList: async (data) => {
    const connection = await pool.getConnection();
    try {
      let limit = 10;
      let offset = ((data.page ?? 1) - 1) * limit;

      const memberRequest = await GroupMemberRequest.getByGroupId(
        connection,
        data.groupId,
        limit,
        offset
      );

      let memberRequestList = [];
      memberRequest.forEach((request) => {
        memberRequestList.push({
          user_id: request.user_id,
          group_id: request.group_id,
          username: request.username,
          bio: request.bio,
          profile_image: process.env.APP_URL + '/' + request.profile_image,
        });
      });

      return { success: true, data: memberRequestList };
    } catch (error) {
      return { error: true, message: 'Fail to get member request.' };
    } finally {
      connection.release();
    }
  },
  acceptRequest: async (data) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      let memberRequest = await GroupMemberRequest.update(connection, data);

      if (memberRequest) {
        const groupMemberData = {
          groupId: data.groupId,
          userId: data.userId,
          isAdmin: false,
        };
        await GroupMember.insert(connection, groupMemberData);
      }

      await connection.commit();

      return { success: true, data: memberRequest };
    } catch (error) {
      await connection.rollback();

      return { error: true, message: 'Fail to accept member request.' };
    } finally {
      connection.release();
    }
  },
  declineRequest: async (data) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      let memberRequest = await GroupMemberRequest.update(connection, data);

      await connection.commit();

      return { success: true, data: memberRequest };
    } catch (error) {
      await connection.rollback();

      return { error: true, message: 'Fail to decline member request.' };
    } finally {
      connection.release();
    }
  },
  getGroupSettingDetails: async (data) => {
    const connection = await pool.getConnection();
    try {
      const group = await Group.getById(connection, data.id);

      const groupDetails = {
        id: group.id,
        name: group.name,
        country: group.country,
        description: group.description,
        group_image:
          group.group_image != null
            ? process.env.APP_URL + '/' + group.group_image
            : null,
        background_image:
          group.background_image != null
            ? process.env.APP_URL + '/' + group.background_image
            : null,
        is_private: group.is_private,
      };
      return { success: true, data: groupDetails };
    } catch (error) {
      return { error: true, message: 'Fail to get group details.' };
    } finally {
      connection.release();
    }
  },
  update: async (data) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      let group = await Group.getById(connection, data.id);
      if (data.group_image != null) {
        data.group_image.mv(
          path.dirname(__dirname) + '/storage/group/' + data.group_image.name
        );
        if (
          fs.existsSync(
            path.dirname(__dirname) + '/storage/group/' + group.group_image
          )
        ) {
          fs.unlinkSync(
            path.dirname(__dirname) + '/storage/group/' + group.group_image
          );
        }
      }
      if (data.background_image != null) {
        data.background_image.mv(
          path.dirname(__dirname) +
            '/storage/group/' +
            data.background_image.name
        );
        if (
          fs.existsSync(
            path.dirname(__dirname) + '/storage/group/' + group.background_image
          )
        ) {
          fs.unlinkSync(
            path.dirname(__dirname) + '/storage/group/' + group.background_image
          );
        }
      }

      let groupData = {
        name: data.name ?? group.name,

        description:
          data.description == ''
            ? null
            : data.description ?? group.description ?? null,

        country: data.country ?? group.country,

        is_private:
          data.is_private == 'true' ? true : false ?? group.is_private,

        group_image:
          data.group_image != null ? data.group_image.name : group.group_image,

        background_image:
          data.background_image != null
            ? data.background_image.name
            : group.background_image,

        id: data.id,
      };

      group = await Group.update(connection, groupData);

      await connection.commit();

      if (data.group_image != null) {
        group.group_image = process.env.APP_URL + '/' + data.group_image.name;
      } else if (data.background_image != null) {
        group.background_image =
          process.env.APP_URL + '/' + data.background_image.name;
      }
      return { success: true, data: group };
    } catch (error) {
      await connection.rollback();

      return { error: true, message: 'Fail to update group details.' };
    } finally {
      connection.release();
    }
  },
  getTotalMemberRequest: async (data) => {
    const connection = await pool.getConnection();
    try {
      const memberRequest = await GroupMemberRequest.getTotalByGroupId(
        connection,
        data.groupId
      );

      return { success: true, data: memberRequest };
    } catch (error) {
      return { error: true, message: 'Fail to get total member request.' };
    } finally {
      connection.release();
    }
  },
};
