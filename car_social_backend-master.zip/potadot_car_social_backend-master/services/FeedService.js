const PostFile = require('../models/PostFileModel');
const PostLike = require('../models/PostLikeModel');
const Post = require('../models/PostModel');
const PostComment = require('../models/PostCommentModel');
const SavedPost = require('../models/UserSavedPostModel');
const fs = require('fs');
const path = require('path');
const { pool } = require('../db');

module.exports = {
  createPost: async (data) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      var feedDir = path.dirname(__dirname) + '/storage/feed';

      if (!fs.existsSync(feedDir)) {
        fs.mkdirSync(feedDir);
      }

      if (Array.isArray(data.files)) {
        data.files.forEach((media) => {
          media.mv(path.dirname(__dirname) + '/storage/feed/' + media.name);
        });
      } else {
        data.files.mv(
          path.dirname(__dirname) + '/storage/feed/' + data.files.name
        );
      }

      const post = await Post.insert(connection, {
        message: data.message,
        userId: data.userId,
      });

      await PostFile.insert(connection, data.files, post.id);
      await connection.commit();
      return { success: true, data: post };
    } catch (error) {
      await connection.rollback();
      return { error: true, message: 'Fail to create post.' };
    } finally {
      connection.release();
    }
  },

  getPostList: async (data) => {
    const connection = await pool.getConnection();
    try {
      data.limit = 5;
      data.offset = ((data.page ?? 1) - 1) * data.limit;

      let posts = await Post.getList(connection, data);

      let postList = [];
      posts.forEach((post) => {
        const previousId =
          postList[postList.length - 1] != null
            ? postList[postList.length - 1].id
            : null;

        if (post.id != previousId) {
          postList.push({
            id: post.id,
            user_id: post.user_id,
            username: post.username,
            profile_image:
              post.profile_image != null
                ? process.env.APP_URL + '/' + post.profile_image
                : null,
            content: post.content,
            group_id: post.group_id,
            total_like: post.total_like,
            total_comment: post.total_comment,
            is_liked: post.is_liked,
            is_saved: post.is_saved,
            created_at: post.created_at,
            updated_at: post.updated_at,
            media: [
              {
                type: post.type,
                url: process.env.APP_URL + '/' + post.name,
                display_order: post.display_order,
              },
            ],
          });
        } else {
          postList[postList.length - 1]['media'] = [
            ...postList[postList.length - 1]['media'],
            {
              type: post.type,
              url: process.env.APP_URL + '/' + post.name,
              display_order: post.display_order,
            },
          ];
        }
      });

      return { success: true, data: postList };
    } catch (error) {
      return { error: true, message: 'Fail to get post list.' };
    } finally {
      connection.release();
    }
  },

  deletePost: async (data) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      let postFiles = await PostFile.getPostFileData(connection, data);
      let posts = await Post.deleteById(connection, data.id);

      postFiles.forEach((file) => {
        fs.unlinkSync(path.dirname(__dirname) + '/storage/feed/' + file.name);
      });

      await connection.commit();

      return { success: true, data: posts };
    } catch (error) {
      await connection.rollback();

      return { error: true, message: 'Fail to delete post.' };
    } finally {
      connection.release();
    }
  },

  updatePost: async (data) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      let posts = await Post.updateById(connection, data);

      await connection.commit();

      return { success: true, data: posts };
    } catch (error) {
      await connection.rollback();

      return { error: true, message: 'Fail to update post.' };
    } finally {
      connection.release();
    }
  },

  likePost: async (data) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      await PostLike.insert(connection, data);

      await connection.commit();

      return { success: true };
    } catch (error) {
      await connection.rollback();

      return { error: true, message: 'Fail to like the post.' };
    } finally {
      connection.release();
    }
  },

  unlikePost: async (data) => {
    const connection = await pool.getConnection();

    try {
      await connection.beginTransaction();

      await PostLike.delete(connection, data);

      await connection.commit();

      return { success: true };
    } catch (error) {
      await connection.rollback();

      return { error: true, message: 'Fail to dislike the post.' };
    } finally {
      connection.release();
    }
  },

  getSinglePost: async (data) => {
    const connection = await pool.getConnection();
    try {
      let posts = await Post.getSinglePost(connection, data);

      let postsData = {
        id: posts[0].id,
        user_id: posts[0].user_id,
        username: posts[0].username,
        profile_image:
          posts[0].profile_image != null
            ? process.env.APP_URL + '/' + posts[0].profile_image
            : null,
        content: posts[0].content,
        group_id: posts[0].group_id,
        total_like: posts[0].total_like,
        is_liked: posts[0].is_liked,
        is_saved: posts[0].is_saved,
        total_comment: posts[0].total_comment,
        created_at: posts[0].created_at,
        updated_at: posts[0].updated_at,
        media: [],
      };

      posts.forEach((post) => {
        const previousId = postsData != null ? postsData.id : null;

        if (post.id != previousId) {
          postsData['media'].push({
            type: post.type,
            url: process.env.APP_URL + '/' + post.name,
            display_order: post.display_order,
          });
        } else {
          postsData['media'] = [
            ...postsData['media'],
            {
              type: post.type,
              url: process.env.APP_URL + '/' + post.name,
              display_order: post.display_order,
            },
          ];
        }
      });
      return { success: true, data: postsData };
    } catch (error) {
      return { error: true, message: 'Fail to get single post.' };
    } finally {
      connection.release();
    }
  },

  getCommentList: async (data) => {
    const connection = await pool.getConnection();
    try {
      data.limit = 5;
      data.offset = ((data.page ?? 1) - 1) * data.limit;

      let comments = await PostComment.getList(connection, data);

      let commentlist = [];
      comments.forEach((comment) => {
        commentlist.push({
          id: comment.id,
          username: comment.username,
          profile_image:
            comment.profile_image != null
              ? process.env.APP_URL + '/' + comment.profile_image
              : null,
          content: comment.content,
        });
      });

      return { success: true, data: commentlist };
    } catch (error) {
      return { error: true, message: 'Fail to get comment list.' };
    } finally {
      connection.release();
    }
  },

  createComment: async (data) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      const comment = await PostComment.insert(connection, {
        userId: data.userId,
        postId: data.postId,
        content: data.content,
      });

      await connection.commit();

      return { success: true, data: comment };
    } catch (error) {
      await connection.rollback();

      return { error: true, message: 'Fail to add the comment.' };
    } finally {
      connection.release();
    }
  },

  getFollowedUserPostList: async (data) => {
    const connection = await pool.getConnection();
    try {
      data.limit = 5;
      data.offset = ((data.page ?? 1) - 1) * data.limit;

      let posts = await Post.getFollowedUserPostList(connection, data);

      let postList = [];
      posts.forEach((post) => {
        const previousId =
          postList[postList.length - 1] != null
            ? postList[postList.length - 1].id
            : null;

        if (post.id != previousId) {
          postList.push({
            id: post.id,
            user_id: post.user_id,
            username: post.username,
            content: post.content,
            group_id: post.group_id,
            total_like: post.total_like,
            is_liked: post.is_liked,
            is_saved: post.is_saved,
            created_at: post.created_at,
            updated_at: post.updated_at,
            media: [
              {
                type: post.type,
                url: process.env.APP_URL + '/' + post.name,
                display_order: post.display_order,
              },
            ],
          });
        } else {
          postList[postList.length - 1]['media'] = [
            ...postList[postList.length - 1]['media'],
            {
              type: post.type,
              url: process.env.APP_URL + '/' + post.name,
              display_order: post.display_order,
            },
          ];
        }
      });

      return { success: true, data: postList };
    } catch (error) {
      return { error: true, message: 'Fail to get followed post list.' };
    } finally {
      connection.release();
    }
  },

  getSavedPostList: async (data) => {
    const connection = await pool.getConnection();
    try {
      limit = 10;
      offset = ((data.page ?? 1) - 1) * limit;

      let posts = await SavedPost.getListByUserId(
        connection,
        data.userId,
        limit,
        offset
      );

      let savedPostList = [];
      posts.forEach((post) => {
        savedPostList.push({
          id: post.id,
          user_id: post.user_id,
          username: post.username,
          postFirstMedia: {
            type: post.post_file_type,
            url: process.env.APP_URL + '/' + post.post_file_name,
          },
        });
      });
      return { success: true, data: savedPostList };
    } catch (error) {
      return { error: true, message: 'Fail to get saved post list.' };
    } finally {
      connection.release();
    }
  },

  savePost: async (data) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      await SavedPost.insert(connection, data);

      await connection.commit();

      return { success: true };
    } catch (error) {
      await connection.rollback();

      return { error: true, message: 'Fail to save the post.' };
    } finally {
      connection.release();
    }
  },

  unsavePost: async (data) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      await SavedPost.delete(connection, data);

      await connection.commit();

      return { success: true };
    } catch (error) {
      await connection.rollback();

      return { error: true, message: 'Fail to unsave the post.' };
    } finally {
      connection.release();
    }
  },
};
