const Event = require('../models/EventModel');
const path = require('path');
const EventMember = require('../models/EventMemberModel');
const User = require('../models/UserModel');
const { pool } = require('../db');
const fs = require('fs');

module.exports = {
  createEvent: async (data) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      var eventDir = path.dirname(__dirname) + '/storage/event';

      if (!fs.existsSync(eventDir)) {
        fs.mkdirSync(eventDir);
      }

      if (data.cover_photo != null) {
        data.cover_photo.mv(
          path.dirname(__dirname) + '/storage/event/' + data.cover_photo.name
        );
      }
      data.cover_photo =
        data.cover_photo != null ? data.cover_photo.name : null;
      const event = await Event.insert(connection, data);

      const eventMemberData = {
        eventId: event.id,
        userId: data.userId,
        isAdmin: true,
      };

      await EventMember.insert(connection, eventMemberData);

      await connection.commit();
      return { success: true, data: event };
    } catch (error) {
      await connection.rollback();
      return { error: true, message: error.message };
      return { error: true, message: 'Fail to create event.' };
    } finally {
      connection.release();
    }
  },

  getMyEventList: async (data) => {
    const connection = await pool.getConnection();
    try {
      limit = 5;
      offset = ((data.page ?? 1) - 1) * limit;

      let myEvents = await EventMember.getList(
        connection,
        data.userId,
        limit,
        offset
      );

      let eventList = [];
      myEvents.forEach((myEvent) => {
        eventList.push({
          id: myEvent.id,
          user_id: myEvent.user_id,
          username: myEvent.username,
          title: myEvent.title,
          total_member: myEvent.total_member,
          location: myEvent.location,
          start_date: myEvent.start_date,
          end_date: myEvent.end_date,
          cover_image: process.env.APP_URL + '/' + myEvent.cover_image,
        });
      });

      return { success: true, data: eventList };
    } catch (error) {
      return { error: true, message: 'Fail to get my event.' };
    } finally {
      connection.release();
    }
  },

  getSingleEvent: async (data) => {
    const connection = await pool.getConnection();
    try {
      const singleEvent = await Event.getByIdAndUserId(
        connection,
        data.id,
        data.userId
      );

      const singleEventDetails = {
        id: singleEvent.id,
        event_by: singleEvent.username,
        title: singleEvent.title,
        total_member: singleEvent.total_member,
        description: singleEvent.description,
        cover_image:
          singleEvent.cover_image != null
            ? process.env.APP_URL + '/' + singleEvent.cover_image
            : null,
        location: singleEvent.location,
        is_admin: singleEvent.is_admin,
        start_date: singleEvent.start_date,
        end_date: singleEvent.end_date,
      };

      return { success: true, data: singleEventDetails };
    } catch (error) {
      return { error: true, message: 'Fail to get single event.' };
    } finally {
      connection.release();
    }
  },

  getNearMeEventList: async (data) => {
    const connection = await pool.getConnection();
    try {
      let userDetails = await User.getById(connection, data.userId);
      data.country = userDetails.country;
      data.userId = userDetails.id;
      limit = 5;
      offset = ((data.page ?? 1) - 1) * limit;

      let nearMeEvents = await EventMember.getNearMeEventList(
        connection,
        data,
        limit,
        offset
      );

      let eventList = [];
      nearMeEvents.forEach((nearMeEvent) => {
        eventList.push({
          id: nearMeEvent.id,
          user_id: nearMeEvent.user_id,
          username: nearMeEvent.username,
          title: nearMeEvent.title,
          total_member: nearMeEvent.total_member,
          location: nearMeEvent.location,
          start_date: nearMeEvent.start_date,
          end_date: nearMeEvent.end_date,
          cover_image: process.env.APP_URL + '/' + nearMeEvent.cover_image,
        });
      });

      return { success: true, data: eventList };
    } catch (error) {
      return { error: true, message: 'Fail to get near me event' };
    } finally {
      connection.release();
    }
  },
};
