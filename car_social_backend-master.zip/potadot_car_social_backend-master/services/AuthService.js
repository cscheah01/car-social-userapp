const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const User = require('../models/UserModel');
const { pool } = require('../db');

module.exports = {
  login: async (data) => {
    const connection = await pool.getConnection();
    try {
      const user = await User.getByEmail(connection, data.email);

      if (!user || !bcrypt.compareSync(data.password, user.password)) {
        return {
          success: false,
          message: 'Invalid email or password.',
        };
      }

      const token = jwt.sign(
        {
          userId: user.id,
        },
        process.env.JWT_SECRET,
        {
          expiresIn: process.env.JWT_EXPIRES_IN,
        }
      );

      return {
        success: true,
        token: token,
        userId: user.id,
        message: 'Successfully logged in.',
      };
    } catch (error) {
      return { error: true, message: 'Fail to login.' };
    } finally {
      connection.release();
    }
  },

  register: async (data) => {
    const connection = await pool.getConnection();
    try {
      const user = await User.insert(connection, data);

      const token = jwt.sign(
        {
          userId: user.id,
        },
        process.env.JWT_SECRET,
        {
          expiresIn: process.env.JWT_EXPIRES_IN,
        }
      );

      return {
        success: true,
        token: token,
        userId: user.id,
        message: 'Successfully registered.',
      };
    } catch (error) {
      return { error: true, message: 'Fail to register.' };
    } finally {
      connection.release();
    }
  },
};
