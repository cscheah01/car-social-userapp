const CarBrand = require('../models/CarBrandModel');
const { pool } = require('../db');

module.exports = {
  getCarBrandList: async () => {
    const connection = await pool.getConnection();

    try {
      const carBrands = await CarBrand.getAll(connection);

      return { success: true, data: carBrands };
    } catch (error) {
      return { error: true, message: 'Fail to get car brand list.' };
    } finally {
      connection.release();
    }
  },
};
