const UserChatSession = require('../models/UserChatSessionModel');
const ChatMessage = require('../models/ChatMessageModel');
const User = require('../models/UserModel');
const ChatSession = require('../models/ChatSessionModel');
const { pool } = require('../db');

module.exports = {
  getChatList: async (data) => {
    const connection = await pool.getConnection();
    try {
      let limit = 10;
      let offset = ((data.page ?? 1) - 1) * limit;

      let sessionList = await UserChatSession.getChatListByUserId(
        connection,
        data.userId,
        limit,
        offset
      );

      let chatRoomUser = await UserChatSession.getChatRoomUser(
        connection,
        data.userId
      );

      let chatList = [];
      sessionList.forEach((chat, index) => {
        chatList.push({
          id: chat.id,
          user_id: chat.user_id,
          profile_image:
            chatRoomUser[index].profile_image != null
              ? process.env.APP_URL + '/' + chatRoomUser[index].profile_image
              : null,
          chat_session_id: chat.chat_session_id,
          created_at: chat.created_at,
          updated_at: chat.updated_at,
          latest_message: chat.latest_message,
          receiver: chatRoomUser[index].username,
        });
      });

      return { success: true, data: chatList };
    } catch (error) {
      return { error: true, message: 'Fail to get chat list.' };
    } finally {
      connection.release();
    }
  },
  getChatContent: async (data) => {
    const connection = await pool.getConnection();
    try {
      let limit = 20;
      let offset = ((data.page ?? 1) - 1) * limit;

      let chatContent = await ChatMessage.getAllByChatSessionId(
        connection,
        data.chatSessionId,
        limit,
        offset
      );

      let allChatContent = [];

      chatContent.forEach((chat) => {
        allChatContent.push({
          id: chat.id,
          user_id: chat.user_id,
          profile_image:
            chat.profile_image != null
              ? process.env.APP_URL + '/' + chat.profile_image
              : null,
          chat_session_id: chat.chat_session_id,
          content: chat.content,
        });
      });

      return { success: true, data: allChatContent };
    } catch (error) {
      return { error: true, message: 'Fail to get chat content.' };
    } finally {
      connection.release();
    }
  },

  createChatMessage: async (data) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      const chat = await ChatMessage.insert(connection, data);

      await connection.commit();

      return { success: true, data: chat };
    } catch (error) {
      await connection.rollback();

      return { error: true, message: 'Fail to send chat message.' };
    } finally {
      connection.release();
    }
  },
  getChatUser: async (data) => {
    const connection = await pool.getConnection();
    try {
      let users = await User.getByUsernameAndId(
        connection,
        data.username + '%',
        data.id
      );

      let userList = [];
      users.forEach((user) => {
        userList.push({
          id: user.id,
          username: user.username,
          profile_image:
            user.profile_image != null
              ? process.env.APP_URL + '/' + user.profile_image
              : null,
        });
      });

      return { success: true, data: userList };
    } catch (error) {
      return { error: true, message: 'Fail to get user list.' };
    } finally {
      connection.release();
    }
  },
  getChatSession: async (data) => {
    const connection = await pool.getConnection();
    try {
      let userChatSession = await UserChatSession.getChatSessionByUserId(
        connection,
        data
      );
      let chatRoomUser;

      if (!userChatSession) {
        const chatSessionData = {
          is_privated: true,
          name: null,
        };
        let chatSession = await ChatSession.insert(connection, chatSessionData);

        data.chat_session_id = chatSession.id;
        userChatSession = await UserChatSession.insert(connection, data);

        chatRoomUser =
          await UserChatSession.getChatRoomUserByUserIdAndChatSessionId(
            connection,
            data.userId,
            data.chat_session_id
          );
      } else {
        chatRoomUser =
          await UserChatSession.getChatRoomUserByUserIdAndChatSessionId(
            connection,
            data.userId,
            userChatSession.chat_session_id
          );
      }

      userChatSession.receiver = chatRoomUser.username;

      return { success: true, data: userChatSession };
    } catch (error) {
      return { error: true, message: 'Fail to get chat session.' };
    } finally {
      connection.release();
    }
  },
};
