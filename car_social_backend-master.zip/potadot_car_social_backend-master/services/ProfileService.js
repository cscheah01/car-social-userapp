const User = require('../models/UserModel');
const path = require('path');
const fs = require('fs');
const { pool } = require('../db');

module.exports = {
  getUserData: async (data) => {
    const connection = await pool.getConnection();
    try {
      const profile = await User.getById(connection, data);

      const profileHeader = {
        id: profile.id,
        email: profile.email,
        username: profile.username,
        bio: profile.bio,
        phone_no: profile.phone_no,
        dob: profile.dob,
        profile_image:
          profile.profile_image != null
            ? process.env.APP_URL + '/' + profile.profile_image
            : null,
        background_image:
          profile.background_image != null
            ? process.env.APP_URL + '/' + profile.background_image
            : null,
      };
      return { success: true, data: profileHeader };
    } catch (error) {
      return { error: true, message: 'Fail to get profile header.' };
    } finally {
      connection.release();
    }
  },

  getProfileDetails: async (data) => {
    const connection = await pool.getConnection();
    try {
      const profile = await User.getById(connection, data.id);

      const profileDetails = {
        id: profile.id,
        username: profile.username,
        email: profile.email,
        phone_no: profile.phone_no,
        dob: profile.dob,
        bio: profile.bio,
        profile_image:
          profile.profile_image != null
            ? process.env.APP_URL + '/' + profile.profile_image
            : null,
        background_image:
          profile.background_image != null
            ? process.env.APP_URL + '/' + profile.background_image
            : null,
      };

      return { success: true, data: profileDetails };
    } catch (error) {
      return { error: true, message: 'Fail to get profile details.' };
    } finally {
      connection.release();
    }
  },

  update: async (data) => {
    const connection = await pool.getConnection();
    try {
      var profileDir = path.dirname(__dirname) + '/storage/profile';

      if (!fs.existsSync(profileDir)) {
        fs.mkdirSync(profileDir);
      }
      let user = await User.getById(connection, data.id);

      if (data.profile_image != null) {
        data.profile_image.mv(
          path.dirname(__dirname) +
            '/storage/profile/' +
            data.profile_image.name
        );
        if (
          fs.existsSync(
            path.dirname(__dirname) + '/storage/profile/' + user.profile_image
          )
        ) {
          fs.unlinkSync(
            path.dirname(__dirname) + '/storage/profile/' + user.profile_image
          );
        }
      }
      if (data.background_image != null) {
        data.background_image.mv(
          path.dirname(__dirname) +
            '/storage/profile/' +
            data.background_image.name
        );

        if (
          fs.existsSync(
            path.dirname(__dirname) +
              '/storage/profile/' +
              user.background_image
          )
        ) {
          fs.unlinkSync(
            path.dirname(__dirname) +
              '/storage/profile/' +
              user.background_image
          );
        }
      }

      let userData = {
        username: data.username ?? user.username,
        email: data.email ?? user.email,
        bio: data.bio == '' ? null : data.bio ?? user.bio ?? null,
        dob: data.dob ?? user.dob,
        phone_no: data.phone_no ?? user.phone_no,
        profile_image:
          data.profile_image != null
            ? data.profile_image.name
            : user.profile_image,
        background_image:
          data.background_image != null
            ? data.background_image.name
            : user.background_image,
        id: data.id,
      };

      let profile = await User.update(connection, userData);

      await connection.commit();
      return { success: true, data: profile };
    } catch (error) {
      await connection.rollback();

      return { error: true, message: 'Fail to update profile details.' };
    } finally {
      connection.release();
    }
  },
};
