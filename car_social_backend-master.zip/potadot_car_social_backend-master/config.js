const config = {
  db: {
    host: 'localhost',
    user: 'root',
    password: null,
    database: 'potadot_car_social',
    dateStrings: true,
  },
};

module.exports = config;
