module.exports = {
  insert: async (connection, data) => {
    const [result] = await connection.query(
      'INSERT INTO posts SET user_id = ?, content = ?',
      [data.userId, data.message]
    );

    return { id: result.insertId, ...data };
  },

  getList: async (connection, data) => {
    const [result] = await connection.query(
      `SELECT posts.*,post_files.type,post_files.name,post_files.display_order,users.username,
      (SELECT COUNT(*) FROM post_likes WHERE post_id = posts.id) as total_like, 
      CASE WHEN (SELECT COUNT(*) FROM post_likes WHERE post_id = posts.id AND user_id = ?) > 0 THEN 1 ELSE 0 END as is_liked,
      CASE WHEN (SELECT COUNT(*) FROM user_saved_posts WHERE post_id = posts.id AND user_id = ?) > 0 THEN 1 ELSE 0 END as is_saved,
      (SELECT COUNT(*) FROM post_comments WHERE post_id = posts.id) as total_comment FROM posts 
      LEFT JOIN post_files ON post_files.post_id = posts.id 
      LEFT JOIN users ON posts.user_id = users.id
      ORDER BY created_at DESC LIMIT ? OFFSET ?`,
      [data.userId, data.userId, data.limit, data.offset]
    );

    if (!result) {
      return null;
    }

    return result;
  },

  deleteById: async (connection, id) => {
    const [result] = await connection.query('DELETE FROM posts WHERE id = ?', [
      id,
    ]);

    return result;
  },

  updateById: async (connection, data) => {
    const [result] = await connection.query(
      'UPDATE posts SET content = ? WHERE id = ?',
      [data.message, data.id]
    );

    return result;
  },

  getById: async (connection, id) => {
    const [result] = await connection.query(
      'SELECT posts.*,post_files.type,post_files.name,post_files.display_order FROM posts INNER JOIN post_files ON post_files.post_id = posts.id WHERE post_id = ?',
      [id]
    );

    if (!result) {
      return null;
    }

    return result;
  },

  getSinglePost: async (connection, data) => {
    var [result] = await connection.query(
      `SELECT posts.*,post_files.type,post_files.name,post_files.display_order,users.username,
      (SELECT COUNT(*) FROM post_likes WHERE post_id = posts.id) as total_like,
      CASE WHEN (SELECT COUNT(*) FROM post_likes WHERE post_id = posts.id AND user_id = ?) > 0 THEN 1 ELSE 0 END as is_liked,
      (SELECT COUNT(*) FROM post_comments WHERE post_id = posts.id) as total_comment FROM posts 
      LEFT JOIN post_files ON post_files.post_id = posts.id
      LEFT JOIN users ON posts.user_id = users.id WHERE posts.id = ?`,
      [data.userId, data.id]
    );

    if (!result) {
      return null;
    }
    return result;
  },

  getFollowedUserPostList: async (connection, data) => {
    const [result] = await connection.query(
      `SELECT posts.*,post_files.type,post_files.name,post_files.display_order,users.username,
      (SELECT COUNT(*) FROM post_likes WHERE post_id = posts.id) as total_like, 
      CASE WHEN (SELECT COUNT(*) FROM post_likes WHERE post_id = posts.id AND user_id = ?) > 0 THEN 1 ELSE 0 END as is_liked 
      FROM posts LEFT JOIN post_files ON post_files.post_id = posts.id 
      LEFT JOIN users ON posts.user_id = users.id
      INNER JOIN (select user_id from user_followers where followed_by = ? ORDER BY created_at LIMIT ? OFFSET ?) as user_followers ON posts.user_id = user_followers.user_id
      ORDER BY created_at DESC LIMIT ? OFFSET ?`,
      [
        data.userId,
        data.userId,
        data.limit,
        data.offset,
        data.limit,
        data.offset,
      ]
    );
    if (!result) {
      return null;
    }

    return result;
  },

  getByIdAndUserId: async (connection, id, userId) => {
    const [result] = await connection.query(
      'SELECT * from posts WHERE id = ? AND user_id = ?',
      [id, userId]
    );

    return result;
  },
};
