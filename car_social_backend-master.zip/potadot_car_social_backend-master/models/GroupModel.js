module.exports = {
  insert: async (connection, data) => {
    const [result] = await connection.query(
      'INSERT INTO groups SET group_image = ?, background_image = ?, name = ?, description = ?, country = ?, is_private = ?',
      [
        data.group_image,
        data.background_image,
        data.name,
        data.description,
        data.country,
        data.is_private,
      ]
    );

    return { id: result.insertId };
  },

  deleteById: async (connection, id) => {
    const [result] = await connection.query('DELETE FROM groups WHERE id = ?', [
      id,
    ]);

    return result;
  },

  getNearMeGroupList: async (connection, data) => {
    const [result] = await connection.query(
      'SELECT groups.id,groups.name,groups.background_image,(SELECT COUNT(*) FROM group_members WHERE group_id = groups.id) as total_member,CASE WHEN (SELECT COUNT(*) FROM group_members WHERE group_id = groups.id AND user_id = ?) > 0 THEN 1 ELSE 0 END as is_joined FROM groups WHERE groups.country = ? LIMIT ? OFFSET ? ',

      [data.userId, data.country, data.limit, data.offset]
    );

    if (!result) {
      return null;
    }

    return result;
  },

  getByName: async (connection, name) => {
    const [result] = await connection.query(
      'SELECT * from groups WHERE name = ?',
      [name]
    );

    return result[0];
  },

  getByIdAndUserId: async (connection, id, userId) => {
    let [result] = await connection.query(
      'SELECT *,(SELECT COUNT(*) FROM group_members WHERE group_id = groups.id) as total_member,(SELECT is_admin FROM group_members WHERE group_id = groups.id AND user_id = ?) as is_admin FROM groups WHERE id = ? ',
      [userId, id]
    );

    if (!result) {
      return null;
    }

    return result[0];
  },
  getById: async (connection, id) => {
    let [result] = await connection.query('SELECT * FROM groups WHERE id = ? ', [
      id,
    ]);

    if (!result) {
      return null;
    }

    return result[0];
  },
  update: async (connection, data) => {
    const [result] = await connection.query(
      'UPDATE groups SET group_image = ? ,background_image = ?, name  = ?, description = ?, country = ?, is_private = ? WHERE id = ?',
      [
        data.group_image,
        data.background_image,
        data.name,
        data.description,
        data.country,
        data.is_private,
        data.id,
      ]
    );

    return result;
  },
};
