module.exports = {
  getAllByChatSessionId: async (
    connection,
    chatSessionId,
    limit = 15,
    offset = 0
  ) => {
    const [result] = await connection.query(
      'SELECT * from chat_messages WHERE chat_session_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?',
      [chatSessionId, limit, offset]
    );

    if (!result) {
      return null;
    }

    return result;
  },
  insert: async (connection, data) => {
    const [result] = await connection.query(
      'INSERT INTO chat_messages SET user_id = ?, chat_session_id = ?, content = ?',
      [data.userId, data.chatSessionId, data.content]
    );

    return { id: result.insertId, ...data };
  },
};
