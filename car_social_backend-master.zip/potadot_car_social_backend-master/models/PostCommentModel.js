module.exports = {
  insert: async (connection, data) => {
    const [result] = await connection.query(
      'INSERT INTO post_comments SET post_id = ?, user_id = ? , content = ?',
      [data.postId, data.userId, data.content]
    );

    return result;
  },

  getList: async (connection, data) => {
    const [result] = await connection.query(
      'SELECT post_comments.*,users.username FROM post_comments LEFT JOIN users ON user_id = users.id WHERE post_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?',
      [data.postId, data.limit, data.offset]
    );

    if (!result) {
      return null;
    }

    return result;
  },
};
