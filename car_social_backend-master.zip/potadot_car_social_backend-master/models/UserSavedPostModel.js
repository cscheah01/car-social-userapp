module.exports = {
  insert: async (connection, data) => {
    const [result] = await connection.query(
      'INSERT INTO user_saved_posts SET post_id = ?, user_id = ?',
      [data.postId, data.userId]
    );

    return { id: result.insertId, ...data };
  },

  delete: async (connection, data) => {
    const [result] = await connection.query(
      'DELETE FROM user_saved_posts WHERE post_id = ? AND user_id = ?',
      [data.postId, data.userId]
    );

    if (!result) {
      return null;
    }

    return result;
  },

  getListByUserId: async (connection, userId, limit = 10, offset = 0) => {
    const [result] = await connection.query(
      `SELECT user_saved_posts.*, users.username, users.profile_image, posts.id, 
      (SELECT name from post_files WHERE post_id = posts.id AND display_order = 0) AS post_file_name,
      (SELECT type from post_files WHERE post_id = posts.id AND display_order = 0) AS post_file_type FROM user_saved_posts 
      LEFT JOIN posts ON user_saved_posts.post_id = posts.id
      LEFT JOIN post_files ON post_files.post_id = posts.id 
      LEFT JOIN users ON posts.user_id = users.id
      WHERE user_saved_posts.user_id = ? AND post_files.display_order = 0
      ORDER BY user_saved_posts.created_at DESC LIMIT ? OFFSET ?`,

      [userId, limit, offset]
    );

    if (!result) {
      return null;
    }

    return result;
  },
};
