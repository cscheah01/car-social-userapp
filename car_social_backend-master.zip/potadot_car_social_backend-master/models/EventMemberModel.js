module.exports = {
  getList: async (connection, userId, limit = 5, offset = 0) => {
    const [result] = await connection.query(
      `SELECT events.*, 
      (SELECT username FROM users WHERE id IN (SELECT user_id from event_members WHERE is_admin = true AND event_id = events.id)) as username,
      (SELECT COUNT(*) FROM event_members WHERE event_id = events.id) as total_member
      FROM event_members 
      LEFT JOIN events ON events.id = event_members.event_id 
      LEFT JOIN users ON event_members.user_id = users.id
      WHERE event_members.user_id = ? LIMIT ? OFFSET ? `,

      [userId, limit, offset]
    );

    if (!result) {
      return null;
    }

    return result;
  },

  insert: async (connection, data) => {
    const [result] = await connection.query(
      'INSERT INTO event_members SET event_id = ?, user_id = ?, is_admin = ?',
      [data.eventId, data.userId, data.isAdmin]
    );

    return { id: result.insertId, ...data };
  },

  getNearMeEventList: async (connection, data, limit = 5, offset = 0) => {
    const [result] = await connection.query(
      `SELECT events.*, 
      (SELECT username FROM users WHERE id IN (SELECT user_id from event_members WHERE is_admin = true AND event_id = events.id)) as username,
      (SELECT COUNT(*) FROM event_members WHERE event_id = events.id) as total_member,
      CASE WHEN (SELECT COUNT(*) FROM event_members WHERE event_id = events.id AND user_id = ?) > 0 THEN 1 ELSE 0 END as is_joined 
      FROM event_members
      LEFT JOIN events ON events.id = event_members.event_id
      LEFT JOIN users ON users.id = event_members.user_id
      WHERE events.location = ? GROUP BY event_members.event_id LIMIT ? OFFSET ? `,
      [data.userId, data.country, limit, offset]
    );

    if (!result) {
      return null;
    }

    return result;
  },
};
