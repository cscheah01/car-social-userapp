module.exports = {
  insert: async (connection, data) => {
    const [result] = await connection.query(
      'INSERT INTO chat_sessions SET name = ?, is_privated = ?',
      [data.name, data.is_privated]
    );

    return { id: result.insertId, ...data };
  },
};
