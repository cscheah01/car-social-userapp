module.exports = {
  getFollowingList: async (connection, data) => {
    const [result] = await connection.query(
      'SELECT user_followers.id,users.username,users.profile_image,users.bio FROM user_followers LEFT JOIN users ON users.id = user_followers.user_id WHERE user_followers.followed_by = ? LIMIT ? OFFSET ? ',

      [data.userId, data.limit, data.offset]
    );

    if (!result) {
      return null;
    }

    return result;
  },

  getFollowerList: async (connection, data) => {
    const [result] = await connection.query(
      'SELECT user_followers.id,users.username,users.profile_image,users.bio FROM user_followers LEFT JOIN users ON users.id = user_followers.followed_by WHERE user_followers.user_id = ? LIMIT ? OFFSET ? ',

      [data.userId, data.limit, data.offset]
    );

    if (!result) {
      return null;
    }

    return result;
  },
};
