module.exports = {
  insert: async (connection, data) => {
    const [result] = await connection.query(
      'INSERT INTO post_likes SET post_id = ?, user_id = ?',
      [data.postId, data.userId]
    );

    return { id: result.insertId, ...data };
  },

  delete: async (connection, data) => {
    const [result] = await connection.query(
      'DELETE FROM post_likes WHERE post_id = ? AND user_id = ?',
      [data.postId, data.userId]
    );

    if (!result) {
      return null;
    }

    return result;
  },
};
