module.exports = {
  insert: async (connection, data, postId) => {
    if (Array.isArray(data)) {
      data.forEach(async (media, index) => {
        await connection.query(
          'INSERT INTO post_files SET post_id = ?, type = ?, name = ?, display_order = ?',
          [postId, media.mimetype, media.name, index]
        );
      });
    } else {
      await connection.query(
        'INSERT INTO post_files SET post_id = ?, type = ?, name = ?, display_order = ?',
        [postId, data.mimetype, data.name, 0]
      );
    }

    return true;
  },
  getPostFileData: async (connection, data) => {
    let [result] = await connection.query(
      'SELECT name from post_files WHERE post_id = ' + data.id
    );

    return result;
  },
};
