module.exports = {
  insert: async (connection, data) => {
    const [result] = await connection.query(
      'INSERT INTO user_garages SET user_id = ?, car_model_id = ?, image = ?',
      [data.userId, data.carModelId, data.image.name]
    );

    return { id: result.insertId };
  },

  updateById: async (connection, data) => {
    const result = await connection.query(
      'UPDATE user_garages SET car_model_id = ?, image = ? WHERE id = ?',
      [data.carModelId, data.image.name, data.id]
    );

    return result;
  },

  getById: async (connection, id) => {
    let [result] = await connection.query(
      'SELECT * from user_garages WHERE id = ' + id
    );

    return result[0];
  },

  getList: async (connection, userId, limit = 5, offset = 0) => {
    let [result] = await connection.query(
      `SELECT user_garages.*,car_brand_models.name as vehicle_name,car_brands.name as vehicle_brand_name from user_garages 
      LEFT JOIN car_brand_models ON user_garages.car_model_id = car_brand_models.id
      LEFT JOIN car_brands ON car_brand_models.car_brand_id = car_brands.id
      WHERE user_garages.user_id = ? ORDER BY user_garages.created_at DESC LIMIT ? OFFSET ?`,
      [userId, limit, offset]
    );

    return result;
  },
};
