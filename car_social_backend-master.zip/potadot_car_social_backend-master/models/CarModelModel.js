module.exports = {
  getAllByCarBrandId: async (connection, carBrandId) => {
    const [result] = await connection.query(
      'SELECT * FROM car_brand_models WHERE car_brand_id = ?',
      [carBrandId]
    );

    if (!result) {
      return null;
    }

    return result;
  },
};
