module.exports = {
  insert: async (connection, data) => {
    const [result] = await connection.query(
      'INSERT INTO events SET cover_image = ?, title = ?, description = ?, location = ?, start_date = ?, end_date = ?',
      [
        data.cover_photo,
        data.title,
        data.description,
        data.location,
        data.start_date,
        data.end_date,
      ]
    );

    return { id: result.insertId };
  },
  getListByUserId: async (connection, userId, limit = 15, offset = 0) => {
    const [result] = await connection.query(
      'SELECT events.*,users.username FROM events LEFT JOIN users ON events.user_id = users.id WHERE user_id = ? DESC LIMIT ? OFFSET ? ',

      [userId, limit, offset]
    );

    if (!result) {
      return null;
    }

    return result;
  },
  getByIdAndUserId: async (connection, id, userId) => {
    let [result] = await connection.query(
      `SELECT events.*,(SELECT COUNT(*) FROM event_members WHERE event_id = events.id) as total_member, (SELECT is_admin FROM event_members WHERE event_id = events.id AND user_id = ?) as is_admin, users.username FROM events 
      LEFT JOIN event_members ON event_members.event_id = events.id 
      LEFT JOIN users ON users.id = event_members.user_id WHERE events.id = ? AND event_members.is_admin = true`,
      [userId, id]
    );

    if (!result) {
      return null;
    }

    return result[0];
  },
  getByTitle: async (connection, title) => {
    const [result] = await connection.query(
      'SELECT * from events WHERE title = ?',
      [title]
    );

    return result[0];
  },
};
