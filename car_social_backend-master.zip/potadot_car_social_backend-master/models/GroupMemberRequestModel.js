module.exports = {
  getByGroupId: async (connection, groupId, limit = 10, offset = 0) => {
    const [result] = await connection.query(
      `SELECT group_member_requests.*,users.username,users.profile_image,users.bio from group_member_requests 
      LEFT JOIN users ON group_member_requests.user_id = users.id WHERE group_member_requests.group_id = ? AND group_member_requests.is_waiting = ? LIMIT ? OFFSET ? `,

      [groupId, true, limit, offset]
    );

    if (!result) {
      return null;
    }

    return result;
  },

  update: async (connection, data) => {
    const [result] = await connection.query(
      'UPDATE group_member_requests SET is_waiting = ? ,is_approved = ?, updated_by = ? WHERE group_id = ? AND user_id = ?',
      [
        data.isWaiting,
        data.isApproved,
        data.updatedBy,
        data.groupId,
        data.userId,
      ]
    );

    return result;
  },

  getTotalByGroupId: async (connection, groupId) => {
    const [result] = await connection.query(
      `SELECT COUNT(*) as total_requests from group_member_requests WHERE group_id = ? AND is_waiting = ?`,
      [groupId, true]
    );

    if (!result) {
      return 0;
    }

    return result[0].total_requests;
  },
};
