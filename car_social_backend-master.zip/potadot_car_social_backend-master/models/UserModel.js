const bcrypt = require('bcryptjs');

module.exports = {
  insert: async (connection, data) => {
    await bcrypt.hash(data.password, 10, (err, hash) => {
      data.password = hash;
    });

    data.password = bcrypt.hashSync(data.password, 10);

    let [result] = await connection.query(
      'INSERT INTO users SET username = ?, email = ?, phone_no = ?, country = ?, password = ?,dob = ?',
      [
        data.username,
        data.email,
        data.phone_no,
        data.country,
        data.password,
        data.dob,
      ]
    );

    return { id: result.insertId, ...data };
  },

  getById: async (connection, id) => {
    let [result] = await connection.query('SELECT * FROM users WHERE id = ?', [
      id,
    ]);

    if (!result) {
      return null;
    }

    return result[0];
  },

  update: async (connection, data) => {
    const [result] = await connection.query(
      'UPDATE users SET username = ? ,email = ?, phone_no = ?, dob = ?, bio = ?, profile_image = ?, background_image = ? WHERE id = ?',
      [
        data.username,
        data.email,
        data.phone_no,
        data.dob,
        data.bio,
        data.profile_image,
        data.background_image,
        data.id,
      ]
    );

    return result;
  },

  getByPhoneNumber: async (connection, phoneNo) => {
    const [result] = await connection.query(
      'SELECT * from users WHERE phone_no = ?',
      [phoneNo]
    );

    return result[0];
  },

  getByUsername: async (connection, username) => {
    const [result] = await connection.query(
      'SELECT * from users WHERE username LIKE ?',
      [username]
    );

    return result[0];
  },

  getByEmail: async (connection, email) => {
    const [result] = await connection.query(
      'SELECT * from users WHERE email = ?',
      [email]
    );

    return result[0];
  },

  getByUsernameAndId: async (connection, username, id) => {
    let [result] = await connection.query(
      'SELECT * FROM users WHERE username LIKE ? AND id != ?',
      [username, id]
    );

    if (!result) {
      return null;
    }

    return result;
  },
};
