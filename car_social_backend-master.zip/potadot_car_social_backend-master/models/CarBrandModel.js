module.exports = {
  getAll: async (connection) => {
    const [result] = await connection.query('SELECT * FROM car_brands');

    if (!result) {
      return null;
    }

    return result;
  },
};
