module.exports = {
  getList: async (connection, data) => {
    const [result] = await connection.query(
      'SELECT group_members.id,group_members.group_id,groups.name,groups.background_image,(SELECT COUNT(*) FROM group_members WHERE group_id = groups.id) as total_member FROM group_members LEFT JOIN groups ON groups.id = group_members.group_id WHERE user_id = ? LIMIT ? OFFSET ? ',

      [data.userId, data.limit, data.offset]
    );

    if (!result) {
      return null;
    }

    return result;
  },

  deleteByGroupId: async (connection, groupId) => {
    const [result] = await connection.query(
      'DELETE FROM group_members WHERE group_id = ?',
      [groupId]
    );

    return result;
  },

  insert: async (connection, data) => {
    const [result] = await connection.query(
      'INSERT INTO group_members SET group_id = ?, user_id = ?, is_admin = ?',
      [data.groupId, data.userId, data.isAdmin]
    );

    return { id: result.insertId, ...data };
  },
};
