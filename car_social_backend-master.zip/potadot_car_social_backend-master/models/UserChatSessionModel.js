module.exports = {
  getChatListByUserId: async (connection, userId, limit = 15, offset = 0) => {
    let [result] = await connection.query(
      `SELECT user_chat_sessions.*, (SELECT content FROM chat_messages WHERE chat_session_id = user_chat_sessions.chat_session_id ORDER BY created_at DESC LIMIT 1) as latest_message FROM user_chat_sessions WHERE user_id = ? LIMIT ? OFFSET ?`,
      [userId, limit, offset]
    );

    if (!result) {
      return null;
    }

    return result;
  },

  getChatRoomUser: async (connection, userId) => {
    let [result] = await connection.query(
      `SELECT user_chat_sessions.user_id,users.username
      FROM user_chat_sessions
      LEFT JOIN users ON user_chat_sessions.user_id = users.id
      WHERE user_id != ? AND
      chat_session_id IN (SELECT chat_session_id FROM user_chat_sessions WHERE user_id = ?)
      GROUP BY chat_session_id`,
      [userId, userId]
    );

    if (!result) {
      return null;
    }

    return result;
  },
  getChatSessionByUserId: async (connection, data) => {
    let [result] = await connection.query(
      `SELECT user_chat_sessions.* FROM user_chat_sessions WHERE user_id = ? AND chat_session_id IN (SELECT chat_session_id FROM user_chat_sessions WHERE user_id = ?)`,
      [data.userId, data.receiverUserId]
    );

    if (!result) {
      return null;
    }

    return result[0];
  },
  insert: async (connection, data) => {
    const [result] = await connection.query(
      'INSERT INTO user_chat_sessions(user_id, chat_session_id) VALUES (?, ?), (?, ?)',
      [
        data.userId,
        data.chat_session_id,
        data.receiverUserId,
        data.chat_session_id,
      ]
    );

    return { id: result.insertId, ...data };
  },
  getChatRoomUserByUserIdAndChatSessionId: async (
    connection,
    userId,
    chatSessionId
  ) => {
    let [result] = await connection.query(
      `SELECT user_chat_sessions.user_id,users.username
      FROM user_chat_sessions
      LEFT JOIN users ON user_chat_sessions.user_id = users.id
      WHERE user_id != ? AND
      chat_session_id IN (SELECT chat_session_id FROM user_chat_sessions WHERE user_id = ?)`,
      [userId, chatSessionId]
    );

    if (!result) {
      return null;
    }

    return result;
  },
};
