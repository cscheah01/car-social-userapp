const express = require('express');
const cors = require('cors');
const app = express();
require('dotenv').config();
const ngrok = require('ngrok');
const fileUpload = require('express-fileupload');
var AuthRouter = require('./routes/AuthRouter');
var FeedRoutes = require('./routes/FeedRouter');
var GroupRouter = require('./routes/GroupRouter');
var ProfileRouter = require('./routes/ProfileRouter');
var AuthMiddleware = require('./middleware/AuthMiddleware');
var ChatRouter = require('./routes/ChatRouter');
var UserGarageRouter = require('./routes/UserGarageRouter');
var CarBrandRouter = require('./routes/CarBrandRouter');
var CarModelRouter = require('./routes/CarModelRouter');
var EventRouter = require('./routes/EventRouter');
var UserFollowerRouter = require('./routes/UserFollowerRouter');

app.use(cors());
// parse requests of content-type - application/json
app.use(express.json());
// parse requests of content-type - application/x-www-form-urlencoded
app.use(express.urlencoded({ extended: true }));
app.use(express.static(`${__dirname}/storage/feed`));
app.use(express.static(`${__dirname}/storage/group`));
app.use(fileUpload());
app.use(express.static(`${__dirname}/storage/feed`));
app.use(express.static(`${__dirname}/storage/profile`));
app.use(express.static(`${__dirname}/storage/event`));
app.use(express.static(`${__dirname}/storage/garage`));

app.use('/auth', AuthRouter);
app.use('/post', AuthMiddleware.isLoggedIn, FeedRoutes);
app.use('/profile', AuthMiddleware.isLoggedIn, ProfileRouter);
app.use('/group', AuthMiddleware.isLoggedIn, GroupRouter);
app.use('/chat', AuthMiddleware.isLoggedIn, ChatRouter);
app.use('/garage', AuthMiddleware.isLoggedIn, UserGarageRouter);
app.use('/event', AuthMiddleware.isLoggedIn, EventRouter);
app.use('/car-brand', CarBrandRouter);
app.use('/car-model', CarModelRouter);
app.use('/user-follower', AuthMiddleware.isLoggedIn, UserFollowerRouter);

// set port, listen for requests
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
});

ngrok.connect(
  {
    proto: 'http',
    addr: process.env.PORT,
  },
  (err, url) => {
    if (err) {
      console.error('Error while connecting Ngrok', err);
      return new Error('Ngrok Failed');
    }
  }
);
