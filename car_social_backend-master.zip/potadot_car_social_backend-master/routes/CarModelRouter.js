var express = require('express');
var router = express.Router();
var CarModelController = require('../controllers/CarModelController');

router.get('/:carBrandId', CarModelController.getCarModelList);
module.exports = router;
