var express = require('express');
var router = express.Router();
var GroupController = require('../controllers/GroupController');
var GroupValidator = require('../validators/GroupValidator');

router.post(
  '/create',
  [GroupValidator.create, GroupValidator.result],
  GroupController.create
);

router.get('/my-group', GroupController.getMyGroupList);

router.get('/near-me', GroupController.getNearMeGroupList);

router.delete('/:id', GroupController.delete);

router.get('/details/:id', GroupController.getSingleGroup);

router.get('/member-request/:groupId', GroupController.getMemberRequestList);

router.get(
  '/total-member-request/:groupId',
  GroupController.getTotalMemberRequest
);

router.get('/group-setting/:id', GroupController.getGroupSettingDetails);

router.patch('/accept-request/:userId', GroupController.acceptRequest);

router.patch('/decline-request/:userId', GroupController.declineRequest);

router.patch(
  '/group-details/:id',
  [GroupValidator.update, GroupValidator.result],
  GroupController.update
);

module.exports = router;
