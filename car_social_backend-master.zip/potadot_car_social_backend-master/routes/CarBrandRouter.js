var express = require('express');
var router = express.Router();
var CarBrandController = require('../controllers/CarBrandController');

router.get('/', CarBrandController.getCarBrandList);

module.exports = router;
