var express = require('express');
var router = express.Router();
var UserGarageController = require('../controllers/UserGarageController');
var UserGarageValidator = require('../validators/UserGaragesValidator');

router.post(
  '/',
  [UserGarageValidator.create, UserGarageValidator.result],
  UserGarageController.create
);

router.patch(
  '/update/:id',
  [UserGarageValidator.edit, UserGarageValidator.result],
  UserGarageController.update
);

router.get('/', UserGarageController.getList);

module.exports = router;
