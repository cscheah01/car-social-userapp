var express = require('express');
var router = express.Router();
var UserFollowerController = require('../controllers/UserFollowerController');

router.get('/follower', UserFollowerController.getFollowerList);
router.get('/following', UserFollowerController.getFollowingList);

module.exports = router;
