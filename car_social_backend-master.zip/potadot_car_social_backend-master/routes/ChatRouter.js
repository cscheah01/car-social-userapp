var express = require('express');
var router = express.Router();
var ChatController = require('../controllers/ChatController');
var ChatValidator = require('../validators/ChatValidator');

router.get('/chat-list', ChatController.getChatList);

router.get('/chat-session', ChatController.getChatSession);

router.get('/chat-content/:chatSessionId', ChatController.getChatContent);

router.get('/chat-user', ChatController.getChatUser);

router.post(
  '/:chatSessionId',
  [ChatValidator.create, ChatValidator.result],
  ChatController.create
);

module.exports = router;
