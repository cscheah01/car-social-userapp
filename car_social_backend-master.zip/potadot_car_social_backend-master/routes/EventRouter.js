var express = require('express');
var router = express.Router();
var EventController = require('../controllers/EventController');
var EventValidator = require('../validators/EventValidator');

router.post(
  '/',
  [EventValidator.create, EventValidator.result],
  EventController.create
);

router.get('/my-event', EventController.getMyEventList);

router.get('/details/:id', EventController.getSingleEvent);

router.get('/near-me', EventController.getNearMeEventList);

module.exports = router;
