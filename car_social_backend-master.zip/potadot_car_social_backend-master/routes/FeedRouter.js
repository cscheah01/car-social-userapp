var express = require('express');
var router = express.Router();
var FeedController = require('../controllers/FeedController');
var PostValidator = require('../validators/FeedValidator');

router.post(
  '/',
  [PostValidator.create, PostValidator.result],
  FeedController.create
);

router.get('/followed-user', FeedController.getFollowedUserPostList);

router.delete('/delete/:id', FeedController.delete);

router.patch(
  '/update/:id',
  [PostValidator.edit, PostValidator.result],
  FeedController.update
);

router.post('/like/:id', FeedController.like);

router.delete('/unlike/:id', FeedController.unlike);

router.get('/details/:id', FeedController.getSinglePost);

router.get('/comment/:id', FeedController.getCommentList);

router.get('/saved-post', FeedController.getSavedPostList);

router.post('/save/:id', FeedController.save);

router.delete('/unsave/:id', FeedController.unsave);

router.get('/', FeedController.getList);

router.post(
  '/comment/:id',
  // [PostValidator.createComment, PostValidator.result],
  FeedController.createComment
);

module.exports = router;
