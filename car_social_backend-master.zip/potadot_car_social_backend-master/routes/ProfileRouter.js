var express = require('express');
var router = express.Router();
var ProfileController = require('../controllers/ProfileController');
var ProfileValidator = require('../validators/ProfileValidator');

router.get('/', ProfileController.getProfileDetails);

router.patch(
  '/',
  [ProfileValidator.update, ProfileValidator.result],
  ProfileController.update
);
module.exports = router;
