var express = require('express');
var router = express.Router();
var AuthController = require('../controllers/AuthController');
var AuthValidator = require('../validators/AuthValidator');

router.post(
  '/login',
  [AuthValidator.login, AuthValidator.result],
  AuthController.login
);


router.post(
  '/register',
  [AuthValidator.register, AuthValidator.result],
  AuthController.register
);
module.exports = router;
