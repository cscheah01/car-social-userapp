import {request, multipartRequest} from './constants';

export const getFollowingList = page => {
  return request({
    url: '/user-follower/following',
    method: 'GET',
    params: {
      page: page,
    },
  });
};

export const getFollowerList = page => {
  return request({
    url: '/user-follower/follower',
    method: 'GET',
    params: {
      page: page,
    },
  });
};
