import EncryptedStorage from 'react-native-encrypted-storage';
import axios from 'axios';
import {Alert} from 'react-native';

const client = axios.create({
  baseURL: 'http://192.168.1.114:8080',
});

const apiRequest = options => {
  const onSuccess = function (response) {
    console.debug('Request Successful!', response);
    return {...response.data, status:response.status};
  };

  const onError = function (error) {
    console.error('Request Failed:', error.config);

    if (error.response) {
      console.error('Status:', error.response.status);
      console.error('Data:', error.response.data);
      console.error('Headers:', error.response.headers);
    } else {
      console.error('Error Message:', error.message);
    }

    if (error.response.status == 500) {
      Alert.alert('Server Error', error.response.data.message);
    }

    return {...error.response.data, status: error.response.status};
  };

  return client(options).then(onSuccess).catch(onError);
};

export const request = async options => {
  const userToken = await EncryptedStorage.getItem('userToken');
  options.headers = {
    Authorization: `Bearer ${userToken}`,
  };

  return apiRequest(options);
};

export const multipartRequest = async options => {
  const userToken = await EncryptedStorage.getItem('userToken');
  options.headers = {
    Authorization: `Bearer ${userToken}`,
    'Content-Type': 'multipart/form-data',
  };

  return apiRequest(options);
};
