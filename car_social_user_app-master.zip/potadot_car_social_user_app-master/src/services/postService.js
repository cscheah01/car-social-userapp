import {request, multipartRequest} from './constants';

export const createPost = data => {
  const post = new FormData();

  data.media.forEach(media => {
    post.append('media', {
      uri: media.uri,
      type: media.type,
      name: media.fileName,
    });
  });

  post.append('message', data.message);

  return multipartRequest({
    url: '/post',
    method: 'POST',
    data: post,
  });
};

export const getPost = page => {
  return request({
    url: '/post',
    method: 'GET',
    params: {
      page: page,
    },
  });
};

export const getFollowedPost = page => {
  return request({
    url: '/post/followed-user',
    method: 'GET',
    params: {
      page: page,
    },
  });
};

export const deletePost = id => {
  return request({
    url: '/post/delete/' + id,
    method: 'Delete',
  });
};

export const likePost = id => {
  return request({
    url: '/post/like/' + id,
    method: 'POST',
  });
};

export const unlikePost = id => {
  return request({
    url: '/post/unlike/' + id,
    method: 'Delete',
  });
};

export const getSinglePost = id => {
  return request({
    url: '/post/details/' + id,
    method: 'GET',
  });
};

export const getCommentList = (postId, page) => {
  return request({
    url: '/post/comment/' + postId,
    method: 'GET',
    params: {
      page: page,
    },
  });
};

export const addComment = data => {
  return request({
    url: '/post/comment/' + data.post_id,
    method: 'POST',
    data: {
      content: data.content,
    },
  });
};
