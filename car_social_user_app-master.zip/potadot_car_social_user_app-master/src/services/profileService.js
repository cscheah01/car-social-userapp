import {request, multipartRequest} from './constants';

export const getProfileDetails = () => {
  return request({
    url: '/profile/',
    method: 'GET',
  });
};

export const updateProfile = data => {
  let profileData = new FormData();

  if (data.profile_image != null) {
    profileData.append('profile_image', {
      uri: data.profile_image.uri,
      type: data.profile_image.type,
      name: data.profile_image.fileName,
    });
  }
  if (data.background_image != null) {
    profileData.append('background_image', {
      uri: data.background_image.uri,
      type: data.background_image.type,
      name: data.background_image.fileName,
    });
  }

  if (data.username != null) {
    profileData.append('username', data.username);
  }

  if (data.dob != null) {
    profileData.append('dob', data.dob);
  }

  if (data.bio != null) {
    profileData.append('bio', data.bio);
  }
  if (data.phone_no != null) {
    profileData.append('phone_no', data.phone_no);
  }

  return multipartRequest({
    url: '/profile',
    method: 'PATCH',
    data: profileData,
  });
};
