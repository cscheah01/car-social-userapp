import {request, multipartRequest} from './constants';

export const getCarBrand = () => {
  return request({
    url: '/car-brand/',
    method: 'GET',
  });
};

export const getCarBrandModel = carBrandId => {
  return request({
    url: '/car-model/' + carBrandId,
    method: 'GET',
  });
};
