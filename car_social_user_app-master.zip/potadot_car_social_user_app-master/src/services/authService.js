import {request, multipartRequest} from './constants';

export const login = data => {
  return request({
    url: '/auth/login',
    method: 'POST',
    data: {
      email: data.email,
      password: data.password,
    },
  });
};

export const register = data => {
  return request({
    url: '/auth/register',
    method: 'POST',
    data: {
      email: data.email,
      username: data.username,
      phone_no: data.phone_no,
      dob: data.dob,
      password: data.password,
      confirm_password: data.confirm_password,
      country: data.country,
    },
  });
};
