import {request, multipartRequest} from './constants';

export const createEvent = data => {
  let event = new FormData();

  if (data.cover_photo != null) {
    event.append('cover_photo', {
      uri: data.cover_photo.uri,
      type: data.cover_photo.type,
      name: data.cover_photo.fileName,
    });
  }

  event.append('title', data.title);
  event.append('start_date', data.start_date);
  event.append('end_date', data.end_date);
  event.append('location', data.location);
  event.append('description', data.description);

  return multipartRequest({
    url: '/event',
    method: 'POST',
    data: event,
  });
};

export const getMyEvent = page => {
  return request({
    url: '/event/my-event',
    method: 'GET',
    params: {
      page: page,
    },
  });
};

export const getSingleEvent = id => {
  return request({
    url: '/event/details/' + id,
    method: 'GET',
  });
};

export const getNearMeEvent = page => {
  return request({
    url: '/event/near-me',
    method: 'GET',
    params: {
      page: page,
    },
  });
};
