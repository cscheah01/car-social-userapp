import {request, multipartRequest} from './constants';

export const createGroup = data => {
  let group = new FormData();

  if (data.group_image != null) {
    group.append('group_image', {
      uri: data.group_image.uri,
      type: data.group_image.type,
      name: data.group_image.fileName,
    });
  }

  if (data.background_image != null) {
    group.append('background_image', {
      uri: data.background_image.uri,
      type: data.background_image.type,
      name: data.background_image.fileName,
    });
  }

  if (data.description != null) {
    group.append('description', data.description);
  }

  group.append('country', data.country);
  group.append('name', data.name);
  group.append('is_private', data.is_private);

  return multipartRequest({
    url: '/group/create',
    method: 'POST',
    data: group,
  });
};

export const getMyGroup = page => {
  return request({
    url: '/group/my-group',
    method: 'GET',
    params: {
      page: page,
    },
  });
};

export const getNearMeGroup = page => {
  return request({
    url: '/group/near-me',
    method: 'GET',
    params: {
      page: page,
    },
  });
};

export const deleteGroup = id => {
  return request({
    url: '/group/' + id,
    method: 'Delete',
  });
};

export const getSingleGroup = id => {
  return request({
    url: '/group/details/' + id,
    method: 'GET',
  });
};

export const getMemberRequest = (groupId, page) => {
  return request({
    url: '/group/member-request/' + groupId,
    method: 'GET',
    params: {
      page: page,
    },
  });
};

export const getTotalMemberRequest = groupId => {
  return request({
    url: '/group/total-member-request/' + groupId,
    method: 'GET',
  });
};

export const acceptRequest = (userId, groupId) => {
  return request({
    url: '/group/accept-request/' + userId,
    method: 'PATCH',
    params: {
      groupId: groupId,
    },
  });
};

export const declineRequest = (userId, groupId) => {
  return request({
    url: '/group/decline-request/' + userId,
    method: 'PATCH',
    params: {
      groupId: groupId,
    },
  });
};

export const getGroupDetails = id => {
  return request({
    url: '/group/group-setting/' + id,
    method: 'GET',
  });
};

export const updateGroupDetails = (data, id) => {
  let groupData = new FormData();

  if (data.group_image != null) {
    groupData.append('group_image', {
      uri: data.group_image.uri,
      type: data.group_image.type,
      name: data.group_image.fileName,
    });
  }
  if (data.background_image != null) {
    groupData.append('background_image', {
      uri: data.background_image.uri,
      type: data.background_image.type,
      name: data.background_image.fileName,
    });
  }

  if (data.name != null) {
    groupData.append('name', data.name);
  }

  if (data.description != null) {
    groupData.append('description', data.description);
  }
  if (data.country != null) {
    groupData.append('country', data.country);
  }

  if (data.is_private != null) {
    groupData.append('is_private', data.is_private);
  }

  return multipartRequest({
    url: '/group/group-details/' + id,
    method: 'PATCH',
    data: groupData,
  });
};
