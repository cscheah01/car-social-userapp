import {request, multipartRequest} from './constants';

export const getGarage = page => {
  return request({
    url: '/garage',
    method: 'GET',
    params: {
      page: page,
    },
  });
};

export const createVehicle = data => {
  const vehicle = new FormData();

  vehicle.append('image', {
    uri: data.image.uri,
    type: data.image.type,
    name: data.image.fileName,
  });

  vehicle.append('car_model_id', data.car_model_id);

  vehicle.append('year', data.year);

  return multipartRequest({
    url: '/garage',
    method: 'POST',
    data: vehicle,
  });
};
