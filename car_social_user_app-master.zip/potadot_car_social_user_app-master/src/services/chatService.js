import {request, multipartRequest} from './constants';

export const getChatList = page => {
  return request({
    url: '/chat/chat-list',
    method: 'GET',
    params: {
      page: page,
    },
  });
};

export const getChatContent = (chat_session_id, page) => {
  return request({
    url: '/chat/chat-content/' + chat_session_id,
    method: 'GET',
    params: {
      page: page,
    },
  });
};

export const sendChatContent = (data, chat_session_id) => {
  return request({
    url: '/chat/' + chat_session_id,
    method: 'POST',
    data: {content: data},
  });
};

export const getChatUser = data => {
  return request({
    url: '/chat/chat-user',
    method: 'GET',
    params: {
      username: data,
    },
  });
};

export const getChatSession = receiverUserId => {
  return request({
    url: '/chat/chat-session',
    method: 'GET',
    params: {
      receiverUserId: receiverUserId,
    },
  });
};
