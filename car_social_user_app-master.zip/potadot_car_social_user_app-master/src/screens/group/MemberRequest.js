import React from 'react';
import {SafeAreaView, StyleSheet, ScrollView} from 'react-native';
import Header from '../../components/groupScreen/singleGroup/manage/memberRequest/Header';
import MemberRequestDetails from '../../components/groupScreen/singleGroup/manage/memberRequest/MemberRequestDetails';

export default function ({route, params}) {
  return (
    <SafeAreaView style={styles.screen}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <Header />
        <MemberRequestDetails
          groupId={route.params.groupId}
          totalRequest={route.params.totalRequest}
        />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
  },
});
