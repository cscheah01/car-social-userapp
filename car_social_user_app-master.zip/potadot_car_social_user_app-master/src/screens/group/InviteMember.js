import React, {useRef} from 'react';
import {SafeAreaView, StyleSheet, FlatList} from 'react-native';
import {normalize} from '../../utils/Helper';
import SearchInput from '../../components/groupScreen/inviteMember/SearchInput';
import User from '../../components/groupScreen/inviteMember/User';
import ShareModalize from '../../components/groupScreen/inviteMember/ShareModalize';
const demoData = [
  {
    id: 1,
    name: 'ImNobody',
    bio: 'Hi,This is my first account',
    image:
      'https://cdn2.f-cdn.com/contestentries/1739341/33559215/5e531116c4bd0_thumb900.jpg',
  },
  {
    id: 2,
    name: 'ImNobody123',
    bio: 'Hi,This is my second account1231231231231321',
    image:
      'https://cdn2.f-cdn.com/contestentries/1739341/33559215/5e531116c4bd0_thumb900.jpg',
  },
  {
    id: 3,
    name: 'Testing',
    bio: 'Hi,This is my third account',
    image:
      'https://cdn2.f-cdn.com/contestentries/1739341/33559215/5e531116c4bd0_thumb900.jpg',
  },
  {
    id: 4,
    name: 'Testing',
    bio: 'Hi,This is my third account',
    image:
      'https://cdn2.f-cdn.com/contestentries/1739341/33559215/5e531116c4bd0_thumb900.jpg',
  },
  {
    id: 5,
    name: 'Testing',
    bio: 'Hi,This is my third account',
    image:
      'https://cdn2.f-cdn.com/contestentries/1739341/33559215/5e531116c4bd0_thumb900.jpg',
  },
  {
    id: 6,
    name: 'Testing',
    bio: 'Hi,This is my third account',
    image:
      'https://cdn2.f-cdn.com/contestentries/1739341/33559215/5e531116c4bd0_thumb900.jpg',
  },
  {
    id: 7,
    name: 'Testing',
    bio: 'Hi,This is my third account',
    image:
      'https://cdn2.f-cdn.com/contestentries/1739341/33559215/5e531116c4bd0_thumb900.jpg',
  },
];
export default function InviteMemberScreen() {
  const shareModalizeRef = useRef(null);
  return (
    <SafeAreaView style={styles.screen}>
      <FlatList
        ListHeaderComponent={
          <SearchInput
            openShareModalize={() => {
              shareModalizeRef.current?.open();
            }}
          />
        }
        showsVerticalScrollIndicator={false}
        data={demoData}
        style={styles.mainWrapper}
        keyExtractor={item => item.id}
        renderItem={({item}) => <User data={item} />}
      />
      <ShareModalize shareModalizeRef={shareModalizeRef} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
  },
  mainWrapper: {
    paddingVertical: normalize(10),
  },
});
