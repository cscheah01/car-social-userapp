import React, {useState, useEffect, useRef} from 'react';
import {SafeAreaView, StyleSheet, ScrollView, Text, Alert} from 'react-native';
import {getGroupDetails, updateGroupDetails} from '../../services/groupService';
import GroupSettingDetails from '../../components/groupScreen/singleGroup/manage/groupSetting/GroupSettingDetails';
import Header from '../../components/groupScreen/singleGroup/manage/groupSetting/Header';
import ImagePickerOptionModalize from '../../components/ImagePickerModalize/ImagePickerOptionModalize';

export default function ({route, params}) {
  const [groupDetails, setGroupDetails] = useState(null);
  const [imageType, setImageType] = useState(null);
  const imagePickerOptionModalizeRef = useRef(null);
  const [isLoading, setIsLoading] = useState(true);

  const inputData = {
    name: null,
    group_image: null,
    background_image: null,
    description: null,
    country: null,
    is_private: null,
  };

  useEffect(() => {
    async function fetchData() {
      setIsLoading(true);
      let response = await getGroupDetails(route.params.groupId);
      setGroupDetails(response.data);
      setIsLoading(false);
    }

    fetchData();
  }, [route.params]);

  const onSubmitEditImage = async () => {
    let response = await updateGroupDetails(inputData, route.params.groupId);

    if (response.status == 200 && response.success) {
      if (imageType == 'group_image') {
        setGroupDetails({
          ...groupDetails,
          group_image: response.data.group_image,
        });
      } else if (imageType == 'background_image') {
        setGroupDetails({
          ...groupDetails,
          background_image: response.data.background_image,
        });
      }
    } else if (response.status == 422) {
      if (imageType == 'group_image') {
        Alert.alert('Edit Group Image Failed', JSON.stringify(response.error));
      } else if (imageType == 'background_image') {
        Alert.alert(
          'Edit Group Background Image Failed',
          JSON.stringify(response.error),
        );
      }
    }
  };

  return (
    <>
      {isLoading ? (
        <Text style={styles.loading}>Loading...</Text>
      ) : (
        <>
          <SafeAreaView style={styles.screen}>
            <Header />
            <ScrollView showsVerticalScrollIndicator={false}>
              <GroupSettingDetails
                data={groupDetails}
                openImagePickerOptionModalize={() => {
                  imagePickerOptionModalizeRef.current?.open();
                }}
                setImageType={value => {
                  setImageType(value);
                }}
              />
            </ScrollView>
            <ImagePickerOptionModalize
              imagePickerOptionModalizeRef={imagePickerOptionModalizeRef}
              setData={value => {
                if (imageType == 'group_image') {
                  inputData.group_image = value;
                  onSubmitEditImage();
                } else if (imageType == 'background_image') {
                  inputData.background_image = value;
                  onSubmitEditImage();
                }
              }}
            />
          </SafeAreaView>
        </>
      )}
    </>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
  },
});
