import React, {useState} from 'react';
import {SafeAreaView, StyleSheet, Alert} from 'react-native';
import {normalize} from '../../utils/Helper';
import Form from '../../components/groupScreen/singleGroup/manage/groupSetting/EditPrivacy/EditPrivacyForm';
import Header from '../../components/groupScreen/singleGroup/manage/groupSetting/EditPrivacy/EditPrivacyHeader';
import {updateGroupDetails} from '../../services/groupService';
import {useNavigation} from '@react-navigation/native';

export default function ({route, params}) {
  const navigation = useNavigation();
  const [inputData, setInputData] = useState({
    name: null,
    group_image: null,
    background_image: null,
    description: null,
    country: null,
    is_private: route.params.is_private,
  });

  const onSubmitEditPrivacy = async () => {
    let response = await updateGroupDetails(inputData, route.params.groupId);

    if (response.status == 200 && response.success) {
      navigation.navigate('GroupSetting', {
        editDetail: inputData.is_private,
        groupId: route.params.groupId,
      });
    } else if (response.status == 422) {
      Alert.alert('Edit Group Privacy Failed', JSON.stringify(response.error));
    }
  };

  return (
    <SafeAreaView style={styles.screen}>
      <Header onSubmitEditPrivacy={onSubmitEditPrivacy} />
      <Form
        inputData={inputData.is_private}
        setInputData={value => {
          setInputData(value);
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
    padding: normalize(10),
    marginBottom: normalize(10),
  },
});
