import React, {useState} from 'react';
import {SafeAreaView, StyleSheet, Alert} from 'react-native';
import {normalize} from '../../utils/Helper';
import Form from '../../components/groupScreen/singleGroup/manage/groupSetting/EditDescription/EditDescriptionForm';
import Header from '../../components/groupScreen/singleGroup/manage/groupSetting/EditDescription/EditDescriptionHeader';
import {updateGroupDetails} from '../../services/groupService';
import {useNavigation} from '@react-navigation/native';

export default function ({route, params}) {
  const navigation = useNavigation();
  const [inputData, setInputData] = useState({
    name: null,
    group_image: null,
    background_image: null,
    description: route.params.description,
    country: null,
    is_private: null,
  });

  const onSubmitEditDescription = async () => {
    let response = await updateGroupDetails(inputData, route.params.groupId);

    if (response.status == 200 && response.success) {
      navigation.navigate('GroupSetting', {
        editDetail: inputData.description,
        groupId: route.params.groupId,
      });
    } else if (response.status == 422) {
      Alert.alert(
        'Edit Group Description Failed',
        JSON.stringify(response.error),
      );
    }
  };

  return (
    <SafeAreaView style={styles.screen}>
      <Header onSubmitEditDescription={onSubmitEditDescription} />
      <Form
        inputData={inputData.description}
        setInputData={value => {
          setInputData(value);
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
    padding: normalize(10),
    marginBottom: normalize(10),
  },
});
