import React, {useState} from 'react';
import {SafeAreaView, StyleSheet, Alert} from 'react-native';
import {normalize} from '../../utils/Helper';
import Form from '../../components/groupScreen/singleGroup/manage/groupSetting/EditName/EditNameForm';
import Header from '../../components/groupScreen/singleGroup/manage/groupSetting/EditName/EditNameHeader';
import {updateGroupDetails} from '../../services/groupService';
import {useNavigation} from '@react-navigation/native';

export default function ({route, params}) {
  const navigation = useNavigation();
  const [inputData, setInputData] = useState({
    name: route.params.name,
    group_image: null,
    background_image: null,
    description: null,
    country: null,
    is_private: null,
  });

  const [inputError, setInputError] = useState({name: null});

  const onSubmitEditName = async () => {
    let error = {};
    if (inputData.name == '') {
      error = {...error, name: 'Name is required.'};
    }
    setInputError(error);
    if (Object.keys(error).length === 0) {
      let response = await updateGroupDetails(inputData, route.params.groupId);

      if (response.status == 200 && response.success) {
        navigation.navigate('GroupSetting', {
          editDetail: inputData.name,
          groupId: route.params.groupId,
        });
      } else if (response.status == 422) {
        setInputError({name: response.error[0].msg});
      }
    }
  };

  return (
    <SafeAreaView style={styles.screen}>
      <Header onSubmitEditName={onSubmitEditName} />
      <Form
        inputData={inputData.name}
        inputError={inputError.name}
        setInputData={value => {
          setInputData(value);
        }}
        setInputError={value => {
          setInputError(value);
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
    padding: normalize(10),
    marginBottom: normalize(10),
  },
});
