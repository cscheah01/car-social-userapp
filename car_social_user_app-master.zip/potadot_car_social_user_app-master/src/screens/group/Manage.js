import React from 'react';
import {SafeAreaView, StyleSheet, ScrollView} from 'react-native';
import Header from '../../components/groupScreen/singleGroup/manage/Header';
import ManageDetails from '../../components/groupScreen/singleGroup/manage/ManageDetails';

export default function ({route, params}) {
  return (
    <SafeAreaView style={styles.screen}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <Header groupName={route.params.groupName} />
        <ManageDetails groupId={route.params.groupId} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
  },
});
