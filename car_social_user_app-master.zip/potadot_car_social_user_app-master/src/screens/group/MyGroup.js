import React, {useState, useEffect} from 'react';
import {SafeAreaView, StyleSheet, FlatList} from 'react-native';
import Group from '../../components/groupScreen/myGroup/Group';
import {normalize} from '../../utils/Helper';
import {getMyGroup} from '../../services/groupService';
import {P, H5} from '../../components/common/Typography';

export default function MyGroupScreen() {
  const [page, setPage] = useState(1);

  const [groups, setGroups] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [disableLoading, setDisableLoading] = useState(false);

  const loadMore = () => {
    setPage(page + 1);
  };

  useEffect(() => {
    async function fetchData() {
      setIsLoading(true);
      let response = await getMyGroup(page);
      if (response.data.length == 0) {
        setDisableLoading(true);
      } else {
        if (groups == null) {
          setGroups(response.data);
        } else {
          setGroups([...groups, ...response.data]);
        }
      }
      setIsLoading(false);
    }

    fetchData();
  }, [page]);
  return (
    <SafeAreaView style={styles.screen}>
      {groups == '' ? (
        <H5 style={styles.emptyData}>You not join or create any group</H5>
      ) : null}
      <FlatList
        showsVerticalScrollIndicator={false}
        data={groups}
        style={styles.mainWrapper}
        keyExtractor={item => item.id}
        renderItem={({item}) => <Group data={item} />}
        onEndReached={disableLoading == true ? null : loadMore}
      />
      {isLoading == true ? <P style={styles.loading}>Loading...</P> : <></>}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
  },
  mainWrapper: {
    paddingVertical: normalize(10),
  },
  loading: {
    color: '#ffffff',
    textAlign: 'center',
  },
  emptyData: {
    color: '#808080',
    alignSelf: 'center',
    marginVertical: normalize(50),
  },
});
