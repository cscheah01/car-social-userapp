import React, {useState, useEffect} from 'react';
import {
  SafeAreaView,
  StyleSheet,
  View,
  ScrollView,
  FlatList,
} from 'react-native';
import {normalize} from '../../utils/Helper';
import Header from '../../components/groupScreen/singleGroup/Header';
import Intro from '../../components/groupScreen/singleGroup/Intro';
import Description from '../../components/groupScreen/singleGroup/Description';
import Button from '../../components/groupScreen/singleGroup/Button';
import CreateGroupPost from '../../components/groupScreen/singleGroup/CreateGroupPost';
import Post from '../../components/post/Post';
import {getSingleGroup} from '../../services/groupService';

const demoData = [
  {
    key: 1,
    username: 'Username',
    createdAt: '22-10-2022',
    profilePicture:
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSzHQv_th9wq3ivQ1CVk7UZRxhbPq64oQrg5Q&usqp=CAU',
    media: [
      {
        url: 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8Y2FyfGVufDB8fDB8fA%3D%3D&w=1000&q=80',
        type: 'image',
      },
      {
        url: 'https://ichef.bbci.co.uk/news/976/cpsprodpb/C448/production/_117684205_lotus.jpg',
        type: 'image',
      },
      {
        url: 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8Y2FyfGVufDB8fDB8fA%3D%3D&w=1000&q=80',
        type: 'image',
      },
      {
        url: 'https://ichef.bbci.co.uk/news/976/cpsprodpb/C448/production/_117684205_lotus.jpg',
        type: 'image',
      },
      {
        url: 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8Y2FyfGVufDB8fDB8fA%3D%3D&w=1000&q=80',
        type: 'image',
      },
    ],
    content:
      'Lorem Ipsum is simply dummy text of the printing and type setting industry.',
    likeCount: 10,
    commentCount: 10,
  },
  {
    key: 2,
    username: 'Username',
    createdAt: '22-10-2022',
    profilePicture:
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSzHQv_th9wq3ivQ1CVk7UZRxhbPq64oQrg5Q&usqp=CAU',
    media: [
      {
        url: 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8Y2FyfGVufDB8fDB8fA%3D%3D&w=1000&q=80',
        type: 'image',
      },
      {
        url: 'https://ichef.bbci.co.uk/news/976/cpsprodpb/C448/production/_117684205_lotus.jpg',
        type: 'image',
      },
      {
        url: 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8Y2FyfGVufDB8fDB8fA%3D%3D&w=1000&q=80',
        type: 'image',
      },
      {
        url: 'https://ichef.bbci.co.uk/news/976/cpsprodpb/C448/production/_117684205_lotus.jpg',
        type: 'image',
      },
      {
        url: 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8Y2FyfGVufDB8fDB8fA%3D%3D&w=1000&q=80',
        type: 'image',
      },
    ],
    content:
      'Lorem Ipsum is simply dummy text of the printing and type setting industry.',
    likeCount: 10,
    commentCount: 10,
  },
  {
    key: 3,
    username: 'Username',
    createdAt: '22-10-2022',
    profilePicture:
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSzHQv_th9wq3ivQ1CVk7UZRxhbPq64oQrg5Q&usqp=CAU',
    media: [
      {
        url: 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8Y2FyfGVufDB8fDB8fA%3D%3D&w=1000&q=80',
        type: 'image',
      },
      {
        url: 'https://ichef.bbci.co.uk/news/976/cpsprodpb/C448/production/_117684205_lotus.jpg',
        type: 'image',
      },
      {
        url: 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8Y2FyfGVufDB8fDB8fA%3D%3D&w=1000&q=80',
        type: 'image',
      },
      {
        url: 'https://ichef.bbci.co.uk/news/976/cpsprodpb/C448/production/_117684205_lotus.jpg',
        type: 'image',
      },
      {
        url: 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8Y2FyfGVufDB8fDB8fA%3D%3D&w=1000&q=80',
        type: 'image',
      },
    ],
    content:
      'Lorem Ipsum is simply dummy text of the printing and type setting industry.',
    likeCount: 10,
    commentCount: 10,
  },
];

export default function ({route, params}) {
  const [groupId, setGroupId] = useState(route.params.groupId);
  const [singleGroup, setSingleGroup] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [comfirmationVisible, setcomfirmationVisible] = useState(false);

  useEffect(() => {
    setIsLoading(true);

    async function fetchData() {
      const response = await getSingleGroup(groupId);
      setSingleGroup(response.data);

      setIsLoading(false);
    }

    fetchData();
  }, [groupId]);

  return (
    <>
      {isLoading ? (
        <></>
      ) : (
        <SafeAreaView style={styles.screen}>
          <ScrollView
            showsVerticalScrollIndicator={false}
            nestedScrollEnabled={true}>
            <View style={styles.mainWrapper}>
              <Header />
              <Intro data={singleGroup} />
              <Description data={singleGroup} />
              <Button />
              <CreateGroupPost />
              <FlatList
                showsVerticalScrollIndicator={false}
                data={demoData}
                keyExtractor={item => item.key}
                renderItem={({item}) => (
                  <Post
                    data={item}
                    comfirmationVisible={comfirmationVisible}
                    setcomfirmationVisible={value => {
                      setcomfirmationVisible(value);
                    }}
                    postModalize={() => {
                      postModalizeRef.current?.open();
                    }}
                  />
                )}
              />
            </View>
          </ScrollView>
        </SafeAreaView>
      )}
    </>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
    height: '40%',
  },
  mainWrapper: {
    paddingVertical: normalize(0),
  },
});
