import React, {useState, useEffect, useRef} from 'react';
import {SafeAreaView, StyleSheet, ScrollView, Alert} from 'react-native';
import {normalize} from '../../utils/Helper';
import ImageAndVideoSelector from '../../components/feedScreen/createPost/ImageAndVideoSelector';
import PostMessage from '../../components/feedScreen/createPost/PostMessage';
import CreatePostHeader from '../../components/feedScreen/createPost/CreatePostHeader';
import {createPost} from '../../services/postService';
import {useNavigation} from '@react-navigation/native';
import ImagePickerOptionModalize from '../../components/feedScreen/createPost/ImagePickerOptionModalize';

export default function CreatePostScreen() {
  const navigation = useNavigation();

  const [postData, setPostData] = useState({media: [], message: null});
  const [disabledSubmit, setDisabledSubmit] = useState(true);
  const imagePickerOptionModalizeRef = useRef(null);

  useEffect(() => {
    setDisabledSubmit(true);

    if (postData.media.length > 0 && postData.message) {
      setDisabledSubmit(false);
    }
  }, [postData]);

  const onSubmitCreatePost = async () => {
    const response = await createPost(postData);

    if (response.status == 200 && response.success) {
      navigation.goBack();
    } else if (response.status == 422) {
      Alert.alert('Create Post Failed', JSON.stringify(response.error));
    }
  };

  return (
    <SafeAreaView style={styles.screen}>
      <CreatePostHeader
        disabledSubmit={disabledSubmit}
        submitCreatePost={onSubmitCreatePost}
      />
      <ScrollView
        showsVerticalScrollIndicator={false}
        style={styles.mainWrapper}>
        <ImageAndVideoSelector
          selectedData={postData.media}
          setPostData={value => {
            setPostData({...postData, media: value});
          }}
          openImagePickerOptionModalize={() => {
            imagePickerOptionModalizeRef.current?.open();
          }}
        />
        <PostMessage
          selectedData={postData.media}
          setPostData={value => {
            setPostData({...postData, message: value});
          }}
        />
      </ScrollView>
      <ImagePickerOptionModalize
        imagePickerOptionModalizeRef={imagePickerOptionModalizeRef}
        selectedData={postData.media}
        setPostData={value => {
          setPostData({...postData, media: value});
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
  },
  mainWrapper: {
    paddingVertical: normalize(10),
  },
});
