import React, {useEffect, useState} from 'react';
import {SafeAreaView, StyleSheet, FlatList, Text} from 'react-native';
import Post from '../../components/feedScreen/singlePost/Post';
import CommentList from '../../components/feedScreen/singlePost/CommentList';
import CommentInput from '../../components/feedScreen/singlePost/CommentInput';
import {normalize} from '../../utils/Helper';
import {getSinglePost, getCommentList} from '../../services/postService';
import Header from '../../components/feedScreen/singlePost/SinglePostHeader';

export default function SinglePostScreen({route, params}) {
  const [isLoading, setIsLoading] = useState(true);
  const [postId, setPostId] = useState(route.params.postId);
  const [singlePost, setSinglePost] = useState(null);
  const [page, setPage] = useState(1);
  const [commentList, setCommentList] = useState(null);
  const [isLoadingComment, setIsLoadingComment] = useState(true);
  const [disableLoading, setDisableLoading] = useState(false);

  const loadMore = () => {
    setPage(page + 1);
  };

  useEffect(() => {
    setIsLoading(true);

    async function fetchData() {
      const response = await getSinglePost(postId);
      setSinglePost(response.data);

      setIsLoading(false);
    }

    fetchData();
  }, [postId]);

  useEffect(() => {
    setIsLoadingComment(true);

    async function fetchCommentData() {
      const response = await getCommentList(postId, page);

      if (response.data.length == 0) {
        setDisableLoading(true);
      } else {
        if (commentList == null) {
          setCommentList(response.data);
        } else {
          setCommentList([...commentList, ...response.data]);
        }
      }

      setIsLoadingComment(false);
    }

    fetchCommentData();
  }, [page]);

  return (
    <>
      {isLoading ? (
        <></>
      ) : (
        <SafeAreaView style={styles.screen}>
          <Header data={singlePost} />
          <FlatList
            showsVerticalScrollIndicator={false}
            data={commentList}
            style={styles.mainWrapper}
            keyExtractor={item => item.id}
            renderItem={({item}) => <CommentList data={item} />}
            ListHeaderComponent={<Post data={singlePost} />}
            onEndReached={disableLoading == true ? null : loadMore}
          />
          {isLoadingComment == true ? (
            <Text style={styles.loading}>Loading...</Text>
          ) : (
            <></>
          )}
          <CommentInput data={postId} />
        </SafeAreaView>
      )}
    </>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
    paddingBottom: normalize(45),
  },
  mainWrapper: {
    paddingVertical: normalize(10),
  },
  loading: {
    color: '#ffffff',
    textAlign: 'center',
    marginBottom: normalize(5),
  },
});
