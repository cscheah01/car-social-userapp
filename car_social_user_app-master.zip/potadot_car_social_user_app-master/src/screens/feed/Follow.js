import React, {useEffect, useState, useRef} from 'react';
import {SafeAreaView, StyleSheet, FlatList} from 'react-native';
import {normalize} from '../../utils/Helper';
import Post from '../../components/post/Post';
import {P, H5} from '../../components/common/Typography';
import {getFollowedPost} from '../../services/postService';

export default function FollowScreen() {
  const [followedpage, setFollowedpage] = useState(1);

  const [followedPost, setFollowedPost] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const postModalizeRef = useRef(null);
  const [comfirmationVisible, setcomfirmationVisible] = useState(false);
  const [disableLoading, setDisableLoading] = useState(false);

  const loadMore = () => {
    setFollowedpage(followedpage + 1);
  };

  useEffect(() => {
    async function fetchData() {
      setIsLoading(true);
      let response = await getFollowedPost(followedpage);
      if (response.data.length == 0) {
        setDisableLoading(true);
      } else {
        if (followedPost == '') {
          setFollowedPost(response.data);
        } else {
          setFollowedPost([...followedPost, ...response.data]);
        }
      }
      setIsLoading(false);
    }

    fetchData();
  }, [followedpage]);

  return (
    <SafeAreaView style={styles.screen}>
      {followedPost == '' ? (
        <H5 style={styles.emptyData}>There is no any follower post</H5>
      ) : null}
      <FlatList
        showsVerticalScrollIndicator={false}
        data={followedPost}
        style={styles.mainWrapper}
        keyExtractor={item => item.id}
        renderItem={({item}) => (
          <Post
            data={item}
            comfirmationVisible={comfirmationVisible}
            setcomfirmationVisible={value => {
              setcomfirmationVisible(value);
            }}
            postModalize={() => {
              postModalizeRef.current?.open();
            }}
          />
        )}
        onEndReached={disableLoading == true ? null : loadMore}
      />
      {isLoading == true ? <P style={styles.loading}>Loading...</P> : <></>}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
  },
  mainWrapper: {
    paddingVertical: normalize(10),
  },
  loading: {
    color: '#ffffff',
    textAlign: 'center',
  },
  emptyData: {
    color: '#808080',
    alignSelf: 'center',
    marginVertical: normalize(50),
  },
});
