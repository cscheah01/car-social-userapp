import React from 'react';
import {SafeAreaView, StyleSheet, ScrollView, View} from 'react-native';
import {normalize} from '../../utils/Helper';
import {H1} from '../../components/common/Typography';
import LoginForm from '../../components/authScreen/login/LoginForm';

export default function LoginScreen() {
  return (
    <SafeAreaView>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollView}>
        <View style={styles.mainWrapper}>
          <View style={styles.content}>
            <H1 style={styles.title}>Car Social</H1>
            <LoginForm />
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  scrollView: {
    flexGrow: 1,
    height: '100%',
  },
  mainWrapper: {
    flex: 1,
    backgroundColor: '#000000',
    justifyContent: 'center',
    alignItems: 'center',
    padding: normalize(10),
  },
  content: {
    width: '100%',
  },
  title: {
    marginBottom: normalize(30),
    textAlign: 'center',
  },
});
