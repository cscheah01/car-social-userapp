import React from 'react';
import {SafeAreaView, StyleSheet, ScrollView, View} from 'react-native';
import {normalize} from '../../utils/Helper';
import {H1} from '../../components/common/Typography';
import RegisterForm from '../../components/authScreen/register/RegisterForm';

export default function RegisterScreen() {
  return (
    <SafeAreaView>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollView}>
        <View style={styles.mainWrapper}>
          <View style={styles.content}>
            <H1 style={styles.title}>Register</H1>
            <RegisterForm />
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  scrollView: {
    flexGrow: 1,
    minHeight: '100%',
  },
  mainWrapper: {
    flex: 1,
    backgroundColor: '#000000',
    justifyContent: 'center',
    alignItems: 'center',
    padding: normalize(10),
  },
  content: {
    width: '100%',
  },
  title: {
    marginBottom: normalize(30),
    textAlign: 'center',
  },
});
