import React, {useState, useEffect} from 'react';
import {SafeAreaView, StyleSheet, FlatList} from 'react-native';
import User from '../../components/profileScreen/followerAndFollowing/User';
import {normalize} from '../../utils/Helper';
import {getFollowingList} from '../../services/userFollowerService';
import {P} from '../../components/common/Typography';

export default function () {
  const [page, setPage] = useState(1);

  const [following, setFollowing] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [disableLoading, setDisableLoading] = useState(false);

  const loadMore = () => {
    setPage(page + 1);
  };

  useEffect(() => {
    async function fetchData() {
      setIsLoading(true);
      let response = await getFollowingList(page);
      if (response.data.length == 0) {
        setDisableLoading(true);
      } else {
        if (following == null) {
          setFollowing(response.data);
        } else {
          setFollowing([...following, ...response.data]);
        }
      }

      setIsLoading(false);
    }

    fetchData();
  }, [page]);
  return (
    <SafeAreaView style={styles.screen}>
      <FlatList
        showsVerticalScrollIndicator={false}
        keyExtractor={item => item.id}
        data={following}
        style={styles.mainWrapper}
        renderItem={({item}) => <User isFollowing={true} data={item} />}
        onEndReached={disableLoading == true ? null : loadMore}
      />
      {isLoading == true ? <P style={styles.loading}>Loading...</P> : <></>}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
  },
  mainWrapper: {
    paddingVertical: normalize(10),
  },
  loading: {
    color: '#ffffff',
    textAlign: 'center',
  },
});
