import React, {useState} from 'react';
import {SafeAreaView, StyleSheet, Alert} from 'react-native';
import Form from '../../components/profileScreen/details/EditBio/EditBioForm';
import Header from '../../components/profileScreen/details/EditBio/EditBioHeader';
import {updateProfile} from '../../services/profileService';
import {useNavigation} from '@react-navigation/native';

export default function ({route, params}) {
  const navigation = useNavigation();
  const [inputData, setInputData] = useState({
    username: null,
    profile_image: null,
    background_image: null,
    dob: null,
    bio: route.params.bio,
    phone_no: null,
  });

  const onSubmitEditBio = async () => {
    let response = await updateProfile(inputData);

    if (response.status == 200 && response.success) {
      navigation.navigate('Details', {
        editDetail: inputData.bio,
      });
    } else if (response.status == 422) {
      Alert.alert('Edit Bio Failed', JSON.stringify(response.error));
    }
  };

  return (
    <SafeAreaView style={styles.screen}>
      <Header onSubmitEditBio={onSubmitEditBio} />
      <Form
        inputData={inputData.bio}
        setInputData={value => {
          setInputData(value);
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
  },
});
