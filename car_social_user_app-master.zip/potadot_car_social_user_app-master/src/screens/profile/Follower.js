import React, {useState, useEffect} from 'react';
import {SafeAreaView, StyleSheet, FlatList} from 'react-native';
import User from '../../components/profileScreen/followerAndFollowing/User';
import {normalize} from '../../utils/Helper';
import {getFollowerList} from '../../services/userFollowerService';
import {P} from '../../components/common/Typography';

export default function () {
  const [page, setPage] = useState(1);

  const [follower, setFollower] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [disableLoading, setDisableLoading] = useState(false);

  const loadMore = () => {
    setPage(page + 1);
  };

  useEffect(() => {
    async function fetchData() {
      setIsLoading(true);
      let response = await getFollowerList(page);
      if (response.data.length == 0) {
        setDisableLoading(true);
      } else {
        if (follower == null) {
          setFollower(response.data);
        } else {
          setFollower([...follower, ...response.data]);
        }
      }

      setIsLoading(false);
    }

    fetchData();
  }, [page]);

  return (
    <SafeAreaView style={styles.screen}>
      <FlatList
        showsVerticalScrollIndicator={false}
        keyExtractor={item => item.id}
        data={follower}
        style={styles.mainWrapper}
        renderItem={({item}) => <User isFollowing={false} data={item} />}
        onEndReached={disableLoading == true ? null : loadMore}
      />
      {isLoading == true ? <P style={styles.loading}>Loading...</P> : <></>}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
  },
  mainWrapper: {
    paddingVertical: normalize(10),
  },
  loading: {
    color: '#ffffff',
    textAlign: 'center',
  },
});
