import React, {useState, useRef} from 'react';
import {SafeAreaView, StyleSheet, ScrollView} from 'react-native';
import {normalize} from '../../utils/Helper';
import AddVehicleFormTwo from '../../components/profileScreen/garages/AddVehicleFormTwo';
import ImagePickerOptionModalize from '../../components/ImagePickerModalize/ImagePickerOptionModalize';

export default function AddVehicleScreenTwo({route, params}) {
  const [dataFormOne, setDataFormOne] = useState(route.params);
  const imagePickerOptionModalizeRef = useRef(null);

  return (
    <SafeAreaView style={styles.screen}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <AddVehicleFormTwo
          data={dataFormOne}
          openImagePickerOptionModalize={() => {
            imagePickerOptionModalizeRef.current?.open();
          }}
        />
      </ScrollView>
      <ImagePickerOptionModalize
        imagePickerOptionModalizeRef={imagePickerOptionModalizeRef}
        setData={value => {
          setDataFormOne({...dataFormOne, image: value});
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
    padding: normalize(10),
  },
});
