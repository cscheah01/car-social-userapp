import React, {useState} from 'react';
import {SafeAreaView, StyleSheet, Alert} from 'react-native';
import Form from '../../components/profileScreen/details/EditPhoneNumber/EditPhoneNumberForm';
import Header from '../../components/profileScreen/details/EditPhoneNumber/EditPhoneNumberHeader';
import {useNavigation} from '@react-navigation/native';
import {updateProfile} from '../../services/profileService';

export default function ({route, params}) {
  const navigation = useNavigation();
  const [inputData, setInputData] = useState({
    username: null,
    profile_image: null,
    background_image: null,
    dob: null,
    bio: null,
    phone_no: route.params.phone_no,
  });
  const [inputError, setInputError] = useState({phone_no: null});

  const onSubmitEditPhoneNumber = async () => {
    let error = {};
    if (inputData.phone_no == '') {
      error = {...error, phone_no: 'Phone Number is required.'};
    }
    setInputError(error);
    if (Object.keys(error).length === 0) {
      let response = await updateProfile(inputData);

      if (response.status == 200 && response.success) {
        navigation.navigate('Details', {
          editDetail: inputData.phone_no,
        });
      } else if (response.status == 422) {
        setInputError({phone_no: response.error[0].msg});
      }
    }
  };

  return (
    <SafeAreaView style={styles.screen}>
      <Header onSubmitEditPhoneNumber={onSubmitEditPhoneNumber} />
      <Form
        inputData={inputData.phone_no}
        inputError={inputError.phone_no}
        setInputData={value => {
          setInputData(value);
        }}
        setInputError={value => {
          setInputError(value);
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
  },
});
