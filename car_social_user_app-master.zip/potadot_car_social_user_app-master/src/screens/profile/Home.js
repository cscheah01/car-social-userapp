import React, {useRef, useState, useEffect} from 'react';
import {SafeAreaView, StyleSheet, View, Alert} from 'react-native';
import {normalize} from '../../utils/Helper';
import Header from '../../components/profileScreen/home/Header';
import SettingModalize from '../../components/profileScreen/home/SettingModalize';
import {getProfileDetails} from '../../services/profileService';
import {ScrollView} from 'react-native-gesture-handler';
import {GaragesAndPostsTab} from '../../navigation/ProfileStack';
import ImagePickerOptionModalize from '../../components/ImagePickerModalize/ImagePickerOptionModalize';
import {updateProfile} from '../../services/profileService';

export default function () {
  const settingModalizeRef = useRef(null);
  const [profileHeader, setProfileHeader] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const imagePickerOptionModalizeRef = useRef(null);

  const inputData = {
    username: null,
    profile_image: null,
    background_image: null,
    dob: null,
    bio: null,
    phone_no: null,
  };

  useEffect(() => {
    async function fetchData() {
      setIsLoading(true);

      let response = await getProfileDetails();
      setProfileHeader(response.data);

      setIsLoading(false);
    }

    fetchData();
  }, []);

  const onSubmitEditImage = async () => {
    let response = await updateProfile(inputData);

    if (response.status == 200 && response.success) {
      setProfileHeader({
        ...profileHeader,
        profile_image: response.data.profile_image,
      });
    } else if (response.status == 422) {
      Alert.alert('Edit Profile Image Failed', JSON.stringify(response.error));
    }
  };
  return (
    <>
      {isLoading ? (
        <></>
      ) : (
        <SafeAreaView style={styles.screen}>
          <ScrollView showsVerticalScrollIndicator={false}>
            <View style={styles.mainWrapper}>
              <Header
                data={profileHeader}
                openSettingModalize={() => {
                  settingModalizeRef.current?.open();
                }}
                openImagePickerOptionModalize={() => {
                  imagePickerOptionModalizeRef.current?.open();
                }}
              />
              <GaragesAndPostsTab />
            </View>
          </ScrollView>
          <SettingModalize settingModalizeRef={settingModalizeRef} />
          <ImagePickerOptionModalize
            imagePickerOptionModalizeRef={imagePickerOptionModalizeRef}
            setData={value => {
              inputData.profile_image = value;
              onSubmitEditImage();
            }}
          />
        </SafeAreaView>
      )}
    </>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
  },
  mainWrapper: {
    paddingVertical: normalize(0),
  },
});
