import React, {useState, useEffect, useRef} from 'react';
import {SafeAreaView, StyleSheet, ScrollView, Text, Alert} from 'react-native';
import ProfileDetails from '../../components/profileScreen/details/ProfileDetails';
import {getProfileDetails} from '../../services/profileService';
import ImagePickerOptionModalize from '../../components/ImagePickerModalize/ImagePickerOptionModalize';
import {updateProfile} from '../../services/profileService';

export default function ({route, params}) {
  const [profileDetails, setProfileDetails] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [imageType, setImageType] = useState(null);
  const imagePickerOptionModalizeRef = useRef(null);

  const inputData = {
    username: null,
    profile_image: null,
    background_image: null,
    dob: null,
    bio: null,
    phone_no: null,
  };

  useEffect(() => {
    async function fetchData() {
      setIsLoading(true);

      let response = await getProfileDetails();
      setProfileDetails(response.data);

      setIsLoading(false);
    }

    fetchData();
  }, [route.params]);

  const onSubmitEditImage = async () => {
    let response = await updateProfile(inputData);

    if (response.status == 200 && response.success) {
      if (imageType == 'profile_image') {
        setProfileDetails({
          ...profileDetails,
          profile_image: response.data.profile_image,
        });
      } else if (imageType == 'background_image') {
        setProfileDetails({
          ...profileDetails,
          background_image: response.data.background_image,
        });
      }
    } else if (response.status == 422) {
      if (imageType == 'profile_image') {
        Alert.alert(
          'Edit Profile Image Failed',
          JSON.stringify(response.error),
        );
      } else if (imageType == 'background_image') {
        Alert.alert(
          'Edit Profile Background Image Failed',
          JSON.stringify(response.error),
        );
      }
    }
  };
  return (
    <>
      {isLoading ? (
        <Text style={styles.loading}>Loading...</Text>
      ) : (
        <>
          <SafeAreaView style={styles.screen}>
            <ScrollView showsVerticalScrollIndicator={false}>
              <ProfileDetails
                data={profileDetails}
                openImagePickerOptionModalize={() => {
                  imagePickerOptionModalizeRef.current?.open();
                }}
                setImageType={value => {
                  setImageType(value);
                }}
              />
            </ScrollView>
            <ImagePickerOptionModalize
              imagePickerOptionModalizeRef={imagePickerOptionModalizeRef}
              setData={value => {
                if (imageType == 'profile_image') {
                  inputData.profile_image = value;
                  onSubmitEditImage();
                } else if (imageType == 'background_image') {
                  inputData.background_image = value;
                  onSubmitEditImage();
                }
              }}
            />
          </SafeAreaView>
        </>
      )}
    </>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
  },
  loading: {
    color: '#000000',
    textAlign: 'center',
  },
});
