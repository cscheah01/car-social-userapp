import React from 'react';
import {SafeAreaView, StyleSheet, ScrollView} from 'react-native';
import {normalize} from '../../utils/Helper';
import AddVehicleFormOne from '../../components/profileScreen/garages/AddVehicleFormOne';

export default function AddVehicleScreenOne() {
  return (
    <SafeAreaView style={styles.screen}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <AddVehicleFormOne />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
  },
});
