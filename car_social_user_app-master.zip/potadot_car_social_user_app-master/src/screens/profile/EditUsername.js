import React, {useState} from 'react';
import {SafeAreaView, StyleSheet, Alert} from 'react-native';
import Form from '../../components/profileScreen/details/EditUsername/EditUsernameForm';
import Header from '../../components/profileScreen/details/EditUsername/EditUsernameHeader';
import {updateProfile} from '../../services/profileService';
import {useNavigation} from '@react-navigation/native';

export default function ({route, params}) {
  const navigation = useNavigation();
  const [inputData, setInputData] = useState({
    username: route.params.username,
    profile_image: null,
    background_image: null,
    dob: null,
    bio: null,
    phone_no: null,
  });

  const [inputError, setInputError] = useState({username: null});

  const onSubmitEditUsername = async () => {
    let error = {};
    if (inputData.username == '') {
      error = {...error, username: 'Username is required.'};
    }
    setInputError(error);
    if (Object.keys(error).length === 0) {
      let response = await updateProfile(inputData);

      if (response.status == 200 && response.success) {
        navigation.navigate('Details', {
          editDetail: inputData.username,
        });
      } else if (response.status == 422) {
        setInputError({username: response.error[0].msg});
      }
    }
  };

  return (
    <SafeAreaView style={styles.screen}>
      <Header onSubmitEditUsername={onSubmitEditUsername} />
      <Form
        inputData={inputData.username}
        inputError={inputError.username}
        setInputData={value => {
          setInputData(value);
        }}
        setInputError={value => {
          setInputError(value);
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
  },
});
