import React, {useState, useEffect} from 'react';
import {View, StyleSheet, FlatList, TouchableOpacity} from 'react-native';
import {normalize, getScreenWidth} from '../../utils/Helper';
import {P, H5} from '../../components/common/Typography';
import {useNavigation} from '@react-navigation/native';
import Vehicle from '../../components/profileScreen/garages/Vehicle';
import {getGarage} from '../../services/garageService';

export default function () {
  const navigation = useNavigation();

  const [page, setPage] = useState(1);
  const [garage, setGarage] = useState('');
  const [disableLoading, setDisableLoading] = useState(false);

  const loadMore = () => {
    setPage(page + 1);
  };

  useEffect(() => {
    async function fetchData() {
      let response = await getGarage(page);

      if (response.data.length == 0) {
        setDisableLoading(true);
      } else {
        if (garage == '') {
          setGarage(response.data);
        } else {
          setGarage([...garage, ...response.data]);
        }
      }
    }

    fetchData();
  }, [page]);

  return (
    <View style={styles.screen}>
      <View>
        <FlatList
          showsVerticalScrollIndicator={false}
          data={garage}
          style={styles.mainWrapper}
          keyExtractor={item => item.id}
          renderItem={({item}) => <Vehicle data={item} />}
          onEndReached={disableLoading == true ? null : loadMore}
        />
        <View style={styles.addVehicleButtonWrapper}>
          {garage == '' ? (
            <H5 style={styles.emptyData}>There is no vehicle in your garage</H5>
          ) : null}
          <TouchableOpacity onPress={() => navigation.navigate('AddVehicle')}>
            <View style={styles.addVehicleButton}>
              <P>Add Vehicle</P>
            </View>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
    paddingTop: normalize(32),
    width: getScreenWidth(),
  },
  mainWrapper: {
    paddingVertical: normalize(10),
    paddingHorizontal: normalize(30),
  },
  addVehicleButton: {
    alignItems: 'center',
    fontColor: '#ffffff',
    backgroundColor: '#0057FF',
    borderRadius: normalize(10),
    borderColor: '#ffffff',
    paddingHorizontal: normalize(15),
    paddingVertical: normalize(10),
    width: normalize(100),
  },
  addVehicleButtonWrapper: {
    alignItems: 'center',
  },
  emptyData: {
    color: '#808080',
    alignSelf: 'center',
    marginVertical: normalize(50),
  },
});
