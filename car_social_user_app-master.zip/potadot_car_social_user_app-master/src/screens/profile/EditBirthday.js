import React, {useState} from 'react';
import {SafeAreaView, StyleSheet} from 'react-native';
import Form from '../../components/profileScreen/details/EditBirthday/EditBirthdayForm';
import Header from '../../components/profileScreen/details/EditBirthday/EditBirthdayHeader';
import {updateProfile} from '../../services/profileService';
import {useNavigation} from '@react-navigation/native';
import moment from 'moment';

export default function ({route, params}) {
  const navigation = useNavigation();
  const [inputData, setInputData] = useState({
    username: null,
    profile_image: null,
    background_image: null,
    dob: route.params.dob,
    bio: null,
    phone_no: null,
  });

  const onSubmitEditBirthday = async () => {
    inputData.dob = moment(inputData.dob).format('YYYY-MM-DD hh:mm:ss');
    let response = await updateProfile(inputData);

    if (response.status == 200 && response.success) {
      navigation.navigate('Details', {
        editDetail: inputData.dob,
      });
    } else if (response.status == 422) {
      Alert.alert('Edit Birthday Failed', JSON.stringify(response.error));
    }
  };

  return (
    <SafeAreaView style={styles.screen}>
      <Header onSubmitEditBirthday={onSubmitEditBirthday} />
      <Form
        inputData={inputData.dob}
        setInputData={value => {
          setInputData(value);
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
  },
});
