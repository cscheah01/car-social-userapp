import React, {useRef, useState} from 'react';
import {SafeAreaView, StyleSheet, FlatList} from 'react-native';
import {getScreenWidth, normalize} from '../../utils/Helper';
import Post from '../../components/post/Post';
import PostModalize from '../../components/post/PostModalize';

const demoData = [
  {
    key: 1,
    username: 'Username',
    createdAt: '22-10-2022',
    profilePicture:
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSzHQv_th9wq3ivQ1CVk7UZRxhbPq64oQrg5Q&usqp=CAU',
    media: [
      {
        url: 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8Y2FyfGVufDB8fDB8fA%3D%3D&w=1000&q=80',
        type: 'image',
      },
      {
        url: 'https://ichef.bbci.co.uk/news/976/cpsprodpb/C448/production/_117684205_lotus.jpg',
        type: 'image',
      },
      {
        url: 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8Y2FyfGVufDB8fDB8fA%3D%3D&w=1000&q=80',
        type: 'image',
      },
      {
        url: 'https://ichef.bbci.co.uk/news/976/cpsprodpb/C448/production/_117684205_lotus.jpg',
        type: 'image',
      },
      {
        url: 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8Y2FyfGVufDB8fDB8fA%3D%3D&w=1000&q=80',
        type: 'image',
      },
    ],
    content:
      'Lorem Ipsum is simply dummy text of the printing and type setting industry.',
    likeCount: 10,
    commentCount: 10,
  },
  {
    key: 2,
    username: 'Username',
    createdAt: '22-10-2022',
    profilePicture:
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSzHQv_th9wq3ivQ1CVk7UZRxhbPq64oQrg5Q&usqp=CAU',
    media: [
      {
        url: 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8Y2FyfGVufDB8fDB8fA%3D%3D&w=1000&q=80',
        type: 'image',
      },
      {
        url: 'https://ichef.bbci.co.uk/news/976/cpsprodpb/C448/production/_117684205_lotus.jpg',
        type: 'image',
      },
      {
        url: 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8Y2FyfGVufDB8fDB8fA%3D%3D&w=1000&q=80',
        type: 'image',
      },
      {
        url: 'https://ichef.bbci.co.uk/news/976/cpsprodpb/C448/production/_117684205_lotus.jpg',
        type: 'image',
      },
      {
        url: 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8Y2FyfGVufDB8fDB8fA%3D%3D&w=1000&q=80',
        type: 'image',
      },
    ],
    content:
      'Lorem Ipsum is simply dummy text of the printing and type setting industry.',
    likeCount: 10,
    commentCount: 10,
  },
  {
    key: 3,
    username: 'Username',
    createdAt: '22-10-2022',
    profilePicture:
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSzHQv_th9wq3ivQ1CVk7UZRxhbPq64oQrg5Q&usqp=CAU',
    media: [
      {
        url: 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8Y2FyfGVufDB8fDB8fA%3D%3D&w=1000&q=80',
        type: 'image',
      },
      {
        url: 'https://ichef.bbci.co.uk/news/976/cpsprodpb/C448/production/_117684205_lotus.jpg',
        type: 'image',
      },
      {
        url: 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8Y2FyfGVufDB8fDB8fA%3D%3D&w=1000&q=80',
        type: 'image',
      },
      {
        url: 'https://ichef.bbci.co.uk/news/976/cpsprodpb/C448/production/_117684205_lotus.jpg',
        type: 'image',
      },
      {
        url: 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8Y2FyfGVufDB8fDB8fA%3D%3D&w=1000&q=80',
        type: 'image',
      },
    ],
    content:
      'Lorem Ipsum is simply dummy text of the printing and type setting industry.',
    likeCount: 10,
    commentCount: 10,
  },
];

export default function () {
  const postModalizeRef = useRef(null);
  const [comfirmationVisible, setcomfirmationVisible] = useState(false);
  return (
    <SafeAreaView style={styles.screen}>
      <FlatList
        showsVerticalScrollIndicator={false}
        data={demoData}
        style={styles.mainWrapper}
        keyExtractor={item => item.key}
        renderItem={({item}) => (
          <Post
            data={item}
            comfirmationVisible={comfirmationVisible}
            setcomfirmationVisible={value => {
              setcomfirmationVisible(value);
            }}
            postModalize={() => {
              postModalizeRef.current?.open();
            }}
          />
        )}
      />
      <PostModalize
        postModalizeRef={postModalizeRef}
        setcomfirmationVisible={value => {
          setcomfirmationVisible(value);
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
    paddingTop: normalize(37),
    width: getScreenWidth(),
  },
  mainWrapper: {
    paddingVertical: normalize(10),
    maxWidth: getScreenWidth(),
  },
});
