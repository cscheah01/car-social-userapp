import React, {useState, useEffect} from 'react';
import {SafeAreaView, StyleSheet, FlatList} from 'react-native';
import Event from '../../components/eventScreen/myEvent/Event';
import {normalize} from '../../utils/Helper';
import {P} from '../../components/common/Typography';
import {getNearMeEvent} from '../../services/eventService';

export default function NearMeEventScreen() {
  const [page, setPage] = useState(1);

  const [events, setEvents] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  const loadMore = () => {
    setPage(page + 1);
  };

  useEffect(() => {
    async function fetchData() {
      setIsLoading(true);
      let response = await getNearMeEvent(page);
      if (events == null) {
        setEvents(response.data);
      } else {
        setEvents([...events, ...response.data]);
      }
      setIsLoading(false);
    }

    fetchData();
  }, [page]);

  return (
    <SafeAreaView style={styles.screen}>
      <FlatList
        showsVerticalScrollIndicator={false}
        data={events}
        style={styles.mainWrapper}
        renderItem={({item}) => <Event data={item} />}
        onEndReached={loadMore}
      />
      {isLoading == true ? <P style={styles.loading}>Loading...</P> : <></>}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
  },
  mainWrapper: {
    paddingVertical: normalize(10),
  },
  emptyData: {
    color: '#808080',
    alignSelf: 'center',
    marginVertical: normalize(50),
  },
});
