import React, {useState, useRef} from 'react';
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  View,
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {useNavigation} from '@react-navigation/native';
import {normalize} from '../../utils/Helper';
import CreateEventFormTwo from '../../components/eventScreen/createEvent/CreateEventFormTwo';
import {H3} from '../../components/common/Typography';
import ImagePickerOptionModalize from '../../components/ImagePickerModalize/ImagePickerOptionModalize';

export default function CreateEventScreenTwo({route, params}) {
  const navigation = useNavigation();
  const [eventData, setEventData] = useState({
    title: route.params.title,
    start_date: route.params.start_date,
    end_date: route.params.end_date,
    location: route.params.location,
  });
  const [coverPhoto, setCoverPhoto] = useState(null);
  const imagePickerOptionModalizeRef = useRef(null);

  return (
    <SafeAreaView style={styles.screen}>
      <View style={styles.topSection}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <View style={(styles.flexRow, styles.backButton)}>
            <Icon name="arrow-left" style={styles.icon} />
          </View>
        </TouchableOpacity>

        <H3>Back</H3>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        <CreateEventFormTwo
          openImagePickerOptionModalize={() => {
            imagePickerOptionModalizeRef.current?.open();
          }}
          coverPhoto={coverPhoto}
          eventData={eventData}
        />
      </ScrollView>
      <ImagePickerOptionModalize
        imagePickerOptionModalizeRef={imagePickerOptionModalizeRef}
        setData={value => {
          setCoverPhoto(value);
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
    padding: normalize(10),
  },
  topSection: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: normalize(30),
  },
  flexRow: {
    flexDirection: 'row',
  },
  backButton: {
    marginRight: normalize(20),
  },
  icon: {
    fontSize: normalize(20),
    color: '#ffffff',
  },
});
