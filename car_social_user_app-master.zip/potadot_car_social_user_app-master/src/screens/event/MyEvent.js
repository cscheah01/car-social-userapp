import React, {useState, useEffect} from 'react';
import {SafeAreaView, StyleSheet, FlatList} from 'react-native';
import Event from '../../components/eventScreen/myEvent/Event';
import {normalize} from '../../utils/Helper';
import {P, H5} from '../../components/common/Typography';
import {getMyEvent} from '../../services/eventService';

export default function MyEventScreen() {
  const [page, setPage] = useState(1);

  const [events, setEvents] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [disableLoading, setDisableLoading] = useState(false);

  const loadMore = () => {
    setPage(page + 1);
  };

  useEffect(() => {
    async function fetchData() {
      setIsLoading(true);
      let response = await getMyEvent(page);
      if (response.data.length == 0) {
        setDisableLoading(true);
      } else {
        if (events == null) {
          setEvents(response.data);
        } else {
          setEvents([...events, ...response.data]);
        }
      }
      setIsLoading(false);
    }

    fetchData();
  }, [page]);

  return (
    <SafeAreaView style={styles.screen}>
      {events == '' ? (
        <H5 style={styles.emptyData}>You not join or create any event</H5>
      ) : null}
      <FlatList
        showsVerticalScrollIndicator={false}
        data={events}
        style={styles.mainWrapper}
        renderItem={({item}) => <Event data={item} />}
        onEndReached={disableLoading == true ? null : loadMore}
      />
      {isLoading == true ? <P style={styles.loading}>Loading...</P> : <></>}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
  },
  mainWrapper: {
    paddingVertical: normalize(10),
  },
  emptyData: {
    color: '#808080',
    alignSelf: 'center',
    marginVertical: normalize(50),
  },
});
