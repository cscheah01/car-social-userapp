import React, {useState, useEffect} from 'react';
import {SafeAreaView, StyleSheet, ScrollView} from 'react-native';
import CreateEventFormOne from '../../components/eventScreen/createEvent/CreateEventFormOne';

export default function CreateEventScreenOne({route, params}) {
  const [responseError, setResponseError] = useState(null);

  useEffect(() => {
    if (route != null) {
      setResponseError(route.params);
    }
  }, [route]);
  return (
    <SafeAreaView style={styles.screen}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <CreateEventFormOne responseError={responseError} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
  },
});
