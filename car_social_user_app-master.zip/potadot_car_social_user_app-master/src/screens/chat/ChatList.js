import React, {useState, useEffect} from 'react';
import {SafeAreaView, StyleSheet, FlatList, View} from 'react-native';
import ChatListHeader from '../../components/chatScreen/chatList/ChatListHeader';
import {normalize} from '../../utils/Helper';
import {H5} from '../../components/common/Typography';
import Chat from '../../components/chatScreen/chatList/Chat.js';
import {getChatList} from '../../services/chatService';
import {P} from '../../components/common/Typography';

export default function ChatListScreen() {
  const [chat, setChat] = useState('');
  const [page, setPage] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [disableLoading, setDisableLoading] = useState(false);

  const loadMore = () => {
    setPage(page + 1);
  };

  useEffect(() => {
    async function fetchData() {
      setIsLoading(true);
      let response = await getChatList(page);
      if (response.data.length == 0) {
        setDisableLoading(true);
      } else {
        if (chat == '') {
          setChat(response.data);
        } else {
          setChat([...chat, ...response.data]);
        }
      }
      setIsLoading(false);
    }

    fetchData();
  }, [page]);

  return (
    <SafeAreaView style={styles.screen}>
      <ChatListHeader />
      <View style={styles.text}>
        <H5>Messages</H5>
      </View>
      <FlatList
        showsVerticalScrollIndicator={false}
        data={chat}
        style={styles.mainWrapper}
        renderItem={({item}) => <Chat data={item} />}
        onEndReached={disableLoading == true ? null : loadMore}
      />
      {isLoading == true ? <P style={styles.loading}>Loading...</P> : <></>}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
  },
  text: {
    marginTop: normalize(15),
    marginLeft: normalize(7),
    marginBottom: normalize(5),
  },
});
