import React, {useState, useEffect} from 'react';
import {SafeAreaView, StyleSheet, FlatList, Alert} from 'react-native';
import SearchUserHeader from '../../components/chatScreen/searchUser/SearchUserHeader';
import User from '../../components/chatScreen/searchUser/User';
import {getChatUser, getChatSession} from '../../services/chatService';
import {useNavigation} from '@react-navigation/native';

export default function ChatListScreen() {
  const navigation = useNavigation();
  const [user, setUser] = useState('');
  const [username, setUsername] = useState('');

  useEffect(() => {
    async function fetchData() {
      let response = await getChatUser(username);
      setUser(response.data);
    }
    if (username != '') {
      fetchData();
    }
  }, [username]);

  const onSubmitCreateChatRoom = async id => {
    let response = await getChatSession(id);

    if (response.status == 200 && response.success) {
      navigation.navigate('ChatRoom', {
        chatSessionId: response.data.chat_session_id,
        username: response.data.receiver,
      });
    } else if (response.status == 422) {
      Alert.alert('Create Chat Room Failed', JSON.stringify(response.error));
    }
  };

  return (
    <SafeAreaView style={styles.screen}>
      <SearchUserHeader
        username={username}
        setUsername={value => {
          setUsername(value);
        }}
      />
      <FlatList
        showsVerticalScrollIndicator={false}
        data={user}
        style={styles.mainWrapper}
        keyExtractor={item => item.id}
        renderItem={({item}) => (
          <User
            data={item}
            setSelectId={value => {
              setSelectId(value);
            }}
            onSubmitCreateChatRoom={onSubmitCreateChatRoom}
          />
        )}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
  },
});
