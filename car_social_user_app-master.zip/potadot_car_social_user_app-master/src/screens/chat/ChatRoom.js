import React, {useState, useEffect, useRef} from 'react';
import {SafeAreaView, StyleSheet, FlatList, View} from 'react-native';
import ChatRoomHeader from '../../components/chatScreen/chatRoom/ChatRoomHeader';
import {normalize} from '../../utils/Helper';
import ChatContent from '../../components/chatScreen/chatRoom/ChatContent';
import ChatInput from '../../components/chatScreen/chatRoom/ChatInput';
import {getChatContent} from '../../services/chatService';
import EncryptedStorage from 'react-native-encrypted-storage';

let userId;
export default function ChatRoomScreen({route, params}) {
  const flatListRef = useRef();
  const [chatSessionId, setChatSessionId] = useState(
    route.params.chatSessionId,
  );
  const [chatContent, setChatContent] = useState('');
  const [page, setPage] = useState(1);

  useEffect(() => {
    async function fetchData() {
      let response = await getChatContent(chatSessionId, page);

      if (chatContent == '') {
        setChatContent(response.data);
      } else {
        setChatContent([...chatContent, ...response.data]);
      }
      userId = await EncryptedStorage.getItem('userId');
    }

    fetchData();
  }, [chatSessionId, page]);

  return (
    <SafeAreaView style={styles.screen}>
      <ChatRoomHeader
        username={route.params.username}
        profileImage={route.params.profile_image}
      />
      <View style={styles.chatContentWrapper}>
        <FlatList
          ref={flatListRef}
          inverted
          showsVerticalScrollIndicator={false}
          data={chatContent}
          keyExtractor={item => item.id}
          renderItem={({item}) => <ChatContent data={item} userId={userId} />}
          onLayout={() => {
            flatListRef.current.scrollToOffset({animated: true, offset: 0});
          }}
        />
      </View>

      <ChatInput
        chatSessionId={chatSessionId}
        chatContent={chatContent}
        setChatContent={setChatContent}
        userId={userId}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000000',
  },
  chatContentWrapper: {
    flex: 1,
    paddingBottom: normalize(50),
  },
});
