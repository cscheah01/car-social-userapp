import React from 'react';
import {StyleSheet, View, Image, TouchableOpacity} from 'react-native';
import {normalize} from '../../../utils/Helper';
import {useNavigation} from '@react-navigation/native';
import {P} from '../../common/Typography';
import moment from 'moment';

export default function Chat({data}) {
  const navigation = useNavigation();

  return (
    <View key={data.id} style={styles.wrapper}>
      <TouchableOpacity
        onPress={() =>
          navigation.navigate('ChatRoom', {
            chatSessionId: data.chat_session_id,
            username: data.receiver,
            profile_image: data.profile_image ?? null,
          })
        }>
        <View style={styles.wrapChat}>
          <View style={styles.wrapProfilePicture}>
            {data.profile_image != null ? (
              <>
                <Image
                  source={{uri: data.profile_image}}
                  style={styles.userProfileImage}
                />
              </>
            ) : (
              <>
                <View style={styles.userProfileImage}></View>
              </>
            )}
          </View>
          <View style={styles.rightSection}>
            <View style={styles.topSection}>
              <P>{data.receiver}</P>
              <P style={styles.postDate}>
                {moment(data.created_at).format('Do MMMM YYYY, h:mm a')}
              </P>
            </View>
            <P numberOfLines={1}>{data.latest_message}</P>
          </View>
        </View>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    padding: normalize(15),
    borderBottomColor: '#ffffff',
    borderBottomWidth: normalize(3),
  },
  wrapChat: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  wrapProfilePicture: {
    flex: 1 / 6,
    justifyContent: 'center',
  },
  topSection: {
    flexDirection: 'row',
    marginBottom: normalize(5),
  },
  rightSection: {
    flex: 5 / 6,
  },
  userProfileImage: {
    height: normalize(30),
    width: normalize(30),
    borderRadius: normalize(30) / 2,
    marginRight: normalize(10),
    backgroundColor: '#1E1B1B',
    borderColor: '#ffffff',
    borderWidth: normalize(2),
  },
  postDate: {
    color: 'rgba(255, 255, 255, 0.5)',
    fontSize: normalize(12),
    marginLeft: normalize(10),
  },
});
