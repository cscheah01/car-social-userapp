import React from 'react';
import {StyleSheet, View, TouchableOpacity} from 'react-native';
import {normalize} from '../../../utils/Helper';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {useNavigation} from '@react-navigation/native';

export default function ChatListHeader() {
  const navigation = useNavigation();

  return (
    <View style={styles.wrapper}>
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <View style={(styles.flexRow, styles.backButton)}>
          <Icon name="arrow-left" style={styles.icon} />
        </View>
      </TouchableOpacity>
      <View style={styles.rightSection}>
        <View style={styles.flexRow}>
          <View style={styles.rightSectionItem}>
            <TouchableOpacity
              onPress={() => {
                navigation.navigate('SearchUser');
              }}>
              <View>
                <Icon name="search" style={styles.icon} />
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#000000',
    padding: normalize(10),
    borderBottomColor: '#ffffff',
    borderBottomWidth: normalize(3),
  },
  title: {
    fontSize: normalize(15),
  },
  backButton: {
    marginRight: normalize(18),
  },
  rightSection: {
    flex: 1,
    alignItems: 'flex-end',
  },
  flexRow: {
    flexDirection: 'row',
  },
  rightSectionItem: {
    marginLeft: normalize(20),
  },
  icon: {
    fontSize: normalize(18),
    color: '#ffffff',
  },
});
