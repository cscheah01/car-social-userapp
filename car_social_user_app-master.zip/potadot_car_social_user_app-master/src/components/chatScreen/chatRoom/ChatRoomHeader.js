import React from 'react';
import {StyleSheet, View, TouchableOpacity, Image} from 'react-native';
import {normalize} from '../../../utils/Helper';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {useNavigation} from '@react-navigation/native';
import {P} from '../../common/Typography';

export default function ChatRoomHeader({username, profileImage}) {
  const navigation = useNavigation();

  return (
    <View style={styles.wrapper}>
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <View style={(styles.flexRow, styles.backButton)}>
          <Icon name="arrow-left" style={styles.icon} />
        </View>
      </TouchableOpacity>
      <View style={styles.flexRow}>
        {profileImage != null ? (
          <>
            <Image
              source={{uri: profileImage}}
              style={styles.userProfileImage}
            />
          </>
        ) : (
          <>
            <View style={styles.userProfileImage}></View>
          </>
        )}
        <P>{username}</P>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#000000',
    padding: normalize(10),
    borderBottomColor: '#ffffff',
    borderBottomWidth: normalize(3),
  },
  backButton: {
    marginRight: normalize(20),
  },
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  icon: {
    fontSize: normalize(18),
    color: '#ffffff',
  },
  userProfileImage: {
    height: normalize(30),
    width: normalize(30),
    borderRadius: normalize(30) / 2,
    marginRight: normalize(10),
    backgroundColor: '#1E1B1B',
    borderColor: '#ffffff',
    borderWidth: normalize(2),
  },
});
