import React, {useState} from 'react';
import {StyleSheet, View, Image} from 'react-native';
import {normalize} from '../../../utils/Helper';
import {P} from '../../common/Typography';
//import {Dimensions} from 'react-native';
export default function ChatContent({data, userId}) {
  // const [height, setHeight] = useState(0);
  // const [width, setWidth] = useState(0);

  // if (data.image) {
  //   let imageUrl = data.image;

  //   Image.getSize(imageUrl, (srcWidth, srcHeight) => {
  //     const maxHeight = Dimensions.get('window').height;

  //     const ratio = Math.min(normalize(140) / srcWidth, maxHeight / srcHeight);
  //     setHeight(srcHeight * ratio);
  //     setWidth(srcWidth * ratio);
  //   });
  // }

  // if (data.user_id == userId) {
  //   if (data.image) {
  //     return (
  //       <View style={styles.mainWrapper}>
  //         <View key={data.id}>
  //           <View style={styles.wrapSelfChatContent}>
  //             <View style={styles.imageContentSection}>
  //               <Image
  //                 source={{uri: data.image}}
  //                 resizeMode={'contain'}
  //                 style={{
  //                   height: height,
  //                   width: width,
  //                   borderRadius: normalize(10),
  //                 }}
  //               />
  //             </View>
  //             <View style={styles.selfProfileImageSection}>
  //               <Image
  //                 source={{
  //                   uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSzHQv_th9wq3ivQ1CVk7UZRxhbPq64oQrg5Q&usqp=CAU',
  //                 }}
  //                 style={styles.userProfileImage}
  //               />
  //             </View>
  //           </View>
  //         </View>
  //       </View>
  //     );
  //   } else {
  //     return (
  //       <View style={styles.mainWrapper}>
  //         <View key={data.key}>
  //           <View style={styles.wrapSelfChatContent}>
  //             <View style={styles.contentSection}>
  //               <P style={styles.content}>{data.content}</P>
  //             </View>
  //             <View style={styles.selfProfileImageSection}>
  //               <Image
  //                 source={{
  //                   uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSzHQv_th9wq3ivQ1CVk7UZRxhbPq64oQrg5Q&usqp=CAU',
  //                 }}
  //                 style={styles.userProfileImage}
  //               />
  //             </View>
  //           </View>
  //         </View>
  //       </View>
  //     );
  //   }
  //   return (
  //     <View style={styles.mainWrapper}>
  //       <View style={styles.wrapSelfChatContent}>
  //         <View style={styles.contentSection}>
  //           <P style={styles.content}>{data.content}</P>
  //         </View>
  //         <View style={styles.selfProfileImageSection}>
  //           <Image
  //             source={{
  //               uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSzHQv_th9wq3ivQ1CVk7UZRxhbPq64oQrg5Q&usqp=CAU',
  //             }}
  //             style={styles.userProfileImage}
  //           />
  //         </View>
  //       </View>
  //     </View>
  //   );
  // } else if (data.user_id != userId) {
  //   if (data.image) {
  //     return (
  //       <View style={styles.mainWrapper}>
  //         <View key={data.key}>
  //           <View style={styles.wrapOtherChatContent}>
  //             <View style={styles.otherProfileImageSection}>
  //               <Image
  //                 source={{
  //                   uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSzHQv_th9wq3ivQ1CVk7UZRxhbPq64oQrg5Q&usqp=CAU',
  //                 }}
  //                 style={styles.userProfileImage}
  //               />
  //             </View>
  //             <View style={styles.imageOtherContentSection}>
  //               <Image
  //                 source={{uri: data.image}}
  //                 resizeMode={'contain'}
  //                 style={{
  //                   height: height,
  //                   width: width,
  //                   borderRadius: normalize(10),
  //                 }}
  //               />
  //             </View>
  //           </View>
  //         </View>
  //       </View>
  //     );
  //   } else {
  //     return (
  //       <View style={styles.mainWrapper}>
  //         <View key={data.key}>
  //           <View style={styles.wrapOtherChatContent}>
  //             <View style={styles.otherProfileImageSection}>
  //               <Image
  //                 source={{
  //                   uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSzHQv_th9wq3ivQ1CVk7UZRxhbPq64oQrg5Q&usqp=CAU',
  //                 }}
  //                 style={styles.userProfileImage}
  //               />
  //             </View>
  //             <View style={styles.contentSection}>
  //               <P style={styles.content}>{data.content}</P>
  //             </View>
  //           </View>
  //         </View>
  //       </View>
  //     );
  //   }
  //   return (
  //     <View style={styles.mainWrapper}>
  //       <View style={styles.wrapOtherChatContent}>
  //         <View style={styles.otherProfileImageSection}>
  //           <Image
  //             source={{
  //               uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSzHQv_th9wq3ivQ1CVk7UZRxhbPq64oQrg5Q&usqp=CAU',
  //             }}
  //             style={styles.userProfileImage}
  //           />
  //         </View>
  //         <View style={styles.contentSection}>
  //           <P style={styles.content}>{data.content}</P>
  //         </View>
  //       </View>
  //     </View>
  //   );
  // }
  return (
    <View style={styles.mainWrapper}>
      {userId == data.user_id ? (
        <View style={styles.wrapSelfChatContent}>
          <View style={styles.contentSection}>
            <P style={styles.content}>{data.content}</P>
          </View>
          <View style={styles.selfProfileImageSection}>
            {data.profile_image != null ? (
              <>
                <Image
                  source={{uri: data.profile_image}}
                  style={styles.userProfileImage}
                />
              </>
            ) : (
              <>
                <View style={styles.userProfileImage}></View>
              </>
            )}
          </View>
        </View>
      ) : (
        <View style={styles.wrapOtherChatContent}>
          <View style={styles.otherProfileImageSection}>
            {data.profile_image != null ? (
              <>
                <Image
                  source={{uri: data.profile_image}}
                  style={styles.userProfileImage}
                />
              </>
            ) : (
              <>
                <View style={styles.userProfileImage}></View>
              </>
            )}
          </View>
          <View style={styles.contentSection}>
            <P style={styles.content}>{data.content}</P>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  mainWrapper: {
    padding: normalize(10),
  },
  wrapSelfChatContent: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'flex-end',
  },
  wrapSelfChatContent: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'flex-end',
  },
  wrapOtherChatContent: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'flex-start',
  },
  userProfileImage: {
    height: normalize(30),
    width: normalize(30),
    borderRadius: normalize(30) / 2,
    backgroundColor: '#1E1B1B',
    borderColor: '#ffffff',
    borderWidth: normalize(2),
  },
  selfProfileImageSection: {
    justifyContent: 'flex-end',
    alignItems: 'flex-end',
    flex: 1 / 8,
  },
  otherProfileImageSection: {
    justifyContent: 'flex-end',
    alignItems: 'flex-start',
    flex: 1 / 8,
  },
  contentSection: {
    flex: 5 / 8,
    backgroundColor: '#ffffff',
    borderRadius: normalize(5),
    padding: normalize(8),
  },
  content: {
    textAlign: 'justify',
    color: '#000000',
  },
  imageContentSection: {
    flex: 5 / 8,
    flexDirection: 'row-reverse',
  },
  imageOtherContentSection: {
    flex: 5 / 8,
    flexDirection: 'row',
  },
});
