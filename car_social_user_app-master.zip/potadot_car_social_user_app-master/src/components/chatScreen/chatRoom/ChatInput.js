import React, {useState} from 'react';
import {StyleSheet, View, TextInput, Alert} from 'react-native';
import {normalize} from '../../../utils/Helper';
import Icon from 'react-native-vector-icons/FontAwesome5';
import SendIcon from 'react-native-vector-icons/Feather';
import {sendChatContent} from '../../../services/chatService';

export default function ChatInput({
  chatSessionId,
  chatContent,
  setChatContent,
}) {
  const inputMaxlength = 65535;
  const [visible, setVisible] = useState({
    sendIcon: false,
    mediaIcon: true,
  });

  const [input, setInput] = useState(null);

  const checkTextInput = text => {
    if (text) {
      setVisible({sendIcon: true, mediaIcon: false});
    } else {
      setVisible({sendIcon: false, mediaIcon: true});
    }
  };

  const onSendMessage = async () => {
    if (!input) {
      return;
    }
    let response = await sendChatContent(input, chatSessionId);

    if (response.status == 200 && response.success) {
      setChatContent([
        {
          id: response.data.id,
          user_id: response.data.userId,
          chatSessionId: response.data.chatSessionId,
          content: response.data.content,
        },
        ...chatContent,
      ]);
      setInput(null);
    } else if (response.status == 422) {
      Alert.alert('Send Chat Failed', JSON.stringify(response.error));
    }
  };

  return (
    <View style={styles.wrapper}>
      <View style={styles.inputSection}>
        <TextInput
          maxLength={inputMaxlength}
          style={styles.chatInput}
          placeholder="Message..."
          placeholderTextColor={'#ffffff'}
          multiline={true}
          value={input}
          onChangeText={text => {
            checkTextInput(text);
            setInput(text);
          }}
        />
        <View style={styles.rightSection}>
          <View style={styles.flexRow}>
            <Icon
              name="camera"
              style={[
                styles.icon,
                visible.mediaIcon == false ? styles.hideIcon : null,
              ]}
              onPress={() => {}}
            />
            <Icon
              name="image"
              style={[
                styles.icon,
                visible.mediaIcon == false ? styles.hideIcon : null,
              ]}
              onPress={() => {}}
            />
            <Icon name="smile" style={styles.icon} onPress={() => {}} />
            <SendIcon
              name="send"
              style={[
                styles.icon,
                visible.sendIcon == false ? styles.hideIcon : null,
              ]}
              onPress={() => {
                onSendMessage();
              }}
            />
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    right: 0,
    left: 0,
    bottom: 0,
    position: 'absolute',
    padding: normalize(10),
  },
  icon: {
    color: '#ffffff',
    fontSize: normalize(20),
    marginLeft: normalize(18),
  },
  inputSection: {
    flex: 1,
    flexDirection: 'row',
    backgroundColor: '#191919',
    paddingHorizontal: normalize(10),
    borderRadius: normalize(7),
    maxHeight: normalize(50),
  },
  chatInput: {
    color: '#ffffff',
    padding: normalize(5),
    width: normalize(210),
  },
  rightSection: {
    flex: 1,
    alignItems: 'flex-end',
    justifyContent: 'center',
    padding: normalize(8),
  },
  flexRow: {
    flexDirection: 'row',
  },
  hideIcon: {
    display: 'none',
  },
});
