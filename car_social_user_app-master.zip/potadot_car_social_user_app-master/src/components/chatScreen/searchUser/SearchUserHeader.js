import React from 'react';
import {StyleSheet, View, TouchableOpacity, TextInput} from 'react-native';
import {normalize} from '../../../utils/Helper';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {useNavigation} from '@react-navigation/native';
import {H5} from '../../common/Typography';

export default function ChatListHeader({setUsername}) {
  const navigation = useNavigation();

  return (
    <View style={styles.wrapper}>
      <TouchableOpacity
        style={styles.wrapBackButton}
        onPress={() => navigation.goBack()}>
        <View style={styles.backButton}>
          <Icon name="arrow-left" style={styles.icon} />
        </View>
      </TouchableOpacity>

      <View style={styles.wrapInputBox}>
        <TextInput
          style={styles.inputBox}
          placeholder="Username"
          onChangeText={text => {
            setUsername(text);
          }}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#000000',
    padding: normalize(10),
    borderBottomColor: '#ffffff',
    borderBottomWidth: normalize(3),
  },
  backButton: {
    marginRight: normalize(20),
  },
  flexRow: {
    flex: 1,
    flexDirection: 'row',
  },
  icon: {
    fontSize: normalize(18),
    color: '#ffffff',
  },
  inputBox: {
    backgroundColor: '#ffffff',
    padding: normalize(5),
    fontSize: normalize(15),
    borderRadius: normalize(10),
    width: '100%',
  },
  buttonBlue: {
    width: normalize(70),
    backgroundColor: '#0057FF',
    borderRadius: normalize(10),
    paddingVertical: normalize(7),
  },
  buttonText: {
    textAlign: 'center',
    fontSize: normalize(14),
  },
  disabledbutton: {
    opacity: 0.4,
  },
  wrapButton: {
    flex: 2 / 8,
    justifyContent: 'center',
    alignContent: 'flex-end',
  },
  wrapInputBox: {flex: 7 / 8, marginRight: normalize(10)},
  wrapBackButton: {
    flex: 1 / 8,
    justifyContent: 'center',
    alignContent: 'center',
  },
});
