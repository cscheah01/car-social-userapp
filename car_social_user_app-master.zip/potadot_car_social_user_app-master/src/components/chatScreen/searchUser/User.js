import React from 'react';
import {StyleSheet, View, Image, TouchableOpacity} from 'react-native';
import {normalize} from '../../../utils/Helper';
import {useNavigation} from '@react-navigation/native';
import {P} from '../../common/Typography';

export default function Chat({data, onSubmitCreateChatRoom}) {
  return (
    <View style={styles.wrapper}>
      <TouchableOpacity
        onPress={() => {
          onSubmitCreateChatRoom(data.id);
        }}>
        <View style={styles.wrapChat}>
          <View style={styles.wrapProfilePicture}>
            {data.profile_image != null ? (
              <>
                <Image
                  source={{uri: data.profile_image}}
                  style={styles.userProfileImage}
                />
              </>
            ) : (
              <>
                <View style={styles.userProfileImage}></View>
              </>
            )}
          </View>
          <View style={styles.rightSection}>
            <P>{data.username}</P>
          </View>
        </View>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    padding: normalize(15),
    borderBottomColor: '#ffffff',
    borderBottomWidth: normalize(3),
  },
  wrapChat: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  wrapProfilePicture: {
    flex: 1 / 6,
    justifyContent: 'center',
  },
  rightSection: {
    flexDirection: 'row',
    alignSelf: 'center',
  },
  userProfileImage: {
    height: normalize(30),
    width: normalize(30),
    borderRadius: normalize(30) / 2,
    marginRight: normalize(10),
    backgroundColor: '#1E1B1B',
    borderColor: '#ffffff',
    borderWidth: normalize(2),
  },
});
