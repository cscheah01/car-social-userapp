import React, {useState, useRef, useCallback} from 'react';
import {
  StyleSheet,
  View,
  Image,
  TouchableWithoutFeedback,
  Modal,
  TouchableOpacity,
  Alert,
} from 'react-native';
import {
  normalize,
  getScreenWidth,
  totalCountFormatter,
} from '../../utils/Helper';
import Carousel from 'react-native-snap-carousel';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {useNavigation} from '@react-navigation/native';
import {P, H4} from '../common/Typography';
import Dots from 'react-native-dots-pagination';
import moment from 'moment';
import Video from 'react-native-video';
import {deletePost, likePost, unlikePost} from '../../services/postService';

function renderItem({item, index}) {
  if (item.type.includes('image')) {
    return (
      <View key={index}>
        <Image source={{uri: item.url}} style={styles.feedImage} />
      </View>
    );
  } else if (item.type.includes('video')) {
    return (
      <View key={index}>
        <Video
          source={{uri: item.url}}
          resizeMode={'contain'}
          repeat={true}
          muted={false}
          style={styles.feedImage}
        />
      </View>
    );
  }
}

export default function Post({
  data,
  postModalize,
  comfirmationVisible,
  setcomfirmationVisible,
}) {
  const navigation = useNavigation();
  const isCarousel = useRef(null);
  const [activeSlideInddax, setActiveSlideInddax] = useState(0);
  const [showAllContent, setShowAllContent] = useState(false);
  const [showSeeMore, setShowSeeMore] = useState(false);
  const [isLiked, setIsLiked] = useState(data.is_liked);
  const [totalLike, setTotalLike] = useState(data.total_like);
  const [totalComment, setTotalComment] = useState(data.total_comment);

  const onTextLayout = useCallback(e => {
    setShowSeeMore(e.nativeEvent.lines.length >= 4);
  }, []);

  const onSubmitDeletePost = async data => {
    let response = await deletePost(data);

    if (response.status == 422) {
      Alert.alert('Delete Post Failed', JSON.stringify(response.error));
    }
  };

  const onPressLike = async () => {
    if (isLiked) {
      setIsLiked(false);
      setTotalLike(totalLike - 1);

      let response = await unlikePost(data.id);

      if (response.status == 422) {
        Alert.alert('Like Post Failed', JSON.stringify(response.error));
      }
    } else {
      setIsLiked(true);
      setTotalLike(totalLike + 1);

      let response = await likePost(data.id);

      if (response.status == 422) {
        Alert.alert('Like Post Failed', JSON.stringify(response.error));
      }
    }
  };

  return (
    <View key={data.id} style={styles.wrapper}>
      <View style={styles.topSection}>
        {data.profile_image != null ? (
          <>
            <Image
              source={{uri: data.profile_image}}
              style={styles.userProfileImage}
            />
          </>
        ) : (
          <>
            <View style={styles.userProfileImage}></View>
          </>
        )}
        <P>{data.username}</P>
        <P style={styles.postDate}>
          {moment(data.created_at).format('Do MMMM YYYY, h:mm a')}
        </P>
        <View style={styles.ellipsisWrapper}>
          <TouchableOpacity
            onPress={() => {
              postModalize();
            }}>
            <Icon name="ellipsis-v" style={styles.ellipsisIcon} />
          </TouchableOpacity>
        </View>
        <Modal
          animationType="slide"
          transparent={true}
          visible={comfirmationVisible}
          onRequestClose={() => {
            setcomfirmationVisible(false);
          }}>
          <View style={styles.centeredView}>
            <View style={styles.comfirmationView}>
              <H4 style={styles.textStyle}>Delete this post?</H4>
              <View style={styles.horizontalLine}></View>
              <TouchableOpacity
                style={[styles.selection]}
                onPress={() => {
                  onSubmitDeletePost(data.id);
                  setcomfirmationVisible(false);
                }}>
                <View>
                  <P style={styles.textStyle}>Delete</P>
                </View>
              </TouchableOpacity>
              <View style={styles.horizontalLine}></View>
              <TouchableOpacity
                style={styles.selection}
                onPress={() => setcomfirmationVisible(false)}>
                <P style={styles.textStyle}>Close</P>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      </View>

      <View>
        <Carousel
          ref={isCarousel}
          data={data.media}
          firstItem={0}
          renderItem={renderItem}
          onSnapToItem={index => setActiveSlideInddax(index)}
          sliderWidth={getScreenWidth()}
          itemWidth={getScreenWidth()}
          useScrollView
          activeSlideAlignment="start"
          inactiveSlideScale={1}
          inactiveSlideOpacity={1}
        />
        <Dots
          length={data.media.length}
          active={activeSlideInddax}
          passiveColor={'rgba(255, 255, 255, 0.5)'}
          activeColor={'#ffffff'}
          width={normalize(55)}
          activeDotWidth={normalize(10)}
          activeDotHeight={normalize(10)}
          passiveDotWidth={normalize(7)}
          passiveDotHeight={normalize(7)}
        />
      </View>

      <View style={styles.bottomSection}>
        <View style={styles.bottomSectionRow1}>
          <TouchableOpacity
            onPress={() => {
              onPressLike();
            }}>
            <View style={styles.likeWraper}>
              <Icon
                name="heart"
                style={isLiked ? styles.likeIcon : styles.unlikeIcon}
              />
              <P>{totalCountFormatter(totalLike)} likes</P>
            </View>
          </TouchableOpacity>
          <TouchableWithoutFeedback
            onPress={() =>
              navigation.navigate('SinglePost', {postId: data.id})
            }>
            <View style={styles.commentWraper}>
              <Icon name="comment" style={styles.commentIcon} />
              <P>{totalCountFormatter(totalComment)} comments</P>
            </View>
          </TouchableWithoutFeedback>
        </View>

        <TouchableWithoutFeedback
          onPress={() => setShowAllContent(!showAllContent)}>
          <View style={styles.bottomSectionRow2}>
            <P
              onTextLayout={onTextLayout}
              numberOfLines={showAllContent ? undefined : 2}>
              {data.content}
            </P>
            {!showAllContent && showSeeMore ? (
              <P style={[styles.textBold]}>See more</P>
            ) : null}
          </View>
        </TouchableWithoutFeedback>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    paddingBottom: normalize(15),
  },
  textBold: {
    fontWeight: 'bold',
  },
  topSection: {
    flexDirection: 'row',
    margin: normalize(10),
    alignItems: 'center',
  },
  userProfileImage: {
    height: normalize(30),
    width: normalize(30),
    borderRadius: normalize(30) / 2,
    marginRight: normalize(10),
    backgroundColor: '#1E1B1B',
    borderColor: '#ffffff',
    borderWidth: normalize(2),
  },
  postDate: {
    color: 'rgba(255, 255, 255, 0.5)',
    fontSize: normalize(12),
    marginLeft: normalize(10),
  },
  ellipsisWrapper: {
    flex: 1,
    alignItems: 'flex-end',
  },
  feedImage: {
    height: getScreenWidth(),
    width: getScreenWidth(),
    resizeMode: 'contain',
  },
  bottomSection: {
    margin: normalize(10),
  },
  bottomSectionRow1: {
    flexDirection: 'row',
  },
  bottomSectionRow2: {
    marginTop: normalize(5),
  },
  likeWraper: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: normalize(10),
  },
  likeIcon: {
    fontSize: normalize(12),
    color: '#FF0000',
    marginRight: normalize(5),
  },
  unlikeIcon: {
    fontSize: normalize(12),
    color: '#ffffff',
    marginRight: normalize(5),
  },
  commentWraper: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  commentIcon: {
    fontSize: normalize(12),
    color: '#ffffff',
    marginRight: normalize(5),
  },
  ellipsisIcon: {
    fontSize: normalize(15),
    color: '#ffffff',
  },
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: normalize(22),
  },
  modalView: {
    margin: normalize(20),
    backgroundColor: '#ffffff',
    borderRadius: normalize(20),
    alignItems: 'center',
    elevation: 5,
    width: normalize(230),
    height: normalize(85),
  },
  comfirmationView: {
    margin: normalize(20),
    backgroundColor: '#ffffff',
    borderRadius: normalize(20),
    alignItems: 'center',
    elevation: 5,
    width: normalize(230),
    height: normalize(125),
  },
  textStyle: {
    color: '#000000',
    textAlign: 'center',
    fontSize: normalize(15),
    margin: normalize(12),
  },
  selection: {
    width: '100%',
  },
  horizontalLine: {
    borderBottomColor: '#808080',
    borderBottomWidth: normalize(2),
    width: '100%',
  },
});
