import React from 'react';
import {StyleSheet, View, TouchableOpacity} from 'react-native';
import {Modalize} from 'react-native-modalize';
import {normalize} from '../../utils/Helper';
import {H5} from '../common/Typography';

export default function ({postModalizeRef, setcomfirmationVisible}) {
  return (
    <Modalize ref={postModalizeRef} adjustToContentHeight={true}>
      <TouchableOpacity
        onPress={() => {
          postModalizeRef.current?.close();
          setcomfirmationVisible(true);
        }}>
        <View style={styles.row}>
          <H5 style={styles.modalText}>Delete</H5>
        </View>
      </TouchableOpacity>
      <View style={styles.horizontalLine}></View>
    </Modalize>
  );
}

const styles = StyleSheet.create({
  horizontalLine: {
    borderBottomColor: '#808080',
    borderBottomWidth: normalize(2),
  },
  row: {
    paddingVertical: normalize(15),
    flexDirection: 'row',
    justifyContent: 'center',
  },
  modalText: {
    textAlign: 'center',
    color: '#000000',
    justifyContent: 'center',
  },
  horizontalLine: {
    borderBottomColor: '#808080',
    borderBottomWidth: normalize(2),
  },
});
