import React, {useContext, useState} from 'react';
import {
  StyleSheet,
  View,
  TextInput,
  TouchableOpacity,
  Alert,
} from 'react-native';
import moment from 'moment';
import {normalize} from '../../../utils/Helper';
import {H5, P, ErrorMessage} from '../../common/Typography';
import {useNavigation} from '@react-navigation/native';
import {AuthContext} from '../../../contexts/AuthContext';
import DatePicker from 'react-native-date-picker';
import {register} from '../../../services/authService';
import {Country} from 'country-state-city';
import SelectDropdown from 'react-native-select-dropdown';

export default function RegisterForm() {
  const navigation = useNavigation();
  const {handleSignup} = useContext(AuthContext);
  const [inputData, setInputData] = useState({
    email: null,
    username: null,
    phone_no: null,
    country: null,
    dob: null,
    password: null,
    confirm_password: null,
  });

  const [inputError, setInputError] = useState({
    email: null,
    username: null,
    phone_no: null,
    country: null,
    dob: null,
    password: null,
    confirm_password: null,
  });

  const [openDatePicker, setOpenDatePicker] = useState(false);

  const submitRegister = async () => {
    let error = {};
    const emailFormat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w\w+)+$/;

    if (!inputData.email) {
      error = {...error, email: 'Email address is required.'};
    } else if (!emailFormat.test(inputData.email)) {
      error = {...error, email: 'Invalid email address.'};
    }

    if (!inputData.username) {
      error = {...error, username: 'Username is required.'};
    }

    if (!inputData.phone_no) {
      error = {...error, phone_no: 'Phone Number is required.'};
    }

    if (!inputData.country) {
      error = {...error, country: 'Country Code is required.'};
    }

    if (!inputData.dob) {
      error = {...error, dob: 'Birthday is required.'};
    }

    if (!inputData.password) {
      error = {...error, password: 'Password is required.'};
    } else if (inputData.password.length < 8) {
      error = {...error, password: 'Password length must be more than 8.'};
    }

    if (inputData.confirm_password != inputData.password) {
      error = {...error, confirm_password: 'Password not match.'};
    }

    setInputError(error);

    if (Object.keys(error).length === 0) {
      let response = await register(inputData);

      if (response.status == 200 && response.success) {
        handleSignup(response.token, response.userId);
      } else if (response.status == 422) {
        let error = {};
        response.error.forEach(response => {
          if (response.param == 'email') {
            error = {...error, email: response.msg};
          }
          if (response.param == 'username') {
            error = {...error, username: response.msg};
          }
          if (response.param == 'phone_no') {
            error = {...error, phone_no: response.msg};
          }
          if (response.param == 'country') {
            error = {...error, country: response.msg};
          }
          if (response.param == 'dob') {
            error = {...error, dob: response.msg};
          }
          if (response.param == 'password') {
            error = {...error, password: response.msg};
          }
        });
        setInputError(error);
      }
    }
  };

  return (
    <View>
      <View style={styles.inputGroup}>
        <P style={styles.inputLabel}>Email address</P>
        <TextInput
          style={styles.inputBox}
          placeholder="Email address"
          onChangeText={text => {
            setInputData({...inputData, email: text});
            setInputError({...inputError, email: null});
          }}
        />
        {inputError.email ? (
          <ErrorMessage>{inputError.email}</ErrorMessage>
        ) : (
          <></>
        )}
      </View>

      <View style={styles.inputGroup}>
        <P style={styles.inputLabel}>Username</P>
        <TextInput
          style={styles.inputBox}
          placeholder="Username"
          onChangeText={text => {
            setInputData({...inputData, username: text});
            setInputError({...inputError, username: null});
          }}
        />
        {inputError.username ? (
          <ErrorMessage>{inputError.username}</ErrorMessage>
        ) : (
          <></>
        )}
      </View>

      <View style={styles.inputGroup}>
        <P style={styles.inputLabel}>Phone Number</P>
        <TextInput
          style={styles.inputBox}
          placeholder="Phone Number"
          onChangeText={text => {
            setInputData({...inputData, phone_no: text});
            setInputError({...inputError, phone_no: null});
          }}
        />
        {inputError.phone_no ? (
          <ErrorMessage>{inputError.phone_no}</ErrorMessage>
        ) : (
          <></>
        )}
      </View>

      <View style={styles.inputGroup}>
        <P style={styles.inputLabel}>Country</P>
        <SelectDropdown
          defaultButtonText="Select a country"
          buttonStyle={styles.buttonStyle}
          dropdownStyle={styles.dropdownStyle}
          data={Country.getAllCountries()}
          onSelect={selectedItem => {
            setInputData({...inputData, country: selectedItem.isoCode});
            setInputError({...inputError, country: null});
          }}
          buttonTextAfterSelection={selectedItem => {
            return selectedItem.name;
          }}
          rowTextForSelection={item => {
            return item.name;
          }}
        />
        {inputError.country ? (
          <ErrorMessage>{inputError.country}</ErrorMessage>
        ) : (
          <></>
        )}
      </View>

      <View style={styles.inputGroup}>
        <P style={styles.inputLabel}>Birthday</P>

        <View style={styles.birthdayLabelRow}>
          <P style={styles.birthdayLabelColumn}>Day</P>
          <P style={styles.birthdayLabelColumn}>Month</P>
          <P style={styles.birthdayLabelColumn}>Year</P>
        </View>

        <TouchableOpacity onPress={() => setOpenDatePicker(true)}>
          {inputData.dob != null ? (
            <View style={styles.selectedDobDisplayRow}>
              <P style={styles.selectedDobDisplayColumn}>
                {moment(inputData.dob).format('DD')}
              </P>

              <P style={styles.selectedDobDisplayColumn}>
                {moment(inputData.dob).format('MMMM')}
              </P>

              <P style={styles.selectedDobDisplayColumn}>
                {moment(inputData.dob).format('YYYY')}
              </P>
            </View>
          ) : (
            <View style={styles.button}>
              <H5 style={styles.dateButtonText}>
                -- Please select your birthday --
              </H5>
            </View>
          )}
        </TouchableOpacity>

        <DatePicker
          modal
          mode="date"
          maximumDate={new Date()}
          open={openDatePicker}
          date={inputData.dob ?? new Date()}
          onConfirm={data => {
            setInputData({...inputData, dob: data});
            setInputError({...inputError, dob: null});
            setOpenDatePicker(false);
          }}
          onCancel={() => {
            setOpenDatePicker(false);
          }}
        />

        {inputError.dob ? <ErrorMessage>{inputError.dob}</ErrorMessage> : <></>}
      </View>

      <View style={styles.inputGroup}>
        <P style={styles.inputLabel}>Password</P>

        <TextInput
          style={styles.inputBox}
          placeholder="Password"
          secureTextEntry={true}
          onChangeText={text => {
            setInputData({...inputData, password: text});
            setInputError({...inputError, password: null});
          }}
        />
        {inputError.password ? (
          <ErrorMessage>{inputError.password}</ErrorMessage>
        ) : (
          <></>
        )}
      </View>

      <View style={styles.inputGroup}>
        <TextInput
          style={styles.inputBox}
          placeholder="Confirm Password"
          secureTextEntry={true}
          onChangeText={text => {
            setInputData({...inputData, confirm_password: text});
            setInputError({...inputError, confirm_password: null});
          }}
        />
        {inputError.confirm_password ? (
          <ErrorMessage>{inputError.confirm_password}</ErrorMessage>
        ) : (
          <></>
        )}
      </View>

      <TouchableOpacity
        onPress={() => {
          submitRegister();
        }}>
        <View style={[styles.button, styles.registerButton]}>
          <H5 style={styles.registerButtonText}>Register</H5>
        </View>
      </TouchableOpacity>

      <View style={styles.horizontalLineWithTextWrapper}>
        <View style={styles.horizontalLine} />
        <View>
          <P style={styles.horizontalLineText}>OR</P>
        </View>
        <View style={styles.horizontalLine} />
      </View>

      <View style={styles.flexContentCenterRow}>
        <TouchableOpacity onPress={() => navigation.navigate('Login')}>
          <P>Login</P>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  inputLabel: {
    paddingBottom: normalize(10),
  },
  inputGroup: {
    marginBottom: normalize(15),
  },
  inputBox: {
    backgroundColor: '#ffffff',
    padding: normalize(10),
    fontSize: normalize(15),
    borderRadius: normalize(10),
  },
  button: {
    backgroundColor: '#ffffff',
    padding: normalize(10),
    borderRadius: normalize(10),
  },
  registerButton: {
    marginVertical: normalize(30),
  },
  registerButtonText: {
    color: '#000000',
    textAlign: 'center',
  },
  birthdayLabelRow: {
    flexDirection: 'row',
    marginBottom: normalize(10),
  },
  birthdayLabelColumn: {
    color: '#D3D3D3',
    width: '33%',
    textAlign: 'center',
  },
  horizontalLineWithTextWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: normalize(20),
  },
  horizontalLine: {
    flex: 1,
    height: normalize(4),
    backgroundColor: '#ffffff',
  },
  horizontalLineText: {
    textAlign: 'center',
    paddingHorizontal: normalize(10),
  },
  flexContentCenterRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: normalize(20),
  },
  dateButtonText: {
    color: '#808080',
    fontSize: normalize(15),
    paddingVertical: normalize(4),
    textAlign: 'center',
  },
  selectedDobDisplayRow: {
    flexDirection: 'row',
    alignItems: 'center',
    color: '#000000',
    backgroundColor: '#ffffff',
    borderRadius: normalize(10),
    padding: normalize(10),
  },
  selectedDobDisplayColumn: {
    textAlign: 'center',
    color: '#000000',
    fontSize: normalize(15),
    width: '33%',
  },
  dropdownStyle: {
    borderRadius: normalize(10),
  },
  buttonStyle: {
    width: '100%',
    backgroundColor: '#ffffff',
    padding: normalize(10),
    fontSize: normalize(15),
    borderRadius: normalize(10),
  },
});
