import React, {useContext, useState} from 'react';
import {
  StyleSheet,
  View,
  TextInput,
  TouchableOpacity,
  Alert,
} from 'react-native';
import {normalize} from '../../../utils/Helper';
import {H5, P, ErrorMessage} from '../../common/Typography';
import {AuthContext} from '../../../contexts/AuthContext';
import {login} from '../../../services/authService';
import {useNavigation} from '@react-navigation/native';

export default function LoginForm() {
  const navigation = useNavigation();
  const {handleLogin} = useContext(AuthContext);

  const [inputData, setInputData] = useState({
    email: null,
    password: null,
  });
  const [inputError, setInputError] = useState({
    email: null,
    password: null,
    response_error: null,
  });

  const submitLogin = async () => {
    let error = {};

    if (!inputData.email) {
      error = {...error, email: 'Email address is required.'};
    }

    if (!inputData.password) {
      error = {...error, password: 'Password is required.'};
    }

    setInputError(error);

    if (Object.keys(error).length === 0) {
      let response = await login(inputData);

      if (response.status == 200 && response.success) {
        handleLogin(response.token, response.userId);
      } else if (response.status == 422) {
        let error = {};
        response.error.forEach(response => {
          if (response.param == 'email') {
            error = {...error, email: response.msg};
          }
          if (response.param == 'password') {
            error = {...error, password: response.msg};
          }
        });
        setInputError(error);
        return;
      } else if (!response.success) {
        setInputError({...inputError, response_error: response.message});
      }
    }
  };

  return (
    <View>
      <View style={styles.inputGroup}>
        <TextInput
          style={styles.inputBox}
          placeholder="Email address"
          onChangeText={text => {
            setInputData({...inputData, email: text});
            setInputError({...inputError, email: null});
          }}
        />
        {inputError.email ? (
          <ErrorMessage>{inputError.email}</ErrorMessage>
        ) : (
          <></>
        )}
      </View>

      <View style={styles.inputGroup}>
        <TextInput
          style={styles.inputBox}
          placeholder="Password"
          secureTextEntry={true}
          onChangeText={text => {
            setInputData({...inputData, password: text});
            setInputError({...inputError, password: null});
          }}
        />
        {inputError.password ? (
          <ErrorMessage>{inputError.password}</ErrorMessage>
        ) : (
          <></>
        )}
        {inputError.response_error ? (
          <ErrorMessage>{inputError.response_error}</ErrorMessage>
        ) : (
          <></>
        )}
      </View>

      <View style={styles.flexEnd}>
        <TouchableOpacity onPress={() => {}}>
          <P>Forgot Password?</P>
        </TouchableOpacity>
      </View>

      <TouchableOpacity
        onPress={() => {
          submitLogin();
        }}>
        <View style={styles.loginButton}>
          <H5 style={styles.loginButtonText}>Log In</H5>
        </View>
      </TouchableOpacity>

      <View style={styles.horizontalLineWithTextWrapper}>
        <View style={styles.horizontalLine} />
        <View>
          <P style={styles.horizontalLineText}>OR</P>
        </View>
        <View style={styles.horizontalLine} />
      </View>

      <View style={styles.flexContentCenterRow}>
        <TouchableOpacity onPress={() => navigation.navigate('Register')}>
          <P>Create An Account</P>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  inputGroup: {
    marginBottom: normalize(15),
  },
  inputBox: {
    backgroundColor: '#ffffff',
    padding: normalize(10),
    fontSize: normalize(15),
  },
  flexEnd: {
    alignItems: 'flex-end',
  },
  loginButton: {
    backgroundColor: '#ffffff',
    padding: normalize(10),
    marginVertical: normalize(30),
  },
  loginButtonText: {
    color: '#000000',
    textAlign: 'center',
  },
  horizontalLineWithTextWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: normalize(20),
  },
  horizontalLine: {
    flex: 1,
    height: normalize(4),
    backgroundColor: '#ffffff',
  },
  horizontalLineText: {
    textAlign: 'center',
    paddingHorizontal: normalize(10),
  },
  flexContentCenterRow: {
    flexDirection: 'row',
    justifyContent: 'center',
  },
});
