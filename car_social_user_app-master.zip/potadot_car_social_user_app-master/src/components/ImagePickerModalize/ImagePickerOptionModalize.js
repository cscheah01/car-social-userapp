import React from 'react';
import {StyleSheet, View, TouchableOpacity} from 'react-native';
import {Modalize} from 'react-native-modalize';
import {normalize} from '../../utils/Helper';
import {H5} from '../common/Typography';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';
import {PermissionsAndroid} from 'react-native';

export default function ({imagePickerOptionModalizeRef, setData}) {
  const option = {
    mediaType: 'photo',
    quality: 1,
  };

  const chooseImage = () => {
    launchImageLibrary(option, response => {
      imagePickerOptionModalizeRef.current?.close();
      if (response.didCancel) {
        return;
      } else if (response.errorCode == 'permission') {
        alert('Permission not satisfied');
        return;
      } else if (response.errorCode == 'others') {
        alert(response.errorMessage);
        return;
      }

      var responseData = response.assets[0];
      setData(responseData);
    });
  };

  const requestCameraPermission = async () => {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.CAMERA,
        {
          title: 'App Camera Permission',
          message: 'App needs access to your camera ',
          buttonNeutral: 'Ask Me Later',
          buttonNegative: 'Cancel',
          buttonPositive: 'OK',
        },
      );
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        let options = {
          storageOptions: {
            skipBackup: true,
            path: 'images',
          },
        };
        launchCamera(options, response => {
          imagePickerOptionModalizeRef.current?.close();
          if (response.didCancel) {
            return;
          } else if (response.errorCode == 'permission') {
            alert('Permission not satisfied');
            return;
          } else if (response.errorCode == 'others') {
            alert(response.errorMessage);
            return;
          }

          var responseData = response.assets[0];

          setData(responseData);
        });
      } else {
        alert('Camera permission denied');
      }
    } catch (err) {
      console.warn(err);
    }
  };
  return (
    <Modalize ref={imagePickerOptionModalizeRef} adjustToContentHeight={true}>
      <TouchableOpacity
        onPress={() => {
          requestCameraPermission();
        }}>
        <View style={styles.row}>
          <H5 style={styles.modalText}>Camera</H5>
        </View>
      </TouchableOpacity>
      <View style={styles.horizontalLine}></View>
      <TouchableOpacity
        onPress={() => {
          chooseImage();
        }}>
        <View style={styles.row}>
          <H5 style={styles.modalText}>Select Image</H5>
        </View>
      </TouchableOpacity>
    </Modalize>
  );
}

const styles = StyleSheet.create({
  label: {
    color: '#000000',
    marginLeft: normalize(12),
  },
  horizontalLine: {
    borderBottomColor: '#808080',
    borderBottomWidth: normalize(2),
  },
  row: {
    paddingVertical: normalize(15),
    flexDirection: 'row',
    justifyContent: 'center',
  },
  icon: {
    fontSize: normalize(20),
    color: '#000000',
  },
  modalText: {
    textAlign: 'center',
    color: '#000000',
    justifyContent: 'center',
  },
  horizontalLine: {
    borderBottomColor: '#808080',
    borderBottomWidth: normalize(2),
  },
});
