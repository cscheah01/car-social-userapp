import React from 'react';
import {Text, StyleSheet} from 'react-native';
import {normalize} from '../../utils/Helper';

export function H1({children, style, ...others}) {
  return (
    <Text
      {...others}
      children={children}
      style={{...styles.h1, ...style}}
      allowFontScaling={false}
    />
  );
}

export function H2({children, style, ...others}) {
  return (
    <Text
      numberOfLines={1}
      {...others}
      children={children}
      style={{...styles.h2, ...style}}
      allowFontScaling={false}
    />
  );
}

export function H3({children, style, ...others}) {
  return (
    <Text
      numberOfLines={1}
      {...others}
      children={children}
      style={{...styles.h3, ...style}}
      allowFontScaling={false}
    />
  );
}

export function H4({children, style}) {
  return (
    <Text
      children={children}
      style={{...styles.h4, ...style}}
      allowFontScaling={false}
    />
  );
}

export function H5({children, style, ...others}) {
  return (
    <Text
      {...others}
      children={children}
      style={{...styles.h5, ...style}}
      allowFontScaling={false}
    />
  );
}

export function P({children, style, ...others}) {
  return (
    <Text
      {...others}
      children={children}
      style={{...styles.p, ...style}}
      allowFontScaling={false}
    />
  );
}

export function ErrorMessage({children, style, ...others}) {
  return (
    <Text
      {...others}
      children={children}
      style={{...styles.errorMessage, ...style}}
      allowFontScaling={false}
    />
  );
}

const styles = StyleSheet.create({
  h1: {
    fontSize: normalize(24),
    fontWeight: 'bold',
    color: '#ffffff',
  },

  h2: {
    fontSize: normalize(22),
    fontWeight: 'bold',
    color: '#ffffff',
  },

  h3: {
    fontSize: normalize(20),
    fontWeight: 'bold',
    color: '#ffffff',
  },

  h4: {
    fontSize: normalize(18),
    fontWeight: '500',
    color: '#ffffff',
  },

  h5: {
    fontSize: normalize(16),
    fontWeight: '500',
    color: '#ffffff',
  },

  p: {
    fontSize: normalize(14),
    color: '#868686',
    color: '#ffffff',
  },
  errorMessage: {
    fontSize: normalize(14),
    color: '#ff0033',
  },
});
