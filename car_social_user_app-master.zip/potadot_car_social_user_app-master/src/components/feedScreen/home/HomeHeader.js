import React from 'react';
import {StyleSheet, View, TouchableOpacity} from 'react-native';
import {normalize} from '../../../utils/Helper';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {useNavigation} from '@react-navigation/native';
import {H4} from '../../common/Typography';

export default function HomeHeader() {
  const navigation = useNavigation();

  return (
    <View style={styles.wrapper}>
      <H4>Platform Name</H4>
      <View style={styles.rightSection}>
        <View style={styles.flexRow}>
          <View style={styles.rightSectionItem}>
            <TouchableOpacity onPress={() => navigation.navigate('CreatePost')}>
              <Icon name="plus-square" style={styles.icon} />
            </TouchableOpacity>
          </View>
          <View style={styles.rightSectionItem}>
            <TouchableOpacity onPress={() => navigation.navigate('Chat')}>
              <Icon name="comment-dots" style={styles.icon} />
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#000000',
    padding: normalize(10),
    borderBottomColor: '#ffffff',
    borderBottomWidth: normalize(3),
  },
  rightSection: {
    flex: 1,
    alignItems: 'flex-end',
  },
  flexRow: {
    flexDirection: 'row',
  },
  rightSectionItem: {
    marginLeft: normalize(18),
  },
  icon: {
    fontSize: normalize(18),
    color: '#ffffff',
  },
});
