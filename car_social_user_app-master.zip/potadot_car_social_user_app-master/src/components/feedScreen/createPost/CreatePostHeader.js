import React from 'react';
import {StyleSheet, View, TouchableOpacity} from 'react-native';
import {normalize} from '../../../utils/Helper';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {useNavigation} from '@react-navigation/native';
import {H4, H5} from '../../common/Typography';

export default function CreatePostHeader({disabledSubmit, submitCreatePost}) {
  const navigation = useNavigation();

  return (
    <View style={styles.wrapper}>
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <View style={(styles.flexRow, styles.backButton)}>
          <Icon name="arrow-left" style={styles.icon} />
        </View>
      </TouchableOpacity>

      <H4>Create post</H4>

      <View style={styles.rightSection}>
        <View style={styles.rightSectionItem}>
          <TouchableOpacity
            disabled={disabledSubmit}
            onPress={() => {
              submitCreatePost();
            }}>
            <View
              style={[
                styles.buttonBlue,
                disabledSubmit ? styles.disabledbutton : null,
              ]}>
              <H5 style={styles.buttonText}>Post</H5>
            </View>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#000000',
    padding: normalize(10),
    borderBottomColor: '#ffffff',
    borderBottomWidth: normalize(3),
  },
  backButton: {
    marginRight: normalize(18),
  },
  rightSection: {
    flex: 1,
    alignItems: 'flex-end',
  },
  flexRow: {
    flexDirection: 'row',
  },
  rightSectionItem: {
    marginLeft: normalize(20),
  },
  icon: {
    fontSize: normalize(15),
    color: '#ffffff',
  },
  buttonBlue: {
    width: normalize(70),
    backgroundColor: '#0057FF',
    borderRadius: normalize(10),
    paddingVertical: normalize(5),
  },
  buttonText: {
    textAlign: 'center',
    fontSize: normalize(14),
  },
  disabledbutton: {
    opacity: 0.4,
  },
});
