import React, {useState, useEffect} from 'react';
import {StyleSheet, View, TouchableOpacity} from 'react-native';
import {Modalize} from 'react-native-modalize';
import {normalize} from '../../../utils/Helper';
import {P} from '../../common/Typography';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';
import {PermissionsAndroid} from 'react-native';

const imagePickerOption = {
  image: {
    mediaType: 'photo',
    maxWidth: 300,
    maxHeight: 300,
    quality: 1,
    selectionLimit: 0,
    storageOptions: {
      skipBackup: true,
      path: 'images',
    },
  },
  video: {
    mediaType: 'video',
    videoQuality: 'high',
    durationLimit: 30,
    selectionLimit: 0,
    storageOptions: {
      skipBackup: true,
      path: 'video',
    },
  },
};

export default function ({
  imagePickerOptionModalizeRef,
  selectedData,
  setPostData,
}) {
  const [selectedMedia, setSelectedMedia] = useState(selectedData);

  useEffect(() => {
    setSelectedMedia(selectedData);
  }, [selectedData]);

  const selectMedia = option => {
    launchImageLibrary(option, response => {
      imagePickerOptionModalizeRef.current?.close();
      if (response.didCancel) {
        return;
      } else if (response.errorCode == 'permission') {
        alert('Permission not satisfied');
        return;
      } else if (response.errorCode == 'others') {
        alert(response.errorMessage);
        return;
      } else if (response.assets.length > 15 || selectedMedia.length > 15) {
        alert('Max selected image and video is 16.');
        return;
      }

      var responseData = response.assets;
      setPostData([...selectedMedia, ...responseData]);
    });
  };

  const requestCameraPermission = async () => {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.CAMERA,
        {
          title: 'App Camera Permission',
          message: 'App needs access to your camera ',
          buttonNeutral: 'Ask Me Later',
          buttonNegative: 'Cancel',
          buttonPositive: 'OK',
        },
      );
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        let options = {
          storageOptions: {
            skipBackup: true,
            path: 'images',
          },
        };
        launchCamera(options, response => {
          imagePickerOptionModalizeRef.current?.close();
          if (response.didCancel) {
            alert('User cancelled launch camera');
            return;
          } else if (response.errorCode == 'permission') {
            alert('Permission not satisfied');
            return;
          } else if (response.errorCode == 'others') {
            alert(response.errorMessage);
            return;
          } else if (response.assets.length > 15 || selectedMedia.length > 15) {
            alert('Max selected image and video is 16.');
            return;
          }
          var responseData = response.assets;
          setPostData([...selectedMedia, ...responseData]);
        });
      } else {
        alert('Camera permission denied');
      }
    } catch (err) {
      console.warn(err);
    }
  };
  return (
    <Modalize ref={imagePickerOptionModalizeRef} adjustToContentHeight={true}>
      <TouchableOpacity
        onPress={() => {
          requestCameraPermission();
        }}>
        <View style={styles.row}>
          <P style={styles.modalText}>Camera</P>
        </View>
      </TouchableOpacity>
      <View style={styles.horizontalLine}></View>
      <TouchableOpacity
        onPress={() => {
          selectMedia(imagePickerOption.image);
        }}>
        <View style={styles.row}>
          <P style={styles.modalText}>Select Image</P>
        </View>
      </TouchableOpacity>
      <View style={styles.horizontalLine}></View>
      <TouchableOpacity
        onPress={() => {
          selectMedia(imagePickerOption.video);
        }}>
        <View style={styles.row}>
          <P style={styles.modalText}>Select Video</P>
        </View>
      </TouchableOpacity>
    </Modalize>
  );
}

const styles = StyleSheet.create({
  label: {
    color: '#000000',
    marginLeft: normalize(12),
  },
  horizontalLine: {
    borderBottomColor: '#808080',
    borderBottomWidth: normalize(2),
  },
  row: {
    paddingVertical: normalize(15),
    flexDirection: 'row',
    justifyContent: 'center',
  },
  icon: {
    fontSize: normalize(20),
    color: '#000000',
  },
  modalText: {
    textAlign: 'center',
    color: '#000000',
    justifyContent: 'center',
  },
  horizontalLine: {
    borderBottomColor: '#808080',
    borderBottomWidth: normalize(2),
  },
});
