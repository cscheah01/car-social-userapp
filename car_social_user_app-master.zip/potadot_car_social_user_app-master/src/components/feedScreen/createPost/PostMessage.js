import React, {useState} from 'react';
import {StyleSheet, View} from 'react-native';
import {getScreenWidth, normalize} from '../../../utils/Helper';
import {TextInput} from 'react-native-gesture-handler';

export default function PostMessage({selectedData, setPostData}) {
  const [input, setInput] = useState(selectedData);

  return (
    <View>
      <TextInput
        style={styles.TextInput}
        placeholder="Share somethings..."
        placeholderTextColor="white"
        multiline={true}
        onChangeText={text => {
          setPostData(text);
        }}>
        {input}
      </TextInput>
    </View>
  );
}

const styles = StyleSheet.create({
  TextInput: {
    padding: normalize(20),
    fontSize: normalize(12),
    color: '#ffffff',
    width: getScreenWidth(),
  },
});
