import React, {useState, useEffect} from 'react';
import {
  StyleSheet,
  View,
  ScrollView,
  TouchableOpacity,
  Image,
} from 'react-native';
import {normalize} from '../../../utils/Helper';
import Icon from 'react-native-vector-icons/AntDesign';
import Video from 'react-native-video';

export default function ImageAndVideoSelector({
  selectedData,
  setPostData,
  openImagePickerOptionModalize,
}) {
  const [selectedMedia, setSelectedMedia] = useState(selectedData);

  useEffect(() => {
    setSelectedMedia(selectedData);
  }, [selectedData]);

  const removeMedia = media_uri => {
    setSelectedMedia(selectedMedia.filter(item => item.uri !== media_uri));
    setPostData(selectedMedia.filter(item => item.uri !== media_uri));
  };

  return (
    <View style={styles.wrapper}>
      <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
        {selectedMedia.map((media, index) => {
          if (media.type.includes('image')) {
            return (
              <View key={index}>
                <Image
                  source={{uri: media.uri}}
                  key={index}
                  style={styles.image}
                />
                <Icon
                  name="closecircle"
                  style={styles.removeIcon}
                  onPress={() => {
                    removeMedia(media.uri);
                  }}
                />
              </View>
            );
          } else if (media.type.includes('video')) {
            return (
              <View key={index}>
                <Video
                  source={{uri: media.uri}}
                  resizeMode={'cover'}
                  style={styles.video}
                />
                <Icon
                  name="closecircle"
                  style={styles.removeIcon}
                  onPress={() => {
                    removeMedia(media.uri);
                  }}
                />
              </View>
            );
          }
        })}
        <TouchableOpacity
          onPress={() => {
            openImagePickerOptionModalize();
          }}>
          <View style={[styles.uploadButton, styles.scrollViewItem]}>
            <Icon name="plus" style={styles.plusIcon} />
          </View>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#000000',
    padding: normalize(10),
    borderBottomColor: '#ffffff',
    borderBottomWidth: normalize(3),
  },
  scrollViewItem: {
    marginRight: normalize(10),
  },
  uploadButton: {
    backgroundColor: '#ffffff',
    width: normalize(60),
    height: normalize(60),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: normalize(10),
    marginBottom: normalize(9),
  },
  plusIcon: {
    fontSize: normalize(30),
    color: '#000000',
  },
  image: {
    width: normalize(60),
    height: normalize(60),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: normalize(10),
    marginRight: normalize(8),
  },
  video: {
    width: normalize(60),
    height: normalize(60),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: normalize(10),
    marginRight: normalize(8),
  },
  removeIcon: {
    color: '#ff0000',
    fontSize: normalize(12),
    position: 'absolute',
    right: normalize(5),
  },
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: normalize(22),
  },
  modalView: {
    margin: normalize(20),
    backgroundColor: '#ffffff',
    borderRadius: normalize(20),
    padding: normalize(35),
    alignItems: 'center',
    elevation: 5,
  },
  buttonClose: {
    backgroundColor: '#0057FF',
    borderRadius: normalize(20),
    padding: normalize(10),
    elevation: 2,
  },
  textStyle: {
    color: '#ffffff',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalText: {
    marginBottom: normalize(15),
    textAlign: 'center',
    color: '#000000',
  },
});
