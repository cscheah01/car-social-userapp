import React, {useState, useEffect} from 'react';
import {
  StyleSheet,
  View,
  TextInput,
  TouchableOpacity,
  Alert,
} from 'react-native';
import {normalize} from '../../../utils/Helper';
import {H5} from '../../common/Typography';
import {addComment} from '../../../services/postService';
import {useNavigation} from '@react-navigation/native';

export default function CommentInput({data}) {
  const navigation = useNavigation();
  const [postId, setPostId] = useState(data);
  const [inputData, setInputData] = useState({
    content: null,
    post_id: postId,
  });
  const [disabledSubmit, setDisabledSubmit] = useState(true);
  const [visible, setVisible] = useState(false);

  const checkTextInput = text => {
    if (text) {
      setVisible(true);
    } else {
      setVisible(false);
    }
  };

  const submitComment = async () => {
    let response = await addComment(inputData);

    if (response.status == 200 && response.success) {
      setInputData({...inputData, content: null});
      checkTextInput(null);
      navigation.addListener('focus', () => {
        navigate('SinglePost', {postId: postId});
      });
    } else if (response.status == 422) {
      Alert.alert('Add Comment Failed', JSON.stringify(response.error));
    }
  };

  useEffect(() => {
    setDisabledSubmit(true);

    if (inputData.content != null && inputData.content != '') {
      setDisabledSubmit(false);
    }
  }, [inputData]);

  return (
    <View style={styles.wrapper}>
      <View style={styles.horizontalWrapper}>
        <TextInput
          style={[
            {width: visible == false ? '100%' : '80%'},
            styles.commentInput,
          ]}
          placeholder="comment"
          value={inputData.content}
          onChangeText={text => {
            setInputData({...inputData, content: text});
            checkTextInput(text);
          }}
        />

        <TouchableOpacity
          disabled={disabledSubmit}
          onPress={() => {
            submitComment();
          }}>
          <View
            style={[
              styles.buttonBlue,
              disabledSubmit ? styles.disabledbutton : null,
              visible == false ? styles.hideButton : null,
            ]}>
            <H5 style={styles.buttonText}>Send</H5>
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    right: 0,
    left: 0,
    bottom: 0,
    position: 'absolute',
    backgroundColor: '#ffffff',
    padding: normalize(10),
  },
  horizontalWrapper: {
    flexDirection: 'row',
  },
  commentInput: {
    backgroundColor: '#C4C4C4',
    paddingVertical: normalize(5),
    paddingHorizontal: normalize(10),
    borderRadius: normalize(20),
  },
  inputWidth: {
    width: '100%',
  },
  inputWidthWithButton: {
    width: '80%',
  },
  buttonBlue: {
    width: normalize(60),
    backgroundColor: '#0057FF',
    borderRadius: normalize(10),
    paddingVertical: normalize(7),
    marginLeft: normalize(6.5),
  },
  buttonText: {
    textAlign: 'center',
    fontSize: normalize(14),
  },
  disabledbutton: {
    opacity: 0.4,
  },
  hideButton: {
    display: 'none',
  },
});
