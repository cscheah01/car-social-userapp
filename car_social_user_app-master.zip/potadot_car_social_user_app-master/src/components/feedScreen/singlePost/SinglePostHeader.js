import React, {useState, useRef, useCallback} from 'react';
import {StyleSheet, View, Image, TouchableOpacity} from 'react-native';
import {normalize, getScreenWidth} from '../../../utils/Helper';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {useNavigation} from '@react-navigation/native';
import {P} from '../../common/Typography';

export default function SinglePostHeader({data}) {
  const navigation = useNavigation();

  return (
    <View style={styles.wrapper}>
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <View style={(styles.flexRow, styles.backButton)}>
          <Icon name="arrow-left" style={styles.icon} />
        </View>
      </TouchableOpacity>

      <View style={styles.userDetailsSection}>
        {data.profile_image != null ? (
          <>
            <Image
              source={{uri: data.profile_image}}
              style={styles.userProfileImage}
            />
          </>
        ) : (
          <>
            <View style={styles.userProfileImage}></View>
          </>
        )}

        <P>{data.username}</P>
      </View>

      <View style={styles.rightSection}>
        <View style={styles.rightSectionItem}>
          <TouchableOpacity>
            <Icon name="ellipsis-v" style={styles.icon} />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#000000',
    padding: normalize(10),
    borderBottomColor: '#ffffff',
    borderBottomWidth: normalize(3),
  },
  rightSection: {
    flex: 1,
    alignItems: 'flex-end',
  },
  flexRow: {
    flexDirection: 'row',
  },
  rightSectionItem: {
    marginLeft: normalize(20),
  },
  icon: {
    fontSize: normalize(20),
    color: '#ffffff',
  },
  backButton: {
    marginRight: normalize(20),
  },
  userProfileImage: {
    height: normalize(30),
    width: normalize(30),
    borderRadius: normalize(30) / 2,
    marginRight: normalize(10),
    backgroundColor: '#1E1B1B',
    borderColor: '#ffffff',
    borderWidth: normalize(2),
  },
  userDetailsSection: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
});
