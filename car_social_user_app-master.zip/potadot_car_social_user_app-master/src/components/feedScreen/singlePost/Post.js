import React, {useState, useRef} from 'react';
import {StyleSheet, View, Image, TouchableOpacity, Alert} from 'react-native';
import {normalize, getScreenWidth} from '../../../utils/Helper';
import Carousel from 'react-native-snap-carousel';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {P, H3, H5} from '../../common/Typography';
import Dots from 'react-native-dots-pagination';
import {likePost, unlikePost} from '../../../services/postService';
import Video from 'react-native-video';

function renderItem({id, item, index}) {
  if (item.type.includes('image')) {
    return (
      <View key={id}>
        <Image source={{uri: item.url}} style={styles.feedImage} />
      </View>
    );
  } else if (item.type.includes('video')) {
    return (
      <View key={id}>
        <Video
          source={{uri: item.url}}
          resizeMode={'contain'}
          repeat={true}
          muted={false}
          style={styles.feedImage}
        />
      </View>
    );
  }
}

export default function Post({data}) {
  const isCarousel = useRef(null);
  const [activeSlideInddax, setActiveSlideInddax] = useState(0);
  const [postData, setpostData] = useState(data);
  const [isLiked, setIsLiked] = useState(postData.is_liked);
  const [totalLike, setTotalLike] = useState(postData.total_like);
  const [totalComment, setTotalComment] = useState(postData.total_comment);

  const onPressLike = async () => {
    if (isLiked) {
      setIsLiked(false);
      setTotalLike(totalLike - 1);

      let response = await unlikePost(postData.id);

      if (response.status == 422) {
        Alert.alert('Like Post Failed', JSON.stringify(response.error));
      }
    } else {
      setIsLiked(true);
      setTotalLike(totalLike + 1);

      let response = await likePost(postData.id);

      if (response.status == 422) {
        Alert.alert('Like Post Failed', JSON.stringify(response.error));
      }
    }
  };

  function totalCountFormatter(total) {
    const lookup = [
      {value: 1, symbol: ''},
      {value: 1e3, symbol: 'k'},
      {value: 1e6, symbol: 'M'},
    ];

    let result = lookup
      .slice()
      .reverse()
      .find(function (item) {
        return total >= item.value;
      });

    return result
      ? Number((total / result.value).toString().match(/^\d+(?:\.\d{0,1})?/)) +
          result.symbol
      : '0';
  }

  return (
    <View>
      <View style={styles.postWrapper}>
        <View>
          <Carousel
            ref={isCarousel}
            data={(postData.id, postData.media)}
            firstItem={0}
            renderItem={renderItem}
            onSnapToItem={index => setActiveSlideInddax(index)}
            sliderWidth={getScreenWidth()}
            itemWidth={getScreenWidth()}
            useScrollView
            activeSlideAlignment="start"
            inactiveSlideScale={1}
            inactiveSlideOpacity={1}
          />
          <Dots
            length={postData.media.length}
            active={activeSlideInddax}
            passiveColor={'rgba(255, 255, 255, 0.5)'}
            activeColor={'#ffffff'}
            width={normalize(55)}
            activeDotWidth={normalize(10)}
            activeDotHeight={normalize(10)}
            passiveDotWidth={normalize(7)}
            passiveDotHeight={normalize(7)}
          />
        </View>

        <View style={styles.bottomSection}>
          <View style={styles.bottomSectionRow1}>
            <TouchableOpacity
              onPress={() => {
                onPressLike();
              }}>
              <View style={styles.likeWraper}>
                <Icon
                  name="heart"
                  style={isLiked ? styles.likeIcon : styles.unlikeIcon}
                />
                <P>{totalCountFormatter(totalLike)} likes</P>
              </View>
            </TouchableOpacity>
            <View style={styles.commentWraper}>
              <Icon name="comment" style={styles.commentIcon} />
              <P>{totalCountFormatter(totalComment)} comments</P>
            </View>
          </View>
          <View style={styles.bottomSectionRow2}>
            <P>{postData.content}</P>
          </View>
        </View>
      </View>
      <H3 style={styles.title}>Comments</H3>
      {totalComment == 0 ? (
        <H5 style={styles.emptyData}>There is no comment for this post</H5>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  postWrapper: {
    paddingBottom: normalize(10),
    borderBottomWidth: normalize(2),
    borderBottomColor: '#ffffff',
  },
  feedImage: {
    height: getScreenWidth(),
    width: getScreenWidth(),
  },
  bottomSection: {
    margin: normalize(10),
  },
  bottomSectionRow1: {
    flexDirection: 'row',
  },
  bottomSectionRow2: {
    marginTop: normalize(5),
  },
  likeWraper: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: normalize(10),
  },
  likeIcon: {
    fontSize: normalize(12),
    color: '#FF0000',
    marginRight: normalize(5),
  },
  unlikeIcon: {
    fontSize: normalize(12),
    color: '#ffffff',
    marginRight: normalize(5),
  },
  commentWraper: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  commentIcon: {
    fontSize: normalize(12),
    color: '#ffffff',
    marginRight: normalize(5),
  },
  title: {
    marginVertical: normalize(10),
    paddingLeft: normalize(10),
  },
  emptyData: {
    color: '#808080',
    alignSelf: 'center',
  },
});
