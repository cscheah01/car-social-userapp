import React from 'react';
import {StyleSheet, View, Image} from 'react-native';
import {normalize} from '../../../utils/Helper';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {P} from '../../common/Typography';

import moment from 'moment';

export default function data({data}) {
  
  return (
    <View style={styles.wrapper}>
      <View style={styles.commentWrap}>
        <View style={styles.topSection}>
          {data.profile_image != null ? (
            <>
              <Image
                source={{
                  uri: data.profile_image,
                }}
                style={styles.userProfileImage}
              />
            </>
          ) : (
            <>
              <View style={styles.userProfileImage}></View>
            </>
          )}

          <P>{data.username}</P>
          <P style={styles.postDate}>{moment(data.created_at).fromNow()}</P>
        </View>
        <View style={styles.centerSection}>
          <P>{data.content}</P>
        </View>
        <View style={styles.bottomSection}>
          <View style={styles.likeWraper}>
            <Icon name="heart" style={styles.likeIcon} />
            <P>10</P>
          </View>
          <P>reply</P>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    margin: normalize(10),
  },
  title: {
    marginBottom: normalize(10),
  },
  commentWrap: {
    marginBottom: normalize(20),
  },
  topSection: {
    flexDirection: 'row',
    margin: normalize(10),
    marginBottom: 0,
    alignItems: 'center',
  },
  userProfileImage: {
    height: normalize(30),
    width: normalize(30),
    borderRadius: normalize(30) / 2,
    marginRight: normalize(10),
    backgroundColor: '#1E1B1B',
    borderColor: '#ffffff',
    borderWidth: normalize(2),
  },
  postDate: {
    color: 'rgba(255, 255, 255, 0.5)',
    fontSize: normalize(12),
    marginLeft: normalize(10),
  },
  centerSection: {
    marginLeft: normalize(50),
  },
  bottomSection: {
    marginLeft: normalize(50),
    marginTop: normalize(15),
    flexDirection: 'row',
  },
  likeWraper: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: normalize(15),
  },
  likeIcon: {
    fontSize: normalize(12),
    color: '#ffffff',
    marginRight: normalize(5),
  },
});
