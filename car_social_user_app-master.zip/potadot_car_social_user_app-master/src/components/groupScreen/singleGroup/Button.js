import React from 'react';
import {StyleSheet, View, TouchableOpacity} from 'react-native';
import {getScreenWidth, normalize} from '../../../utils/Helper';
import {P} from '../../common/Typography';

export default function () {
  return (
    <View style={styles.wrapper}>
      <View style={styles.buttonWrapper}>
        <TouchableOpacity>
          <View style={styles.button}>
            <P style={styles.buttonText}>Photos</P>
          </View>
        </TouchableOpacity>
        <TouchableOpacity>
          <View style={styles.button}>
            <P style={styles.buttonText}>Albums</P>
          </View>
        </TouchableOpacity>
        <TouchableOpacity>
          <View style={styles.button}>
            <P style={styles.buttonText}>Events</P>
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    backgroundColor: '#000000',
    padding: normalize(10),
  },
  buttonWrapper: {
    flexDirection: 'row',
    alignSelf: 'center',
  },
  button: {
    backgroundColor: '#000000',
    borderColor: '#ffffff',
    borderWidth: normalize(2),
    borderRadius: normalize(10),
    padding: normalize(10),
    marginHorizontal: normalize(7),
    width: normalize(90),
  },
  buttonText: {
    textAlign: 'center',
  },
});
