import React, {useState} from 'react';
import {StyleSheet, View, Image, TouchableOpacity} from 'react-native';
import {
  normalize,
  getScreenWidth,
  totalCountFormatter,
} from '../../../utils/Helper';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {P, H5} from '../../common/Typography';
import {useNavigation} from '@react-navigation/native';

export default function Group({data}) {
  const navigation = useNavigation();
  const [group, setGroup] = useState(data);

  return (
    <View key={group.id} style={styles.wrapper}>
      {group.background_image != null ? (
        <>
          <Image
            source={{uri: group.background_image}}
            style={styles.backgroundImage}></Image>
        </>
      ) : (
        <>
          <View style={styles.backgroundImage}></View>
        </>
      )}

      <View style={styles.bottomSection}>
        <View style={styles.mainLeftColumn}>
          {group.group_image != null ? (
            <>
              <Image
                source={{uri: group.group_image}}
                style={styles.groupImage}></Image>
            </>
          ) : (
            <>
              <View style={styles.groupImage}></View>
            </>
          )}
          <View style={styles.groupPrivacy}>
            <Icon
              name={group.is_private == true ? 'lock' : 'globe'}
              style={styles.icon}
            />
            <P>{group.is_private == true ? 'Private Group' : 'Public Group'}</P>
          </View>
        </View>
        <View style={styles.mainRightColumn}>
          <View>
            <H5>{group.name}</H5>
          </View>
          <View style={styles.wrapIconWithText}>
            <Icon name="user-friends" style={styles.icon} />
            <P style={styles.memberCount}>
              {totalCountFormatter(group.total_member)} members
            </P>
          </View>
          <View style={styles.buttonWrapper}>
            <TouchableOpacity style={styles.inviteButton}>
              <View style={styles.buttonBlue}>
                <H5 style={styles.buttonText}>Invite</H5>
              </View>
            </TouchableOpacity>
            {group.is_admin == false ? (
              <TouchableOpacity style={styles.button}>
                <View style={styles.buttonJoined}>
                  <H5 style={styles.buttonText}>Joined</H5>
                </View>
              </TouchableOpacity>
            ) : (
              <>
                <TouchableOpacity
                  style={styles.button}
                  onPress={() => {
                    navigation.navigate('Manage', {
                      groupName: group.name,
                      groupId: group.id,
                    });
                  }}>
                  <View style={styles.buttonBlue}>
                    <H5 style={styles.buttonText}>Manage</H5>
                  </View>
                </TouchableOpacity>
              </>
            )}
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    marginBottom: normalize(20),
  },
  backgroundImage: {
    aspectRatio: 1,
    width: getScreenWidth(),
  },
  bottomSection: {
    flexDirection: 'row',
    padding: normalize(10),
  },
  memberCount: {
    color: '#ffffff',
  },
  groupImage: {
    width: getScreenWidth() * 0.3,
    height: getScreenWidth() * 0.3,
    borderRadius: (getScreenWidth() * 0.3) / 2,
    position: 'absolute',
    top: -55,
    backgroundColor: '#1E1B1B',
    borderWidth: normalize(2),
    borderColor: '#ffffff',
  },
  mainLeftColumn: {
    width: '35%',
  },
  mainRightColumn: {
    paddingHorizontal: normalize(10),
    width: '65%',
  },
  groupPrivacy: {
    flexDirection: 'row',
    position: 'absolute',
    bottom: 0,
  },
  icon: {
    color: '#ffffff',
    marginRight: normalize(8),
    alignSelf: 'center',
    fontSize: normalize(18),
  },
  wrapIconWithText: {
    flexDirection: 'row',
    marginTop: normalize(5),
    marginBottom: normalize(10),
  },
  buttonWrapper: {
    flexDirection: 'row',
  },
  buttonBlue: {
    backgroundColor: '#0057FF',
    borderRadius: normalize(10),
    padding: normalize(10),
  },
  buttonJoined: {
    backgroundColor: '#192563',
    borderRadius: normalize(10),
    padding: normalize(10),
  },
  buttonText: {
    textAlign: 'center',
  },
  button: {
    width: '50%',
  },
  inviteButton: {
    width: '50%',
    marginRight: normalize(10),
  },
});
