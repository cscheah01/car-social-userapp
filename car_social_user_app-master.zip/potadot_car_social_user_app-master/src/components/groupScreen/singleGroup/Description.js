import React, {useState, useCallback} from 'react';
import {StyleSheet, View, TouchableWithoutFeedback} from 'react-native';
import {normalize} from '../../../utils/Helper';
import {P, H4} from '../../common/Typography';

export default function ({data}) {
  const [showSeeMore, setShowSeeMore] = useState(false);
  const [showAllContent, setShowAllContent] = useState(false);
  const [groupDetails, setGroupDetails] = useState(data);
  const onTextLayout = useCallback(e => {
    setShowSeeMore(e.nativeEvent.lines.length >= 4);
  }, []);
  return (
    <View style={styles.wrapper}>
      <H4>Description</H4>
      <TouchableWithoutFeedback
        onPress={() => setShowAllContent(!showAllContent)}>
        <View style={styles.wrapDescription}>
          <P
            style={styles.description}
            onTextLayout={onTextLayout}
            numberOfLines={showAllContent ? undefined : 3}>
            {groupDetails.description}
          </P>
          {!showAllContent && showSeeMore ? (
            <P style={[styles.textBold]}>See more</P>
          ) : null}
        </View>
      </TouchableWithoutFeedback>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    backgroundColor: '#000000',
    padding: normalize(10),
  },
  wrapDescription: {
    backgroundColor: '#1f1f1f',
    padding: normalize(10),
    borderRadius: normalize(10),
  },
  description: {
    textAlign: 'justify',
  },
  textBold: {
    fontWeight: 'bold',
  },
});
