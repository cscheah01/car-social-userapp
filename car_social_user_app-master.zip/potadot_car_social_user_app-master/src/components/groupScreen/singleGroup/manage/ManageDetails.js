import React, {useState, useEffect} from 'react';
import {StyleSheet, View, TouchableOpacity} from 'react-native';
import {normalize, totalCountFormatter} from '../../../../utils/Helper';
import Icon from 'react-native-vector-icons/FontAwesome5';
import FeatherIcon from 'react-native-vector-icons/Feather';
import EvilIcon from 'react-native-vector-icons/EvilIcons';
import {P, H4} from '../../../common/Typography';
import {useNavigation} from '@react-navigation/native';
import {getTotalMemberRequest} from '../../../../services/groupService';

export default function ManageDetails({groupId}) {
  const navigation = useNavigation();
  const [totalRequest, setTotalRequest] = useState(0);

  useEffect(() => {
    async function fetchData() {
      let response = await getTotalMemberRequest(groupId);

      setTotalRequest(response.data);
    }

    fetchData();
  }, []);

  return (
    <View>
      <View style={styles.mainWrapper}>
        <H4 style={styles.label}>Review</H4>
        <TouchableOpacity
          style={styles.wrapper}
          onPress={() =>
            navigation.navigate('MemberRequest', {
              groupId: groupId,
              totalRequest: totalRequest,
            })
          }>
          <FeatherIcon name="user-plus" style={styles.FeatherIcon} />
          <P>Member requests </P>
          <P style={totalRequest != 0 ? styles.primaryText : null}>
            {totalRequest != 0 ? totalCountFormatter(totalRequest) : null}
          </P>
          <View style={styles.rightSection}>
            <Icon name="chevron-right" style={styles.FontAwesomeIcon} />
          </View>
        </TouchableOpacity>
        <H4 style={styles.label}>Settings</H4>
        <TouchableOpacity
          style={styles.wrapper}
          onPress={() =>
            navigation.navigate('GroupSetting', {
              groupId: groupId,
            })
          }>
          <EvilIcon name="gear" style={styles.FeatherIcon} />
          <P>Group Setting</P>
          <View style={styles.rightSection}>
            <Icon name="chevron-right" style={styles.FontAwesomeIcon} />
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  mainWrapper: {
    paddingVertical: normalize(15),
    paddingHorizontal: normalize(20),
  },
  label: {
    paddingLeft: normalize(5),
    paddingBottom: normalize(10),
    marginBottom: normalize(5),
  },
  FontAwesomeIcon: {
    color: '#ffffff',
    fontSize: normalize(16),
  },
  FeatherIcon: {
    color: '#ffffff',
    fontSize: normalize(25),
    marginRight: normalize(10),
  },
  row: {
    flex: 1,
    flexDirection: 'row',
    fontColor: '#ffffff',
  },
  wrapper: {
    flexDirection: 'row',
    marginBottom: normalize(20),
    alignItems: 'center',
  },
  rightSection: {
    flex: 1,
    alignItems: 'flex-end',
  },
  primaryText: {
    color: '#ffffff',
    fontWeight: 'bold',
    backgroundColor: '#007bff',
    width: normalize(30),
    borderRadius: normalize(5),
    textAlign: 'center',
  },
});
