import React from 'react';
import {StyleSheet, View} from 'react-native';
import {normalize} from '../../../../../../utils/Helper';
import {Country, State, City} from 'country-state-city';
import SelectDropdown from 'react-native-select-dropdown';
import {P, ErrorMessage} from '../../../../../common/Typography';

export default function EditCountryForm({
  setInputData,
  inputData,
  setInputError,
  inputError,
}) {
  let location = Country.getCountryByCode(inputData);

  return (
    <View>
      <View style={styles.inputGroup}>
        <P style={styles.inputLabel}>Country</P>
        <SelectDropdown
          defaultButtonText="Select a country"
          buttonStyle={styles.buttonStyle}
          dropdownStyle={styles.dropdownStyle}
          data={Country.getAllCountries()}
          defaultValue={location}
          onSelect={selectedItem => {
            setInputData({...inputData, country: selectedItem.isoCode});
            setInputError({...inputError, country: null});
          }}
          buttonTextAfterSelection={selectedItem => {
            return selectedItem.name;
          }}
          rowTextForSelection={item => {
            return item.name;
          }}
        />
        {inputError ? <ErrorMessage>{inputError}</ErrorMessage> : <></>}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  inputGroup: {
    marginBottom: normalize(15),
  },
  inputLabel: {
    paddingBottom: normalize(10),
  },
  dropdownStyle: {
    borderRadius: normalize(10),
  },
  buttonStyle: {
    width: '100%',
    backgroundColor: '#ffffff',
    padding: normalize(10),
    fontSize: normalize(15),
    borderRadius: normalize(10),
  },
});
