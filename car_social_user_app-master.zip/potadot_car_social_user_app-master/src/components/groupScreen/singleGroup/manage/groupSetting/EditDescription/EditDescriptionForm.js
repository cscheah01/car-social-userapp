import React from 'react';
import {StyleSheet, View, TextInput} from 'react-native';
import {normalize} from '../../../../../../utils/Helper';

export default function EditDescriptionForm({setInputData, inputData}) {
  return (
    <View>
      <View style={styles.inputGroup}>
        <TextInput
          style={styles.inputBox}
          value={inputData}
          placeholder="Description"
          multiline={true}
          onChangeText={text => {
            setInputData({...inputData, description: text});
          }}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  inputGroup: {
    marginBottom: normalize(15),
  },
  inputBox: {
    backgroundColor: '#ffffff',
    padding: normalize(10),
    fontSize: normalize(15),
    borderRadius: normalize(10),
  },
  textStyle: {
    color: '#b2b2b2',
  },
});
