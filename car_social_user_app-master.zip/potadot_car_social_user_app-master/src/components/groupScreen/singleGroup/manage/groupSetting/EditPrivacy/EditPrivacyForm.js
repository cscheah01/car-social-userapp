import React from 'react';
import {StyleSheet, View, TouchableOpacity} from 'react-native';
import {normalize} from '../../../../../../utils/Helper';
import {P, H5} from '../../../../../common/Typography';
import Icon from 'react-native-vector-icons/FontAwesome5';

export default function EditPrivacyForm({setInputData, inputData}) {
  return (
    <View>
      <P style={styles.inputLabel}>Privacy</P>
      <View style={styles.inputGroup}>
        <TouchableOpacity
          style={styles.row}
          onPress={() => {
            setInputData({...inputData, is_private: false});
          }}>
          <View style={styles.rowLabelWrapper}>
            <Icon name="globe" style={styles.icon} />
            <H5 style={styles.rowLabel}>Public</H5>
          </View>

          <View style={styles.rowRadioButtonWrapper}>
            <View
              style={
                inputData == false
                  ? styles.activeRadioButton
                  : styles.unactiveRadioButton
              }></View>
          </View>
        </TouchableOpacity>
      </View>
      <View style={styles.inputGroup}>
        <TouchableOpacity
          style={styles.row}
          onPress={() => {
            setInputData({...inputData, is_private: true});
          }}>
          <View style={styles.rowLabelWrapper}>
            <Icon name="lock" style={styles.icon} />
            <H5 style={styles.rowLabel}>Private</H5>
          </View>

          <View style={styles.rowRadioButtonWrapper}>
            <View
              style={
                inputData == true
                  ? styles.activeRadioButton
                  : styles.unactiveRadioButton
              }></View>
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  inputLabel: {
    paddingBottom: normalize(10),
  },
  inputGroup: {
    marginBottom: normalize(15),
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  rowLabelWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  rowLabel: {
    marginLeft: normalize(10),
  },
  icon: {
    fontSize: normalize(25),
    color: '#ffffff',
  },
  rowRadioButtonWrapper: {
    flex: 1,
    alignItems: 'flex-end',
  },
  activeRadioButton: {
    backgroundColor: '#0057FF',
    borderColor: '#ffffff',
    borderWidth: normalize(5),
    borderRadius: normalize(30),
    width: normalize(20),
    height: normalize(20),
  },
  unactiveRadioButton: {
    backgroundColor: '#ffffff',
    borderColor: '#ffffff',
    borderWidth: normalize(5),
    borderRadius: normalize(30),
    width: normalize(20),
    height: normalize(20),
  },
});
