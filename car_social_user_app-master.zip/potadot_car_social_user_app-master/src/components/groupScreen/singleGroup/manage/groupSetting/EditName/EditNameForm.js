import React, {useEffect, useState} from 'react';
import {StyleSheet, View, TextInput} from 'react-native';
import {normalize} from '../../../../../../utils/Helper';
import {P, ErrorMessage} from '../../../../../common/Typography';

export default function EditNameForm({
  inputError,
  setInputData,
  inputData,
  setInputError,
}) {
  const [textLength, setTextLength] = useState(0);
  const [username, setUsername] = useState(inputData);
  const maxLength = 255;

  useEffect(() => {
    setTextLength(username.length);
  }, [username]);

  return (
    <View>
      <View style={styles.inputGroup}>
        <TextInput
          maxLength={maxLength}
          style={styles.inputBox}
          value={inputData}
          placeholder="Username"
          onChangeText={text => {
            setUsername(text);
            setInputData({...inputData, name: text});
            setInputError({name: null});
          }}
        />
        {inputError ? <ErrorMessage>{inputError}</ErrorMessage> : <></>}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  inputGroup: {
    marginBottom: normalize(15),
  },
  inputBox: {
    backgroundColor: '#ffffff',
    padding: normalize(10),
    fontSize: normalize(15),
    borderRadius: normalize(10),
  },
  textStyle: {
    color: '#b2b2b2',
  },
  flexRow: {
    flexDirection: 'row',
  },
  rightSection: {
    flex: 1,
    alignItems: 'flex-end',
  },
});
