import React, {useState, useEffect} from 'react';
import {StyleSheet, View, Image, TouchableOpacity} from 'react-native';
import {normalize} from '../../../../../utils/Helper';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {P} from '../../../../common/Typography';
import {useNavigation} from '@react-navigation/native';
import {Country} from 'country-state-city';

export default function GroupSettingDetails({
  data,
  setImageType,
  openImagePickerOptionModalize,
}) {
  const navigation = useNavigation();
  let location = Country.getCountryByCode(data.country);

  const [groupDetails, setGroupDetails] = useState(data);

  useEffect(() => {
    setGroupDetails(data);
  }, [data]);

  return (
    <View>
      <View style={styles.mainWrapper}>
        <View style={styles.groupImageWrapper}>
          <TouchableOpacity
            onPress={() => {
              openImagePickerOptionModalize();
              setImageType('group_image');
            }}>
            {groupDetails.group_image != null ? (
              <>
                <Image
                  source={{uri: groupDetails.group_image}}
                  style={styles.groupImage}
                />
              </>
            ) : (
              <>
                <View style={styles.groupImage}></View>
              </>
            )}

            <Icon name="camera" style={styles.cameraIcon} />
          </TouchableOpacity>
        </View>

        <TouchableOpacity
          style={styles.wrapper}
          onPress={() => {
            navigation.navigate('EditName', {
              name: groupDetails.name,
              groupId: groupDetails.id,
            });
          }}>
          <P style={styles.label}>Name</P>
          <P style={styles.data}>{groupDetails.name}</P>
          <View style={styles.rightSection}>
            <Icon name="chevron-right" style={styles.rowIcon} />
          </View>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.wrapper}
          onPress={() => {
            navigation.navigate('EditDescription', {
              description: groupDetails.description,
              groupId: groupDetails.id,
            });
          }}>
          <P style={styles.label}>Description</P>
          <P style={styles.data}>{groupDetails.description ?? '-'}</P>
          <View style={styles.rightSection}>
            <Icon name="chevron-right" style={styles.rowIcon} />
          </View>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.wrapper}
          onPress={() => {
            openImagePickerOptionModalize();
            setImageType('background_image');
          }}>
          <P style={styles.label}>Background Image</P>
          <Image
            source={{uri: groupDetails.background_image}}
            style={styles.userBackgroundImage}></Image>
          <View style={styles.rightSection}>
            <Icon name="chevron-right" style={styles.rowIcon} />
          </View>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.wrapper}
          onPress={() => {
            navigation.navigate('EditCountry', {
              country: groupDetails.country,
              groupId: groupDetails.id,
            });
          }}>
          <P style={styles.label}>Location</P>
          <P style={styles.data}>{location.name}</P>
          <View style={styles.rightSection}>
            <Icon name="chevron-right" style={styles.rowIcon} />
          </View>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.wrapper}
          onPress={() => {
            navigation.navigate('EditPrivacy', {
              is_private: groupDetails.is_private,
              groupId: groupDetails.id,
            });
          }}>
          <P style={styles.label}>Privacy</P>
          <P style={styles.data}>
            {groupDetails.is_private == true ? 'Private' : 'Public'}
          </P>
          <View style={styles.rightSection}>
            <Icon name="chevron-right" style={styles.rowIcon} />
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  mainWrapper: {
    paddingVertical: normalize(15),
    paddingHorizontal: normalize(20),
  },
  groupImage: {
    height: normalize(100),
    width: normalize(100),
    borderRadius: normalize(50),
    marginLeft: normalize(5),
    backgroundColor: '#1E1B1B',
    borderWidth: normalize(2),
    borderColor: '#ffffff',
    resizeMode: 'contain',
  },
  userBackgroundImage: {
    height: normalize(50),
    width: normalize(60),
    marginLeft: normalize(30),
    marginRight: normalize(80),
  },
  groupImageWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingBottom: normalize(10),
  },
  label: {
    color: '#ffffff',
    fontSize: normalize(14),
    width: normalize(80),
    fontWeight: 'bold',
  },
  data: {
    color: '#ffffff',
    marginLeft: normalize(30),
    fontSize: normalize(14),
    width: normalize(140),
  },
  rowIcon: {
    color: '#ffffff',
    fontSize: normalize(16),
    marginTop: normalize(5),
    marginLeft: normalize(30),
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    height: normalize(70),
    width: normalize(250),
    marginHorizontal: normalize(6),
    paddingLeft: normalize(10),
    fontColor: '#ffffff',
  },
  editProfileButton: {
    marginLeft: normalize(128),
  },
  editProfile: {
    width: normalize(90),
    height: normalize(35),
    fontColor: '#ffffff',
    backgroundColor: 'rgba(0,0,0,0.6)',
    borderWidth: normalize(2),
    borderRadius: normalize(10),
    borderColor: '#ffffff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  cameraIcon: {
    fontSize: normalize(16),
    color: '#ffffff',
    position: 'absolute',
    paddingLeft: normalize(80),
    paddingBottom: normalize(80),
  },
  wrapper: {
    flexDirection: 'row',
    marginVertical: normalize(20),
    alignItems: 'center',
  },
  rightSection: {
    flex: 1,
    alignItems: 'flex-end',
  },
});
