import React, {useEffect, useState} from 'react';
import {StyleSheet, View, TouchableOpacity, FlatList} from 'react-native';
import {normalize, totalCountFormatter} from '../../../../../utils/Helper';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {H4} from '../../../../common/Typography';
import Request from '../memberRequest/Request';
import {
  acceptRequest,
  declineRequest,
  getMemberRequest,
} from '../../../../../services/groupService';
import {useNavigation} from '@react-navigation/native';

export default function MemberRequestDetails({groupId, totalRequest}) {
  const navigation = useNavigation();
  const [page, setPage] = useState(1);
  const [request, setRequest] = useState('');
  const [disableLoading, setDisableLoading] = useState(false);

  const loadMore = () => {
    setPage(page + 1);
  };

  useEffect(() => {
    async function fetchData() {
      let response = await getMemberRequest(groupId, page);
      if (response.data.length == 0) {
        setDisableLoading(true);
      } else {
        if (request == '') {
          setRequest(response.data);
        } else {
          setRequest([...request, ...response.data]);
        }
      }
    }

    fetchData();
  }, []);

  const onSubmitAcceptRequest = async userId => {
    let response = await acceptRequest(userId, groupId);

    if (response.status == 200 && response.success) {
      navigation.goBack();
    } else if (response.status == 422) {
      Alert.alert('Accept Request Failed', JSON.stringify(response.error));
    }
  };

  const onSubmitDeclineRequest = async user_id => {
    let response = await declineRequest(user_id, groupId);

    if (response.status == 200 && response.success) {
      navigation.goBack();
    } else if (response.status == 422) {
      Alert.alert('Decline Request Failed', JSON.stringify(response.error));
    }
  };

  return (
    <View style={styles.mainWrapper}>
      <View style={styles.row}>
        <H4 style={styles.label}>
          {totalCountFormatter(totalRequest)} requests
        </H4>
        <View style={styles.rightSection}>
          <TouchableOpacity>
            <Icon name="search" style={styles.FontAwesomeIcon} />
          </TouchableOpacity>
        </View>
      </View>
      <FlatList
        showsVerticalScrollIndicator={false}
        data={request}
        keyExtractor={item => item.id}
        renderItem={({item}) => (
          <Request
            data={item}
            onSubmitAcceptRequest={onSubmitAcceptRequest}
            onSubmitDeclineRequest={onSubmitDeclineRequest}
            onEndReached={disableLoading == true ? null : loadMore}
          />
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  mainWrapper: {
    paddingVertical: normalize(15),
    paddingHorizontal: normalize(10),
  },
  label: {
    justifyContent: 'center',
  },
  FontAwesomeIcon: {
    color: '#ffffff',
    fontSize: normalize(16),
  },
  row: {
    flex: 1,
    flexDirection: 'row',
  },
  rightSection: {
    flex: 1,
    alignItems: 'flex-end',
    justifyContent: 'center',
  },
});
