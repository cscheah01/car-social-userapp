import React from 'react';
import {StyleSheet, View, TouchableOpacity} from 'react-native';
import {normalize} from '../../../../../utils/Helper';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {useNavigation} from '@react-navigation/native';
import {H4} from '../../../../common/Typography';

export default function () {
  const navigation = useNavigation();

  return (
    <View style={styles.wrapper}>
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <View style={(styles.flexRow, styles.backButton)}>
          <Icon name="arrow-left" style={styles.icon} />
        </View>
      </TouchableOpacity>
      <View style={styles.headerLabel}>
        <H4>Member Requests</H4>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#000000',
    padding: normalize(10),
    borderBottomColor: '#ffffff',
    borderBottomWidth: normalize(3),
  },
  flexRow: {
    flexDirection: 'row',
  },
  icon: {
    fontSize: normalize(18),
    color: '#ffffff',
  },
  backButton: {
    marginRight: normalize(20),
  },
  headerLabel: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: normalize(20),
  },
});
