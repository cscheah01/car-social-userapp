import React from 'react';
import {StyleSheet, View, Image, TouchableOpacity} from 'react-native';
import {normalize} from '../../../../../utils/Helper';
import {P} from '../../../../common/Typography';

export default function Request({
  data,
  onSubmitAcceptRequest,
  onSubmitDeclineRequest,
}) {
  return (
    <View style={styles.wrapper}>
      <View style={styles.wrapRequest}>
        <View style={styles.wrapProfilePicture}>
          <Image
            source={{
              uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSzHQv_th9wq3ivQ1CVk7UZRxhbPq64oQrg5Q&usqp=CAU',
            }}
            style={styles.userProfileImage}
          />
        </View>
        <View style={styles.rightSection}>
          <View style={styles.topSection}>
            <P>{data.username}</P>
          </View>
          <View style={styles.buttonWrapper}>
            <TouchableOpacity
              onPress={() => {
                onSubmitAcceptRequest(data.user_id);
              }}>
              <View style={styles.acceptButton}>
                <P style={styles.buttonText}>Accept</P>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => {
                onSubmitDeclineRequest(data.user_id);
              }}>
              <View style={styles.declineButton}>
                <P style={styles.buttonText}>Decline</P>
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    padding: normalize(15),
    borderBottomColor: '#ffffff',
    borderBottomWidth: normalize(3),
  },
  wrapRequest: {
    flexDirection: 'row',
    padding: normalize(5),
  },
  wrapProfilePicture: {
    justifyContent: 'center',
    marginRight: normalize(20),
  },
  topSection: {
    flexDirection: 'row',
    marginBottom: normalize(10),
  },
  rightSection: {
    alignContent: 'flex-end',
    justifyContent: 'center',
  },
  userProfileImage: {
    height: normalize(50),
    width: normalize(50),
    borderRadius: normalize(30),
  },
  buttonWrapper: {
    flexDirection: 'row',
    alignSelf: 'flex-end',
  },
  declineButton: {
    backgroundColor: '#2c2c2c',
    borderRadius: normalize(10),
    marginHorizontal: normalize(7),
    padding: normalize(10),
    width: normalize(100),
  },
  acceptButton: {
    backgroundColor: '#0057FF',
    borderRadius: normalize(10),
    padding: normalize(10),
    width: normalize(100),
  },
  buttonText: {
    textAlign: 'center',
  },
  Icon: {
    color: '#000000',
    fontSize: normalize(25),
  },
});
