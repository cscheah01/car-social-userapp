import React, {useState} from 'react';
import {StyleSheet, View, Image, TouchableOpacity} from 'react-native';
import {
  normalize,
  getScreenWidth,
  totalCountFormatter,
} from '../../../utils/Helper';
import {P, H5} from '../../common/Typography';
import {useNavigation} from '@react-navigation/native';
export default function Group({data}) {
  const navigation = useNavigation();
  return (
    <View key={data.id} style={styles.wrapper}>
      <Image source={{uri: data.background_image}} style={styles.image} />
      <View style={styles.bottomSection}>
        <View>
          <H5>{data.name}</H5>
          <P style={styles.memberCount}>
            {totalCountFormatter(data.total_member)} members
          </P>
        </View>
        <View style={styles.buttonWrapper}>
          <TouchableOpacity
            onPress={() => {
              navigation.navigate('SingleGroup', {groupId: data.group_id});
            }}>
            <View style={styles.buttonBlue}>
              <H5 style={styles.buttonText}>View</H5>
            </View>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    marginBottom: normalize(40),
  },
  image: {
    height: getScreenWidth(),
    width: getScreenWidth(),
  },
  bottomSection: {
    flexDirection: 'row',
    padding: normalize(10),
  },
  memberCount: {
    color: 'rgba(255, 255, 255, 0.5)',
  },
  buttonWrapper: {
    flex: 1,
    marginLeft: normalize(15),
  },
  buttonBlue: {
    backgroundColor: '#0057FF',
    borderRadius: normalize(10),
    padding: normalize(10),
  },
  buttonText: {
    textAlign: 'center',
  },
});
