import React from 'react';
import {StyleSheet, View, TouchableOpacity} from 'react-native';
import {P} from '../../common/Typography';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {Modalize} from 'react-native-modalize';
import {normalize} from '../../../utils/Helper';

export default function ({shareModalizeRef}) {
  return (
    <Modalize ref={shareModalizeRef} adjustToContentHeight={true}>
      <TouchableOpacity onPress={() => {}}>
        <View style={styles.row}>
          <Icon name="edit" style={styles.icon}></Icon>
          <P style={styles.label}>Share to New Feed</P>
        </View>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => {}}>
        <View style={styles.row}>
          <Icon name="paper-plane" style={styles.icon}></Icon>
          <P style={styles.label}>Share to Chat</P>
        </View>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => {}}>
        <View style={styles.row}>
          <Icon name="copy" style={styles.icon}></Icon>
          <P style={styles.label}>Copy Link</P>
        </View>
      </TouchableOpacity>
    </Modalize>
  );
}

const styles = StyleSheet.create({
  label: {
    color: '#000000',
    marginLeft: normalize(12),
    fontSize: normalize(16),
  },

  row: {
    paddingHorizontal: normalize(10),
    paddingVertical: normalize(15),
    flexDirection: 'row',
    alignItems: 'center',
  },
  icon: {
    fontSize: normalize(20),
    color: '#000000',
  },
});
