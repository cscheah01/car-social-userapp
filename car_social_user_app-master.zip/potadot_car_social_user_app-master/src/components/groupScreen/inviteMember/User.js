import React from 'react';
import {StyleSheet, View, Image, TouchableOpacity} from 'react-native';
import {normalize} from '../../../utils/Helper';
import {P} from '../../common/Typography';

export default function ({data}) {
  return (
    <View style={styles.mainWrapper}>
      <Image source={{uri: data.image}} style={styles.image} />
      <View style={styles.detailsWrapper}>
        <P style={styles.username}>{data.name}</P>
        <P style={styles.bio} numberOfLines={1} ellipsizeMode="tail">
          {data.bio}
        </P>
      </View>

      <TouchableOpacity>
        <View style={[styles.button, styles.buttonFollow]}>
          <P>Invite</P>
        </View>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  mainWrapper: {
    marginBottom: normalize(5),
    flexDirection: 'row',
    backgroundColor: '#1D1D1D',
    padding: normalize(10),
    alignItems: 'center',
  },
  image: {
    height: normalize(50),
    width: normalize(50),
    borderRadius: normalize(50) / 2,
  },

  detailsWrapper: {
    flexDirection: 'column',
    flex: 1,
    paddingHorizontal: normalize(10),
  },
  username: {
    fontWeight: 'bold',
  },
  bio: {
    marginTop: normalize(5),
    color: 'rgba(255, 255, 255, 0.5)',
  },
  button: {
    borderRadius: normalize(20),
    paddingHorizontal: normalize(10),
    paddingVertical: normalize(5),
  },
  buttonFollowing: {
    backgroundColor: '#192563',
  },
  buttonFollow: {
    backgroundColor: '#0057FF',
    borderRadius: normalize(20),
  },
});
