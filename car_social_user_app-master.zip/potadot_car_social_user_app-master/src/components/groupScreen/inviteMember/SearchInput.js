import React, {useState} from 'react';
import {StyleSheet, View, TouchableOpacity, TextInput} from 'react-native';
import {normalize} from '../../../utils/Helper';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {P} from '../../common/Typography';

export default function InviteMember({openShareModalize}) {
  const [searchInput, setSearchInput] = useState(null);

  return (
    <View>
      <View style={styles.mainWrapper}>
        <TouchableOpacity
          onPress={() => {
            openShareModalize();
          }}>
          <View style={styles.row}>
            <Icon name="share-alt" style={styles.rowIcon} />
            <P style={styles.text}>Share</P>
            <View style={styles.iconWrapper}>
              <Icon name="chevron-right" style={styles.rowIcon} />
            </View>
          </View>
        </TouchableOpacity>
        <View style={styles.inputGroup}>
          <Icon style={styles.searchIcon} name="search" />
          <TextInput
            style={styles.inputBox}
            placeholder="Search"
            onChangeText={text => {
              setSearchInput(text);
            }}
          />
        </View>
        {searchInput ? (
          <>
            <View>
              <P style={styles.text}>{'Result for "' + searchInput + '"'}</P>
            </View>
          </>
        ) : (
          <></>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  mainWrapper: {
    flex: 1,
    marginBottom: normalize(10),
  },
  rowIcon: {
    color: '#ffffff',
    fontSize: normalize(16),
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    height: normalize(70),
    marginHorizontal: normalize(6),
    paddingLeft: normalize(10),
    fontColor: '#ffffff',
  },
  text: {
    color: '#ffffff',
    fontSize: normalize(16),
    width: normalize(200),
    marginLeft: normalize(15),
  },
  iconWrapper: {
    flex: 1,
    alignItems: 'flex-end',
    marginRight: normalize(10),
  },

  searchIcon: {
    color: '#000000',
    fontSize: normalize(18),
    marginLeft: normalize(10),
  },

  inputGroup: {
    marginBottom: normalize(15),
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: normalize(15),
  },
  inputBox: {
    backgroundColor: '#ffffff',
    padding: normalize(10),
    fontSize: normalize(18),
    height: normalize(38),
  },
});
