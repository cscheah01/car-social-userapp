import React, {useState, useEffect} from 'react';
import {
  StyleSheet,
  View,
  TextInput,
  TouchableOpacity,
  Image,
  Alert,
} from 'react-native';
import {normalize, getScreenWidth} from '../../../utils/Helper';
import {H5, P, ErrorMessage} from '../../common/Typography';
import Icon from 'react-native-vector-icons/Feather';
import {createGroup} from '../../../services/groupService';
import {useNavigation} from '@react-navigation/native';

export default function CreateGroupFormTwo({
  setImageType,
  openImagePickerOptionModalize,
  groupData,
}) {
  const navigation = useNavigation();

  useEffect(() => {
    setInputData({
      ...inputData,
      ...groupData,
    });
  }, [groupData]);

  const [inputData, setInputData] = useState({
    group_image: null,
    background_image: null,
    description: null,
  });

  const [inputError, setInputError] = useState({
    description: null,
  });

  const errorMessage = {
    country: null,
    name: null,
    is_private: null,
  };

  const submitCreateGroup = async () => {
    let response = await createGroup(inputData);

    if (response.status == 200 && response.success) {
      navigation.navigate('MyGroup');
    } else if (response.status == 422) {
      let error = {};
      response.error.forEach(response => {
        if (response.param == 'description') {
          error = {...error, description: response.msg};
        }
        if (response.param == 'country') {
          errorMessage.country = response.msg;
        }
        if (response.param == 'name') {
          errorMessage.name = response.msg;
        }
        if (response.param == 'is_private') {
          errorMessage.is_private = response.msg;
        }
      });
      setInputError(error);
    }
    if (
      errorMessage.name != null ||
      errorMessage.country != null ||
      errorMessage.is_private != null
    ) {
      navigation.navigate('CreateGroupScreenOne', {
        name: errorMessage.name ?? null,
        country: errorMessage.country ?? null,
        is_private: errorMessage.is_private ?? null,
      });
    }
  };

  return (
    <View style={styles.wrapper}>
      <View style={styles.inputGroup}>
        <P style={styles.inputLabel}>Group Image</P>
        <View style={styles.wrapImage}>
          <TouchableOpacity
            onPress={() => {
              openImagePickerOptionModalize();
              setImageType('group');
            }}>
            {inputData.group_image != null ? (
              <>
                <Image
                  source={{
                    uri: inputData.group_image.uri,
                  }}
                  style={styles.groupImage}
                />
              </>
            ) : (
              <>
                <View style={styles.groupImage}></View>
              </>
            )}
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.wrapGroupImageEditIcon}
            onPress={() => {
              openImagePickerOptionModalize();
              setImageType('group');
            }}>
            <Icon name="camera" style={styles.groupImageIcon} />
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.inputGroup}>
        <P style={styles.inputLabel}>Background</P>
        <View style={styles.wrapImage}>
          <TouchableOpacity
            onPress={() => {
              openImagePickerOptionModalize();
              setImageType('background');
            }}>
            {inputData.background_image != null ? (
              <>
                <Image
                  source={{
                    uri: inputData.background_image.uri,
                  }}
                  style={styles.backgroundImage}
                />
              </>
            ) : (
              <>
                <View style={styles.backgroundImage}></View>
              </>
            )}
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.wrapEditIcon}
            onPress={() => {
              openImagePickerOptionModalize();
              setImageType('background');
            }}>
            <Icon name="camera" style={styles.backgroundImageIcon} />
          </TouchableOpacity>
        </View>
      </View>
      <View style={styles.inputGroup}>
        <P style={styles.inputLabel}>Description</P>
        <TextInput
          style={styles.inputBox}
          multiline={true}
          numberOfLines={5}
          placeholder="Description of your group..."
          onChangeText={text => {
            setInputData({...inputData, description: text});
            setInputError({...inputError, description: null});
          }}
        />
        {inputError.description ? (
          <ErrorMessage>{inputError.description}</ErrorMessage>
        ) : (
          <></>
        )}
      </View>

      <TouchableOpacity
        onPress={() => {
          submitCreateGroup();
        }}>
        <View style={styles.button}>
          <H5 style={styles.buttonText}>Create Group</H5>
        </View>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    padding: normalize(10),
  },
  inputGroup: {
    marginBottom: normalize(15),
  },
  inputLabel: {
    paddingBottom: normalize(10),
  },
  inputBox: {
    backgroundColor: '#ffffff',
    padding: normalize(10),
    fontSize: normalize(15),
    borderRadius: normalize(10),
    textAlignVertical: 'top',
    width: getScreenWidth() * 0.95,
    alignSelf: 'center',
  },
  button: {
    backgroundColor: '#0057FF',
    padding: normalize(10),
    marginVertical: normalize(30),
    borderRadius: normalize(10),
  },
  buttonText: {
    color: '#ffffff',
    textAlign: 'center',
  },
  groupImage: {
    width: normalize(100),
    height: normalize(100),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: normalize(200),
    backgroundColor: '#1E1B1B',
    borderColor: '#ffffff',
    borderWidth: normalize(2),
  },
  backgroundImage: {
    width: getScreenWidth() * 0.95,
    height: normalize(190),
    borderRadius: normalize(10),
    backgroundColor: '#1E1B1B',
    borderColor: '#ffffff',
    borderWidth: normalize(2),
  },
  wrapEditIcon: {
    position: 'absolute',
    borderRadius: normalize(10),
    width: normalize(24),
    height: normalize(24),
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
  },
  wrapGroupImageEditIcon: {
    position: 'absolute',
    borderRadius: normalize(10),
    width: normalize(24),
    height: normalize(24),
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
  },
  groupImageIcon: {
    fontSize: normalize(18),
    color: '#ffffff',
  },
  backgroundImageIcon: {
    fontSize: normalize(18),
    color: '#ffffff',
  },
  wrapImage: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalView: {
    margin: normalize(20),
    backgroundColor: '#ffffff',
    borderRadius: normalize(20),
    padding: normalize(35),
    alignItems: 'center',
    elevation: 5,
  },
  buttonClose: {
    backgroundColor: '#0057FF',
    borderRadius: normalize(20),
    padding: normalize(10),
    elevation: 2,
  },
  textStyle: {
    color: '#ffffff',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalText: {
    color: '#000000',
    marginBottom: normalize(15),
    textAlign: 'center',
  },
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: normalize(22),
  },
});
