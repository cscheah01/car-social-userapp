import React, {useState, useEffect} from 'react';
import {StyleSheet, View, TextInput, TouchableOpacity} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import {normalize} from '../../../utils/Helper';
import {H5, P, ErrorMessage} from '../../common/Typography';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {Country} from 'country-state-city';
import SelectDropdown from 'react-native-select-dropdown';

export default function CreateGroupFormOne({responseError}) {
  const navigation = useNavigation();

  const [inputData, setInputData] = useState({
    name: null,
    country: null,
    is_private: null,
  });
  const [inputError, setInputError] = useState({
    name: null,
    country: null,
    is_private: null,
  });

  useEffect(() => {
    setInputError({...inputError, ...responseError});
  }, [responseError]);

  const nextStep = async () => {
    var error = {};
    if (inputData.name == null) {
      error = {...error, name: 'Group name is required.'};
    }
    if (inputData.country == null) {
      error = {...error, country: 'Country is required.'};
    }
    if (inputData.is_private == null) {
      error = {...error, is_private: 'Privacy setting is required.'};
    }

    setInputError(error);

    if (Object.keys(error).length === 0) {
      navigation.navigate('CreateGroupScreenTwo', inputData);
    }
  };

  return (
    <View style={styles.wrapper}>
      <View style={styles.inputGroup}>
        <P style={styles.inputLabel}>Group Name</P>
        <TextInput
          style={styles.inputBox}
          placeholder="Group Name"
          onChangeText={text => {
            setInputData({...inputData, name: text});
            setInputError({...inputError, name: null});
          }}
        />
        {inputError.name ? (
          <ErrorMessage>{inputError.name}</ErrorMessage>
        ) : (
          <></>
        )}
      </View>

      <View style={styles.inputGroup}>
        <P style={styles.inputLabel}>Country</P>
        <SelectDropdown
          defaultButtonText="Select a country"
          buttonStyle={styles.buttonStyle}
          dropdownStyle={styles.dropdownStyle}
          data={Country.getAllCountries()}
          onSelect={selectedItem => {
            setInputData({...inputData, country: selectedItem.isoCode});
            setInputError({...inputError, country: null});
          }}
          buttonTextAfterSelection={selectedItem => {
            return selectedItem.name;
          }}
          rowTextForSelection={item => {
            return item.name;
          }}
        />
        {inputError.country ? (
          <ErrorMessage>{inputError.country}</ErrorMessage>
        ) : (
          <></>
        )}
      </View>

      <P style={styles.inputLabel}>Privacy</P>
      <View style={styles.inputGroup}>
        <TouchableOpacity
          style={styles.row}
          onPress={() => {
            setInputData({...inputData, is_private: false});
            setInputError({...inputError, is_private: null});
          }}>
          <View style={styles.rowLabelWrapper}>
            <Icon name="globe" style={styles.icon} />
            <H5 style={styles.rowLabel}>Public</H5>
          </View>

          <View style={styles.rowRadioButtonWrapper}>
            <View
              style={
                inputData.is_private == false
                  ? styles.activeRadioButton
                  : styles.unactiveRadioButton
              }></View>
          </View>
        </TouchableOpacity>
      </View>

      <View style={styles.inputGroup}>
        <TouchableOpacity
          style={styles.row}
          onPress={() => {
            setInputData({...inputData, is_private: true});
            setInputError({...inputError, is_private: null});
          }}>
          <View style={styles.rowLabelWrapper}>
            <Icon name="lock" style={styles.icon} />
            <H5 style={styles.rowLabel}>Private</H5>
          </View>

          <View style={styles.rowRadioButtonWrapper}>
            <View
              style={
                inputData.is_private == true
                  ? styles.activeRadioButton
                  : styles.unactiveRadioButton
              }></View>
          </View>
        </TouchableOpacity>
      </View>

      {inputError.is_private ? (
        <ErrorMessage>{inputError.is_private}</ErrorMessage>
      ) : (
        <></>
      )}

      <TouchableOpacity
        onPress={() => {
          nextStep();
        }}>
        <View style={styles.button}>
          <H5 style={styles.buttonText}>Next</H5>
        </View>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    padding: normalize(10),
  },
  inputGroup: {
    marginBottom: normalize(15),
  },
  inputLabel: {
    paddingBottom: normalize(10),
  },
  inputBox: {
    backgroundColor: '#ffffff',
    padding: normalize(10),
    fontSize: normalize(15),
    borderRadius: normalize(10),
  },
  dropdownStyle: {
    borderRadius: normalize(10),
  },
  buttonStyle: {
    width: '100%',
    backgroundColor: '#ffffff',
    padding: normalize(10),
    fontSize: normalize(15),
    borderRadius: normalize(10),
  },
  button: {
    backgroundColor: '#0057FF',
    padding: normalize(10),
    marginVertical: normalize(30),
    borderRadius: normalize(10),
  },
  buttonText: {
    color: '#ffffff',
    textAlign: 'center',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  rowLabelWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  rowLabel: {
    marginLeft: normalize(10),
  },
  rowRadioButtonWrapper: {
    flex: 1,
    alignItems: 'flex-end',
  },
  activeRadioButton: {
    backgroundColor: '#0057FF',
    borderColor: '#ffffff',
    borderWidth: normalize(5),
    borderRadius: normalize(30),
    width: normalize(20),
    height: normalize(20),
  },
  unactiveRadioButton: {
    backgroundColor: '#ffffff',
    borderColor: '#ffffff',
    borderWidth: normalize(5),
    borderRadius: normalize(30),
    width: normalize(20),
    height: normalize(20),
  },
  icon: {
    fontSize: normalize(25),
    color: '#ffffff',
  },
});
