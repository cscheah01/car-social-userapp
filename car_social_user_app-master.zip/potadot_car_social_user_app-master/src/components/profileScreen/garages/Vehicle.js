import React from 'react';
import {StyleSheet, View, Image} from 'react-native';
import {getScreenWidth, normalize} from '../../../utils/Helper';
import {H5, P} from '../../common/Typography';

export default function Vehicle({data}) {
  return (
    <View>
      <H5 style={styles.carBrand}>{data.car_brand}</H5>
      <View style={styles.carImageWrapper}>
        <Image source={{uri: data.car_image}} style={styles.carImage} />
      </View>

      <P style={styles.carName}>
        ({data.car_year}) {data.car_name}
      </P>
    </View>
  );
}

const styles = StyleSheet.create({
  carImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
    borderRadius: normalize(10),
  },
  carImageWrapper: {
    height: normalize(180),
    width: (getScreenWidth() * 3) / 4,
    alignSelf: 'center',
    borderColor: '#ffffff',
    borderWidth: normalize(2),
    borderRadius: normalize(10),
    marginBottom: normalize(20),
  },
  carName: {
    alignSelf: 'center',
  },
  carBrand: {
    alignSelf: 'center',
    marginTop: normalize(20),
    marginBottom: normalize(20),
  },
});
