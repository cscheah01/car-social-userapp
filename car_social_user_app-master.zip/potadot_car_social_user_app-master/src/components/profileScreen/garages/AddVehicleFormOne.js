import React, {useState, useEffect} from 'react';
import {StyleSheet, View, TouchableOpacity} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import {normalize} from '../../../utils/Helper';
import {H5, P, ErrorMessage} from '../../common/Typography';
import SelectDropdown from 'react-native-select-dropdown';
import {getCarBrand, getCarBrandModel} from '../../../services/carService';
import Icon from 'react-native-vector-icons/FontAwesome5';

export default function AddVehiclesFormOne() {
  const navigation = useNavigation();

  const year = new Date().getFullYear();
  const years = Array.from(new Array(50), (val, index) => year - index);

  const [carBrand, setCarBrand] = useState(null);
  const [carBrandModel, setCarBrandModel] = useState({name: null});
  const [isLoading, setIsLoading] = useState(true);

  const [inputData, setInputData] = useState({
    car_brand_id: null,
    car_model_id: null,
    year: null,
  });
  const [inputError, setInputError] = useState({
    car_brand_id: null,
    car_model_id: null,
    year: null,
  });

  useEffect(() => {
    async function fetchData() {
      setIsLoading(true);

      let response = await getCarBrand();

      setCarBrand(response.data);

      setIsLoading(false);
    }

    fetchData();
  }, []);

  async function onGetCarBrandModel(carBrand) {
    let response = await getCarBrandModel(carBrand);
    setCarBrandModel(response.data);
  }

  const nextStep = async () => {
    var error = {};
    if (inputData.car_brand_id == null) {
      error = {...error, car_brand_id: 'Brand is required.'};
    }
    if (inputData.car_model_id == null) {
      error = {...error, car_model_id: 'Model is required.'};
    }
    if (inputData.year == null) {
      error = {...error, year: 'Year is required.'};
    }

    setInputError(error);

    if (Object.keys(error).length === 0) {
      navigation.navigate('AddVehicleScreenTwo', inputData);
    }
  };

  return (
    <>
      {isLoading ? (
        <></>
      ) : (
        <View style={styles.wrapper}>
          <View style={styles.inputCar}>
            <P style={styles.inputLabel}>Brand</P>
            <SelectDropdown
              defaultButtonText="Select Brand"
              buttonStyle={styles.buttonStyle}
              buttonTextStyle={styles.buttonDropDownTextStyle}
              renderDropdownIcon={selectedItem => {
                return <Icon name="angle-down" style={styles.icon} />;
              }}
              dropdownStyle={styles.dropdownStyle}
              data={carBrand}
              onSelect={selectedItem => {
                setInputData({...inputData, car_brand_id: selectedItem.id});
                setInputError({...inputError, car_brand_id: null});
                onGetCarBrandModel(selectedItem.id);
              }}
              buttonTextAfterSelection={selectedItem => {
                return selectedItem.name;
              }}
              rowTextForSelection={item => {
                return item.name;
              }}
            />
            {inputError.car_brand_id ? (
              <ErrorMessage>{inputError.car_brand_id}</ErrorMessage>
            ) : (
              <></>
            )}
          </View>

          <View style={styles.inputCar}>
            <P style={styles.inputLabel}>Model</P>
            <SelectDropdown
              defaultButtonText="Select Model"
              buttonStyle={styles.buttonStyle}
              buttonTextStyle={styles.buttonDropDownTextStyle}
              renderDropdownIcon={selectedItem => {
                return <Icon name="angle-down" style={styles.icon} />;
              }}
              dropdownStyle={styles.dropdownStyle}
              data={carBrandModel}
              onSelect={selectedItem => {
                setInputData({...inputData, car_model_id: selectedItem.id});
                setInputError({...inputError, car_model_id: null});
              }}
              buttonTextAfterSelection={selectedItem => {
                return selectedItem.name;
              }}
              rowTextForSelection={item => {
                return item.name;
              }}
            />
            {inputError.car_model_id ? (
              <ErrorMessage>{inputError.car_model_id}</ErrorMessage>
            ) : (
              <></>
            )}
          </View>

          <View style={styles.inputCar}>
            <P style={styles.inputLabel}>Year</P>
            <SelectDropdown
              defaultButtonText="Select Year"
              buttonStyle={styles.buttonStyle}
              buttonTextStyle={styles.buttonDropDownTextStyle}
              renderDropdownIcon={selectedItem => {
                return <Icon name="angle-down" style={styles.icon} />;
              }}
              dropdownStyle={styles.dropdownStyle}
              data={years}
              onSelect={selectedItem => {
                setInputData({...inputData, year: selectedItem});
                setInputError({...inputError, year: null});
              }}
              buttonTextAfterSelection={selectedItem => {
                return selectedItem;
              }}
              rowTextForSelection={item => {
                return item;
              }}
            />
            {inputError.year ? (
              <ErrorMessage>{inputError.year}</ErrorMessage>
            ) : (
              <></>
            )}
          </View>

          <TouchableOpacity
            onPress={() => {
              nextStep();
            }}>
            <View style={styles.button}>
              <H5 style={styles.buttonText}>Next</H5>
            </View>
          </TouchableOpacity>
        </View>
      )}
    </>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    padding: normalize(10),
  },
  inputCar: {
    marginTop: normalize(15),
  },
  inputLabel: {
    paddingBottom: normalize(10),
  },
  dropdownStyle: {
    borderRadius: normalize(10),
  },
  buttonStyle: {
    width: '100%',
    backgroundColor: '#ffffff',
    padding: normalize(10),
    borderRadius: normalize(10),
    height: normalize(40),
  },
  buttonDropDownTextStyle: {
    color: '#575757',
  },

  button: {
    backgroundColor: '#0057FF',
    padding: normalize(10),
    marginVertical: normalize(30),
    borderRadius: normalize(10),
  },
  buttonText: {
    color: '#ffffff',
    textAlign: 'center',
  },

  icon: {
    fontSize: normalize(20),
    color: '#000000',
    marginRight: normalize(20),
    position: 'absolute',
  },
});
