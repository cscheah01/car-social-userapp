import React, {useState, useEffect} from 'react';
import {StyleSheet, View, TouchableOpacity, Image, Alert} from 'react-native';
import {getScreenWidth, normalize} from '../../../utils/Helper';
import {H5, P} from '../../common/Typography';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {createVehicle} from '../../../services/garageService';
import {useNavigation} from '@react-navigation/native';

export default function AddVehiclesFormTwo({
  data,
  openImagePickerOptionModalize,
}) {
  const navigation = useNavigation();
  const [disabledSubmit, setDisabledSubmit] = useState(true);
  const [inputData, setInputData] = useState({
    car_brand_id: data.car_brand_id,
    car_model_id: data.car_model_id,
    year: data.year,
    image: null,
  });

  useEffect(() => {
    setDisabledSubmit(true);

    if (inputData.image) {
      setDisabledSubmit(false);
    }
  }, [inputData]);

  useEffect(() => {
    setInputData({
      ...inputData,
      image: data.image,
    });
  }, [data]);

  const submitAddVehicle = async () => {
    let response = await createVehicle(inputData);

    if (response.status == 200 && response.success) {
      navigation.navigate('Home');
    } else if (response.status == 422) {
      Alert.alert('Create Vehicle Failed', JSON.stringify(response.error));
    }
  };

  return (
    <View style={styles.mainWrapper}>
      <P style={styles.inputLabel}>Vehicle image</P>
      <View style={styles.wrapImage}>
        <TouchableOpacity
          onPress={() => {
            openImagePickerOptionModalize();
          }}>
          {inputData.image != null ? (
            <>
              <Image
                source={{
                  uri: inputData.image.uri,
                }}
                style={styles.carImage}
              />
            </>
          ) : (
            <>
              <View style={styles.carImage}></View>
            </>
          )}
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.wrapEditIcon}
          onPress={() => {
            openImagePickerOptionModalize();
          }}>
          <Icon name="camera" style={styles.carImageIcon} />
        </TouchableOpacity>
      </View>
      <TouchableOpacity
        disabled={disabledSubmit}
        onPress={() => {
          submitAddVehicle();
        }}>
        <View style={styles.button}>
          <H5
            style={
              disabledSubmit ? styles.disabledbutton : styles.enabledbutton
            }>
            Add
          </H5>
        </View>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  mainWrapper: {
    paddingTop: normalize(15),
    paddingBottom: normalize(10),
  },
  inputLabel: {
    paddingBottom: normalize(10),
  },
  button: {
    backgroundColor: '#0057FF',
    padding: normalize(10),
    marginVertical: normalize(30),
    borderRadius: normalize(10),
  },
  enabledbutton: {
    color: '#ffffff',
    textAlign: 'center',
  },
  carImage: {
    width: getScreenWidth() * 0.95,
    height: normalize(190),
    borderRadius: normalize(10),
    borderColor: '#ffffff',
    borderWidth: normalize(2),
    backgroundColor: '#1E1B1B',
  },
  wrapEditIcon: {
    position: 'absolute',
    borderRadius: normalize(10),
    width: normalize(24),
    height: normalize(24),
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
  },
  carImageIcon: {
    fontSize: normalize(18),
    color: '#ffffff',
  },
  wrapImage: {
    alignItems: 'center',
    justifyContent: 'center',
    width: getScreenWidth() * 0.95,
  },
  modalView: {
    margin: normalize(20),
    backgroundColor: '#ffffff',
    borderRadius: normalize(20),
    padding: normalize(35),
    alignItems: 'center',
    elevation: 5,
  },
  buttonClose: {
    backgroundColor: '#0057FF',
    borderRadius: normalize(20),
    padding: normalize(10),
    elevation: 2,
  },
  textStyle: {
    color: '#ffffff',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalText: {
    color: '#000000',
    marginBottom: normalize(15),
    textAlign: 'center',
  },
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: normalize(22),
  },
  disabledbutton: {
    opacity: 0.4,
    color: '#ffffff',
    textAlign: 'center',
  },
});
