import React, {useEffect, useState} from 'react';
import {
  StyleSheet,
  View,
  ImageBackground,
  Image,
  TouchableOpacity,
  TouchableWithoutFeedback,
} from 'react-native';
import {getScreenWidth, normalize} from '../../../utils/Helper';
import {useNavigation} from '@react-navigation/native';
import {P, H5, H4} from '../../common/Typography';
import Icon from 'react-native-vector-icons/Ionicons';

const demoData = {
  following: '100',
  follower: '2',
  posts: '4',
};

export default function ({
  data,
  openSettingModalize,
  openImagePickerOptionModalize,
}) {
  const navigation = useNavigation();
  const [profile, setProfile] = useState('');

  useEffect(() => {
    setProfile(data);
  }, [data]);

  return (
    <ImageBackground
      source={{uri: profile.background_image}}
      imageStyle={{opacity: 0.4}}
      blurRadius={2}
      style={
        profile.background_image != null
          ? styles.mainContainer
          : styles.mainContainerEmpty
      }>
      <View style={styles.topSection}>
        <H4>{profile.username}</H4>
        <View style={styles.ellipsisWrapper}>
          <TouchableOpacity
            onPress={() => {
              openSettingModalize();
            }}>
            <Icon name="ellipsis-vertical" style={styles.ellipsisIcon} />
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.mainRow}>
        <View style={styles.mainLeftColumn}>
          <TouchableOpacity
            onPress={() => {
              openImagePickerOptionModalize();
            }}>
            <Image
              source={{uri: profile.profile_image}}
              style={
                profile.profile_image == null
                  ? styles.profileEmptyImage
                  : styles.profileImage
              }
            />
          </TouchableOpacity>
        </View>
        <View style={styles.mainRightColumn}>
          <View style={styles.countNumberRow}>
            <View style={styles.countNumberColumn}>
              <TouchableWithoutFeedback
                onPress={() =>
                  navigation.navigate('FollowerAndFollowing', {
                    screen: 'Follower',
                  })
                }>
                <View>
                  <H5 style={styles.textCenter}>{demoData.follower}</H5>
                  <P style={styles.textCenter}>Follower</P>
                </View>
              </TouchableWithoutFeedback>
            </View>

            <View style={styles.countNumberColumn}>
              <TouchableWithoutFeedback
                onPress={() =>
                  navigation.navigate('FollowerAndFollowing', {
                    screen: 'Following',
                  })
                }>
                <View>
                  <H5 style={styles.textCenter}>{demoData.following}</H5>
                  <P style={styles.textCenter}>Following</P>
                </View>
              </TouchableWithoutFeedback>
            </View>

            <View style={styles.countNumberColumn}>
              <H5 style={styles.textCenter}>{demoData.posts}</H5>
              <P style={styles.textCenter}>Posts</P>
            </View>
          </View>

          <View style={styles.bioDescriptionWrapper}>
            {profile.bio == null ? (
              <TouchableOpacity
                onPress={() => {
                  navigation.navigate('EditBio', {
                    bio: null,
                  });
                }}>
                <P>Click here to edit bio description</P>
              </TouchableOpacity>
            ) : (
              <P>{profile.bio}</P>
            )}
          </View>
        </View>
      </View>

      <View style={styles.bottomSection}>
        <TouchableOpacity onPress={() => navigation.navigate('Details')}>
          <View style={styles.editProfileButton}>
            <P>Edit Profile</P>
          </View>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    resizeMode: 'contain',
    paddingBottom: normalize(15),
  },
  mainContainerEmpty: {
    resizeMode: 'contain',
    paddingBottom: normalize(15),
    backgroundColor: '#272727',
  },
  topSection: {
    marginBottom: normalize(20),
    padding: normalize(10),
    backgroundColor: 'rgba(0,0,0,0.3)',
    flexDirection: 'row',
    alignItems: 'center',
  },
  mainRow: {
    flexDirection: 'row',
    paddingHorizontal: normalize(10),
    alignItems: 'center',
  },
  mainLeftColumn: {
    width: '30%',
  },
  mainRightColumn: {
    width: '70%',
  },
  profileImage: {
    width: getScreenWidth() * 0.25,
    height: getScreenWidth() * 0.25,
    borderRadius: (getScreenWidth() * 0.25) / 2,
  },
  profileEmptyImage: {
    width: getScreenWidth() * 0.25,
    height: getScreenWidth() * 0.25,
    borderRadius: (getScreenWidth() * 0.25) / 2,
    backgroundColor: '#383939',
  },
  countNumberRow: {
    flexDirection: 'row',
  },
  countNumberColumn: {
    width: '33%',
  },
  textCenter: {
    textAlign: 'center',
  },
  bioDescriptionWrapper: {
    backgroundColor: 'rgba(0,0,0,0.6)',
    fontColor: '#ffffff',
    marginTop: normalize(15),
    paddingVertical: normalize(5),
    paddingHorizontal: normalize(10),
    borderRadius: normalize(10),
  },
  bottomSection: {
    alignItems: 'flex-end',
    paddingHorizontal: normalize(10),
    marginTop: normalize(10),
  },
  editProfileButton: {
    fontColor: '#ffffff',
    backgroundColor: 'rgba(0,0,0,0.6)',
    borderWidth: normalize(2),
    borderRadius: normalize(10),
    borderColor: '#ffffff',
    paddingHorizontal: normalize(15),
    paddingVertical: normalize(10),
  },
  ellipsisWrapper: {
    flex: 1,
    alignItems: 'flex-end',
  },
  ellipsisIcon: {
    fontSize: normalize(15),
    color: '#ffffff',
  },
});
