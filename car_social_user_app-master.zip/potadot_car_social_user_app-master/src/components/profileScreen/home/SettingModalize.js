import React, {useContext} from 'react';
import {StyleSheet, View, TouchableOpacity} from 'react-native';
import {H5} from '../../common/Typography';
import Icon from 'react-native-vector-icons/Ionicons';
import {Modalize} from 'react-native-modalize';
import {normalize} from '../../../utils/Helper';
import {AuthContext} from '../../../contexts/AuthContext';

export default function ({settingModalizeRef}) {
  const {handleLogout} = useContext(AuthContext);

  const logout = () => {
    handleLogout();
  };

  return (
    <Modalize ref={settingModalizeRef} adjustToContentHeight={true}>
      <TouchableOpacity onPress={() => {}}>
        <View style={styles.row}>
          <Icon name="settings" style={styles.icon}></Icon>
          <H5 style={styles.label}>Setting</H5>
        </View>
      </TouchableOpacity>

      <View style={styles.horizontalLine}></View>

      <TouchableOpacity
        onPress={() => {
          logout();
        }}>
        <View style={styles.row}>
          <Icon name="lock-closed" style={styles.icon}></Icon>
          <H5 style={styles.label}>Logout</H5>
        </View>
      </TouchableOpacity>
    </Modalize>
  );
}

const styles = StyleSheet.create({
  label: {
    color: '#000000',
    marginLeft: normalize(12),
  },
  horizontalLine: {
    borderBottomColor: '#808080',
    borderBottomWidth: normalize(2),
  },
  row: {
    paddingHorizontal: normalize(10),
    paddingVertical: normalize(15),
    flexDirection: 'row',
    alignItems: 'center',
  },
  icon: {
    fontSize: normalize(20),
    color: '#000000',
  },
});
