import React, {useState, useEffect} from 'react';
import {StyleSheet, View, Image, TouchableOpacity} from 'react-native';
import {normalize} from '../../../utils/Helper';
import Icon from 'react-native-vector-icons/Feather';
import {P} from '../../common/Typography';
import {useNavigation} from '@react-navigation/native';
import moment from 'moment';

export default function ProfileDetails({
  data,
  setImageType,
  openImagePickerOptionModalize,
}) {
  const navigation = useNavigation();
  const [profileDetails, setProfileDetails] = useState(data);

  useEffect(() => {
    setProfileDetails(data);
  }, [data]);

  return (
    <View>
      <View style={styles.mainWrapper}>
        <View style={styles.UserProfileImageWrapper}>
          <TouchableOpacity
            onPress={() => {
              openImagePickerOptionModalize();
              setImageType('profile_image');
            }}>
            {profileDetails.profile_image != null ? (
              <>
                <Image
                  source={{uri: profileDetails.profile_image}}
                  style={styles.userProfileImage}></Image>
              </>
            ) : (
              <>
                <View style={styles.userProfileImage}></View>
              </>
            )}
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.wrapEditIcon}
            onPress={() => {
              openImagePickerOptionModalize();
              setImageType('background');
            }}>
            <Icon name="camera" style={styles.cameraIcon} />
          </TouchableOpacity>
        </View>

        <View style={styles.row}>
          <P style={styles.label}>Email</P>
          <P style={styles.data}>{profileDetails.email}</P>
        </View>
        <TouchableOpacity
          onPress={() => {
            navigation.navigate('EditUsername', {
              username: profileDetails.username,
            });
          }}>
          <View style={styles.row}>
            <P style={styles.label}>Username</P>
            <P style={styles.data}>{profileDetails.username}</P>
            <Icon name="chevron-right" style={styles.rowIcon} />
          </View>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => {
            navigation.navigate('EditPhoneNumber', {
              phone_no: profileDetails.phone_no,
            });
          }}>
          <View style={styles.row}>
            <P style={styles.label}>Phone Number</P>
            <P style={styles.data}>{profileDetails.phone_no}</P>
            <Icon name="chevron-right" style={styles.rowIcon} />
          </View>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => {
            navigation.navigate('EditDateOfBirth', {
              dob: profileDetails.dob,
            });
          }}>
          <View style={styles.row}>
            <P style={styles.label}>Birthday</P>
            <P style={styles.data}>
              {moment(profileDetails.dob).format('DD MMMM YYYY')}
            </P>
            <Icon name="chevron-right" style={styles.rowIcon} />
          </View>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => {
            navigation.navigate('EditBio', {
              bio: profileDetails.bio,
            });
          }}>
          <View style={styles.row}>
            <P style={styles.label}>Bio</P>
            <P style={styles.data} numberOfLines={3} ellipsizeMode="tail">
              {profileDetails.bio != null ? profileDetails.bio : '-'}
            </P>
            <Icon name="chevron-right" style={styles.rowIcon} />
          </View>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => {
            openImagePickerOptionModalize();
            setImageType('background_image');
          }}>
          <View style={styles.row}>
            <P style={styles.label}>Background Image</P>
            {profileDetails.background_image != null ? (
              <>
                <Image
                  source={{uri: profileDetails.background_image}}
                  style={styles.userBackgroundImage}></Image>
              </>
            ) : (
              <>
                <View style={styles.userBackgroundImage}></View>
              </>
            )}
            <Icon name="chevron-right" style={styles.rowIcon} />
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  mainWrapper: {
    paddingTop: normalize(30),
    paddingBottom: normalize(10),
  },
  userProfileImage: {
    width: normalize(100),
    height: normalize(100),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: normalize(200),
    backgroundColor: '#1E1B1B',
    borderWidth: normalize(2),
    borderColor: '#ffffff',
    resizeMode: 'contain',
  },
  userBackgroundImage: {
    height: normalize(50),
    width: normalize(60),
    marginLeft: normalize(30),
    marginRight: normalize(80),
    backgroundColor: '#1E1B1B',
  },
  UserProfileImageWrapper: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  label: {
    color: '#ffffff',
    fontSize: normalize(14),
    width: normalize(80),
    fontWeight: 'bold',
  },
  data: {
    color: '#ffffff',
    marginLeft: normalize(30),
    fontSize: normalize(14),
    width: normalize(140),
  },
  rowIcon: {
    color: '#ffffff',
    fontSize: normalize(16),
    marginTop: normalize(5),
    marginLeft: normalize(30),
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    height: normalize(70),
    width: normalize(250),
    marginHorizontal: normalize(6),
    paddingLeft: normalize(10),
    fontColor: '#ffffff',
  },
  editProfileButton: {
    marginLeft: normalize(128),
  },
  editProfile: {
    width: normalize(90),
    height: normalize(35),
    fontColor: '#ffffff',
    backgroundColor: 'rgba(0,0,0,0.6)',
    borderWidth: normalize(2),
    borderRadius: normalize(10),
    borderColor: '#ffffff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  wrapEditIcon: {
    position: 'absolute',
    borderRadius: normalize(10),
    width: normalize(24),
    height: normalize(24),
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
  },
  cameraIcon: {
    fontSize: normalize(18),
    color: '#ffffff',
  },
});
