import React from 'react';
import {StyleSheet, View, TouchableOpacity} from 'react-native';
import {normalize} from '../../../../utils/Helper';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {useNavigation} from '@react-navigation/native';
import {H4, H5} from '../../../common/Typography';

export default function ({onSubmitEditBio}) {
  const navigation = useNavigation();

  return (
    <View style={styles.wrapper}>
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <View style={(styles.flexRow, styles.backButton)}>
          <Icon name="arrow-left" style={styles.icon} />
        </View>
      </TouchableOpacity>
      <View style={styles.headerLabel}>
        <H4>Bio</H4>
      </View>
      <View style={styles.rightSection}>
        <View style={styles.rightSectionItem}>
          <TouchableOpacity
            onPress={() => {
              onSubmitEditBio();
            }}>
            <View style={styles.buttonBlue}>
              <H5 style={styles.buttonText}>Save</H5>
            </View>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#000000',
    padding: normalize(10),
    borderBottomColor: '#ffffff',
    borderBottomWidth: normalize(3),
  },
  flexRow: {
    flexDirection: 'row',
  },
  icon: {
    fontSize: normalize(18),
    color: '#ffffff',
  },
  backButton: {
    marginRight: normalize(20),
  },
  headerLabel: {
    flex: 7 / 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rightSection: {
    flex: 1 / 8,
    alignItems: 'flex-end',
  },
  rightSectionItem: {
    marginLeft: normalize(20),
  },
  buttonBlue: {
    width: normalize(70),
    backgroundColor: '#0057FF',
    borderRadius: normalize(10),
    paddingVertical: normalize(5),
  },
  buttonText: {
    textAlign: 'center',
  },
});
