import React from 'react';
import {StyleSheet, View, TextInput} from 'react-native';
import {normalize} from '../../../../utils/Helper';

export default function EditBioForm({setInputData, inputData}) {
  return (
    <View style={styles.wrapper}>
      <View style={styles.inputGroup}>
        <TextInput
          style={styles.inputBox}
          value={inputData}
          placeholder="Bio"
          multiline={true}
          onChangeText={text => {
            setInputData({...inputData, bio: text});
          }}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    padding: normalize(10),
  },
  inputGroup: {
    marginBottom: normalize(15),
  },
  inputBox: {
    backgroundColor: '#ffffff',
    padding: normalize(10),
    fontSize: normalize(15),
    borderRadius: normalize(10),
  },
  textStyle: {
    color: '#b2b2b2',
  },
});
