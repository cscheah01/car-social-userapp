import React, {useEffect, useState} from 'react';
import {StyleSheet, View, TextInput} from 'react-native';
import {normalize} from '../../../../utils/Helper';
import {P, ErrorMessage} from '../../../common/Typography';

export default function EditUsernameForm({
  inputError,
  setInputData,
  inputData,
  setInputError,
}) {
  const [textLength, setTextLength] = useState(0);
  const [username, setUsername] = useState(inputData);
  const maxLength = 24;

  useEffect(() => {
    setTextLength(username.length);
  }, [username]);

  return (
    <View style={styles.wrapper}>
      <View style={styles.inputGroup}>
        <TextInput
          maxLength={maxLength}
          style={styles.inputBox}
          value={inputData}
          placeholder="Username"
          onChangeText={text => {
            setUsername(text);
            setInputData({...inputData, username: text});
            setInputError({username: null});
          }}
        />
        {inputError ? <ErrorMessage>{inputError}</ErrorMessage> : <></>}
        <View style={styles.flexRow}>
          <P style={styles.textStyle}>{textLength} characters</P>
          <View style={styles.rightSection}>
            <P style={styles.textStyle}>{maxLength} max characters</P>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    padding: normalize(10),
  },
  inputGroup: {
    marginBottom: normalize(15),
  },
  inputBox: {
    backgroundColor: '#ffffff',
    padding: normalize(10),
    fontSize: normalize(15),
    borderRadius: normalize(10),
  },
  textStyle: {
    color: '#b2b2b2',
  },
  flexRow: {
    flexDirection: 'row',
  },
  rightSection: {
    flex: 1,
    alignItems: 'flex-end',
  },
});
