import React from 'react';
import {StyleSheet, View, TextInput} from 'react-native';
import {normalize} from '../../../../utils/Helper';
import {ErrorMessage} from '../../../common/Typography';

export default function EditPhoneNumberForm({
  inputError,
  setInputData,
  inputData,
  setInputError,
}) {
  return (
    <View style={styles.wrapper}>
      <View style={styles.inputGroup}>
        <TextInput
          style={styles.inputBox}
          value={inputData}
          placeholder="Phone Number"
          onChangeText={text => {
            setInputData({...inputData, phone_no: text});
            setInputError({phone_no: null});
          }}
        />
        {inputError ? <ErrorMessage>{inputError}</ErrorMessage> : <></>}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    padding: normalize(10),
  },
  inputGroup: {
    marginBottom: normalize(15),
  },
  inputBox: {
    backgroundColor: '#ffffff',
    padding: normalize(10),
    fontSize: normalize(15),
    borderRadius: normalize(10),
  },
  textStyle: {
    color: '#b2b2b2',
  },
});
