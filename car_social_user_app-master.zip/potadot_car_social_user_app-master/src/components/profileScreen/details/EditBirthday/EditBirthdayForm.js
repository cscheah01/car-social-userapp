import React, {useState} from 'react';
import {StyleSheet, View, TouchableOpacity} from 'react-native';
import {normalize} from '../../../../utils/Helper';
import {P, ErrorMessage, H5} from '../../../common/Typography';
import DatePicker from 'react-native-date-picker';
import moment from 'moment';

export default function EditBirthDayForm({setInputData, inputData}) {
  const [openDatePicker, setOpenDatePicker] = useState(false);
  return (
    <View style={styles.wrapper}>
      <View style={styles.inputGroup}>
        <View style={styles.birthdayLabelRow}>
          <P style={styles.birthdayLabelColumn}>Day</P>
          <P style={styles.birthdayLabelColumn}>Month</P>
          <P style={styles.birthdayLabelColumn}>Year</P>
        </View>

        <TouchableOpacity onPress={() => setOpenDatePicker(true)}>
          {inputData != null ? (
            <View style={styles.selectedDobDisplayRow}>
              <P style={styles.selectedDobDisplayColumn}>
                {moment(inputData).format('DD')}
              </P>

              <P style={styles.selectedDobDisplayColumn}>
                {moment(inputData).format('MMMM')}
              </P>

              <P style={styles.selectedDobDisplayColumn}>
                {moment(inputData).format('YYYY')}
              </P>
            </View>
          ) : (
            <View style={styles.button}>
              <H5 style={styles.dateButtonText}>
                -- Please select your birthday --
              </H5>
            </View>
          )}
        </TouchableOpacity>

        <DatePicker
          modal
          mode="date"
          maximumDate={new Date()}
          open={openDatePicker}
          date={new Date()}
          onConfirm={data => {
            setInputData({...inputData, dob: data});
            setOpenDatePicker(false);
          }}
          onCancel={() => {
            setOpenDatePicker(false);
          }}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    padding: normalize(10),
  },
  inputGroup: {
    marginBottom: normalize(15),
  },
  birthdayLabelRow: {
    flexDirection: 'row',
    marginBottom: normalize(10),
  },
  birthdayLabelColumn: {
    color: '#D3D3D3',
    width: '33%',
    textAlign: 'center',
  },
  dateButtonText: {
    color: '#808080',
    fontSize: normalize(15),
    paddingVertical: normalize(4),
    textAlign: 'center',
  },
  selectedDobDisplayRow: {
    flexDirection: 'row',
    alignItems: 'center',
    color: '#000000',
    backgroundColor: '#ffffff',
    borderRadius: normalize(10),
    padding: normalize(10),
  },
  selectedDobDisplayColumn: {
    textAlign: 'center',
    color: '#000000',
    fontSize: normalize(15),
    width: '33%',
  },
  button: {
    backgroundColor: '#ffffff',
    padding: normalize(10),
    borderRadius: normalize(10),
  },
});
