import React from 'react';
import {StyleSheet, View, Image, TouchableOpacity} from 'react-native';
import {
  getScreenWidth,
  normalize,
  totalCountFormatter,
} from '../../../utils/Helper';
import {P, H4} from '../../common/Typography';
import moment from 'moment';
import Icon from 'react-native-vector-icons/Ionicons';
import {Country} from 'country-state-city';
import {useNavigation} from '@react-navigation/native';

export default function Event({data}) {
  const navigation = useNavigation();
  let location = Country.getCountryByCode(data.location);

  return (
    <View key={data.id} style={styles.wrapper}>
      <TouchableOpacity
        onPress={() => {
          navigation.navigate('SingleEvent', {eventId: data.id});
        }}>
        <Image source={{uri: data.cover_image}} style={styles.image} />
        <H4 style={styles.name}>{data.title}</H4>
        <View style={styles.rowWrapper}>
          <View style={styles.leftColumn}>
            <P style={styles.date}>{moment(data.start_date).calendar()}</P>
            <View style={styles.rowWrapper}>
              <Icon name="location-outline" style={styles.locationIcon} />
              <P>{location.name}</P>
            </View>
            <P style={styles.memberCount}>
              {totalCountFormatter(data.total_member)} Joined
            </P>
          </View>
          <View style={styles.rightColumn}>
            <P style={styles.label}>Event By</P>
            <P style={styles.userName} numberOfLines={1}>
              {data.username}
            </P>
          </View>
        </View>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    paddingHorizontal: normalize(18),
    marginVertical: normalize(10),
  },
  image: {
    width: (getScreenWidth() * 9) / 10,
    height: normalize(200),
    borderRadius: normalize(10),
    backgroundColor: '#1E1B1B',
    borderColor: '#ffffff',
    borderWidth: normalize(2),
    alignSelf: 'center',
    resizeMode: 'cover',
  },
  name: {
    flexDirection: 'row',
    marginTop: normalize(10),
    marginBottom: normalize(10),
  },
  rowWrapper: {
    flexDirection: 'row',
  },
  date: {
    color: '#ffffff',
    textTransform: 'uppercase',
    marginBottom: normalize(10),
  },
  location: {
    color: '#ffffff',
    marginTop: normalize(10),
  },
  label: {
    marginRight: normalize(5),
  },
  userName: {
    fontWeight: 'bold',
  },
  memberCount: {
    color: '#ffffff',
    marginLeft: normalize(20),
    fontSize: normalize(12),
  },
  rightColumn: {
    width: '30%',
    flexDirection: 'row',
  },
  leftColumn: {
    width: '60%',
  },
  locationIcon: {
    fontSize: normalize(20),
    color: '#ffffff',
  },
});
