import React, {useState, useEffect} from 'react';
import {
  StyleSheet,
  View,
  TextInput,
  TouchableOpacity,
  Image,
  Alert,
} from 'react-native';
import {normalize, getScreenWidth} from '../../../utils/Helper';
import {H5, P, ErrorMessage} from '../../common/Typography';
import Icon from 'react-native-vector-icons/Feather';
import {useNavigation} from '@react-navigation/native';
import {createEvent} from '../../../services/eventService';
import moment from 'moment';

export default function CreateEventFormTwo({
  openImagePickerOptionModalize,
  coverPhoto,
  eventData,
}) {
  const navigation = useNavigation();

  useEffect(() => {
    setInputData({
      ...inputData,
      cover_photo: coverPhoto,
    });
  }, [coverPhoto]);

  const [inputData, setInputData] = useState({
    title: eventData.title,
    start_date: eventData.start_date,
    end_date: eventData.end_date,
    location: eventData.location,
    cover_photo: null,
    description: null,
  });

  const [inputError, setInputError] = useState({
    description: null,
  });

  const errorMessage = {
    title: null,
    start_date: null,
    end_date: null,
    location: null,
  };

  const submitCreateEvent = async () => {
    inputData.start_date = moment(inputData.start_date).format(
      'YYYY-MM-DD HH:mm:ss',
    );
    inputData.end_date = moment(inputData.end_date).format(
      'YYYY-MM-DD HH:mm:ss',
    );
    let response = await createEvent(inputData);

    if (response.status == 200 && response.success) {
      navigation.navigate('MyEvent');
    } else if (response.status == 422) {
      let error = {};
      response.error.forEach(response => {
        if (response.param == 'description') {
          error = {...error, description: response.msg};
        }
        if (response.param == 'title') {
          errorMessage.title = response.msg;
        }
        if (response.param == 'start_date') {
          errorMessage.start_date = response.msg;
        }
        if (response.param == 'end_date') {
          errorMessage.end_date = response.msg;
        }
        if (response.param == 'location') {
          errorMessage.location = response.msg;
        }
      });
      setInputError(error);
    }
    if (
      errorMessage.title != null ||
      errorMessage.start_date != null ||
      errorMessage.end_date != null ||
      errorMessage.location != null
    ) {
      navigation.navigate('CreateEventScreenOne', {
        title: errorMessage.title ?? null,
        start_date: errorMessage.start_date ?? null,
        end_date: errorMessage.end_date ?? null,
        location: errorMessage.location ?? null,
      });
    }
  };

  return (
    <View>
      <View style={styles.inputGroup}>
        <P style={styles.inputLabel}>Cover Photo</P>
        <View style={styles.wrapImage}>
          <TouchableOpacity
            onPress={() => {
              openImagePickerOptionModalize();
            }}>
            {inputData.cover_photo != null ? (
              <>
                <Image
                  source={{
                    uri: inputData.cover_photo.uri,
                  }}
                  style={styles.coverPhoto}
                />
              </>
            ) : (
              <>
                <View style={styles.coverPhoto}></View>
              </>
            )}
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.wrapEditIcon}
            onPress={() => {
              openImagePickerOptionModalize();
            }}>
            <Icon name="camera" style={styles.coverPhotoIcon} />
          </TouchableOpacity>
          <View></View>
        </View>
      </View>
      <View style={styles.inputGroup}>
        <P style={styles.inputLabel}>Description</P>
        <TextInput
          style={styles.inputBox}
          multiline={true}
          numberOfLines={5}
          placeholder="Description of your event..."
          onChangeText={text => {
            setInputData({...inputData, description: text});
          }}
        />
        {inputError.description ? (
          <ErrorMessage>{inputError.description}</ErrorMessage>
        ) : (
          <></>
        )}
      </View>

      <TouchableOpacity
        onPress={() => {
          submitCreateEvent();
        }}>
        <View style={styles.button}>
          <H5 style={styles.buttonText}>Create Event</H5>
        </View>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  inputGroup: {
    marginBottom: normalize(15),
  },
  inputLabel: {
    paddingBottom: normalize(10),
    marginLeft: normalize(10),
  },
  inputBox: {
    backgroundColor: '#ffffff',
    padding: normalize(10),
    fontSize: normalize(15),
    borderRadius: normalize(10),
    textAlignVertical: 'top',
    width: getScreenWidth() * 0.9,
    alignSelf: 'center',
  },
  button: {
    backgroundColor: '#0057FF',
    padding: normalize(10),
    marginVertical: normalize(30),
    borderRadius: normalize(10),
    width: getScreenWidth() * 0.9,
    alignSelf: 'center',
  },
  buttonText: {
    color: '#ffffff',
    textAlign: 'center',
  },
  groupImage: {
    width: normalize(100),
    height: normalize(100),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: normalize(200),
    backgroundColor: '#1E1B1B',
    borderColor: '#ffffff',
    borderWidth: normalize(2),
  },
  coverPhoto: {
    width: getScreenWidth() * 0.9,
    height: normalize(190),
    borderRadius: normalize(10),
    backgroundColor: '#1E1B1B',
    borderColor: '#ffffff',
    borderWidth: normalize(2),
  },
  wrapEditIcon: {
    position: 'absolute',
    borderRadius: normalize(10),
    width: normalize(24),
    height: normalize(24),
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
  },
  wrapGroupImageEditIcon: {
    position: 'absolute',
    borderRadius: normalize(10),
    width: normalize(24),
    height: normalize(24),
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
  },
  groupImageIcon: {
    fontSize: normalize(18),
    color: '#ffffff',
  },
  coverPhotoIcon: {
    fontSize: normalize(18),
    color: '#ffffff',
  },
  wrapImage: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalView: {
    margin: normalize(20),
    backgroundColor: '#ffffff',
    borderRadius: normalize(20),
    padding: normalize(35),
    alignItems: 'center',
    elevation: 5,
  },
  buttonClose: {
    backgroundColor: '#0057FF',
    borderRadius: normalize(20),
    padding: normalize(10),
    elevation: 2,
  },
  textStyle: {
    color: '#ffffff',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalText: {
    color: '#000000',
    marginBottom: normalize(15),
    textAlign: 'center',
  },
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: normalize(22),
  },
});
