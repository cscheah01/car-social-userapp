import React, {useState, useEffect} from 'react';
import {StyleSheet, View, TextInput, TouchableOpacity} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import {normalize} from '../../../utils/Helper';
import {H5, P, ErrorMessage} from '../../common/Typography';
import {Country} from 'country-state-city';
import SelectDropdown from 'react-native-select-dropdown';
import DatePicker from 'react-native-date-picker';
import moment from 'moment';

export default function CreateEventFormOne({responseError}) {
  const navigation = useNavigation();

  const [inputData, setInputData] = useState({
    title: null,
    start_date: null,
    end_date: null,
    location: null,
  });
  const [inputError, setInputError] = useState({
    title: null,
    start_date: null,
    end_date: null,
    location: null,
  });

  useEffect(() => {
    setInputError({...inputError, ...responseError});
  }, [responseError]);

  const [openStartDatePicker, setOpenStartDatePicker] = useState(false);
  const [openEndDatePicker, setOpenEndDatePicker] = useState(false);

  const nextStep = async () => {
    var error = {};
    if (inputData.title == null) {
      error = {...error, title: 'Event title is required.'};
    }
    if (inputData.start_date == null) {
      error = {...error, start_date: 'Start date is required.'};
    }
    if (inputData.end_date == null) {
      error = {...error, end_date: 'End date is required.'};
    }
    if (inputData.location == null) {
      error = {...error, location: 'Location is required.'};
    }

    setInputError(error);

    if (Object.keys(error).length === 0) {
      navigation.navigate('CreateEventScreenTwo', inputData);
    }
  };

  return (
    <View style={styles.wrapper}>
      <View style={styles.inputGroup}>
        <P style={styles.inputLabel}>Event Title</P>
        <TextInput
          style={styles.inputBox}
          placeholder="Event Title"
          onChangeText={text => {
            setInputData({...inputData, title: text});
            setInputError({...inputError, title: null});
          }}
        />
        {inputError.title ? (
          <ErrorMessage>{inputError.title}</ErrorMessage>
        ) : (
          <></>
        )}
      </View>

      <View style={styles.inputGroup}>
        <P style={styles.inputLabel}>Start Date</P>

        <View style={styles.labelRow}>
          <P style={styles.labelColumn}>Day</P>
          <P style={styles.labelColumn}>Month</P>
          <P style={styles.labelColumn}>Year</P>
          <P style={styles.labelColumn}>Time</P>
        </View>

        <TouchableOpacity onPress={() => setOpenStartDatePicker(true)}>
          {inputData.start_date != null ? (
            <View style={styles.selectedDisplayRow}>
              <P style={styles.selectedDisplayColumn}>
                {moment(inputData.start_date).format('DD')}
              </P>

              <P style={styles.selectedDisplayColumn}>
                {moment(inputData.start_date).format('MMMM')}
              </P>

              <P style={styles.selectedDisplayColumn}>
                {moment(inputData.start_date).format('YYYY')}
              </P>

              <P style={styles.selectedDisplayColumn}>
                {moment(inputData.start_date).format('h:mm a')}
              </P>
            </View>
          ) : (
            <View style={styles.dateButton}>
              <H5 style={styles.dateButtonText}>
                -- Please Select Start Date --
              </H5>
            </View>
          )}
        </TouchableOpacity>

        <DatePicker
          modal
          mode="datetime"
          minimumDate={new Date()}
          open={openStartDatePicker}
          date={inputData.start_date ?? new Date()}
          onConfirm={data => {
            setInputData({...inputData, start_date: data});
            setInputError({...inputError, start_date: null});
            setOpenStartDatePicker(false);
          }}
          onCancel={() => {
            setOpenStartDatePicker(false);
          }}
        />

        {inputError.start_date ? (
          <ErrorMessage>{inputError.start_date}</ErrorMessage>
        ) : (
          <></>
        )}
      </View>

      <View style={styles.inputGroup}>
        <P style={styles.inputLabel}>End Date</P>

        <View style={styles.labelRow}>
          <P style={styles.labelColumn}>Day</P>
          <P style={styles.labelColumn}>Month</P>
          <P style={styles.labelColumn}>Year</P>
          <P style={styles.labelColumn}>Time</P>
        </View>

        <TouchableOpacity onPress={() => setOpenEndDatePicker(true)}>
          {inputData.end_date != null ? (
            <View style={styles.selectedDisplayRow}>
              <P style={styles.selectedDisplayColumn}>
                {moment(inputData.end_date).format('DD')}
              </P>

              <P style={styles.selectedDisplayColumn}>
                {moment(inputData.end_date).format('MMMM')}
              </P>

              <P style={styles.selectedDisplayColumn}>
                {moment(inputData.end_date).format('YYYY')}
              </P>

              <P style={styles.selectedDisplayColumn}>
                {moment(inputData.end_date).format('h:mm a')}
              </P>
            </View>
          ) : (
            <View style={styles.dateButton}>
              <H5 style={styles.dateButtonText}>
                -- Please Select End Date --
              </H5>
            </View>
          )}
        </TouchableOpacity>

        <DatePicker
          modal
          mode="datetime"
          minimumDate={inputData.start_date}
          open={openEndDatePicker}
          date={inputData.end_date ?? new Date()}
          onConfirm={data => {
            setInputData({...inputData, end_date: data});
            setInputError({...inputError, end_date: null});
            setOpenEndDatePicker(false);
          }}
          onCancel={() => {
            setOpenEndDatePicker(false);
          }}
        />

        {inputError.end_date ? (
          <ErrorMessage>{inputError.end_date}</ErrorMessage>
        ) : (
          <></>
        )}
      </View>

      <View style={styles.inputGroup}>
        <P style={styles.inputLabel}>Location</P>
        <SelectDropdown
          defaultButtonText="Select a country"
          buttonStyle={styles.buttonStyle}
          dropdownStyle={styles.dropdownStyle}
          data={Country.getAllCountries()}
          onSelect={selectedItem => {
            setInputData({...inputData, location: selectedItem.isoCode});
            setInputError({...inputError, location: null});
          }}
          buttonTextAfterSelection={selectedItem => {
            return selectedItem.name;
          }}
          rowTextForSelection={item => {
            return item.name;
          }}
        />
        {inputError.location ? (
          <ErrorMessage>{inputError.location}</ErrorMessage>
        ) : (
          <></>
        )}
      </View>

      <TouchableOpacity
        onPress={() => {
          nextStep();
        }}>
        <View style={styles.button}>
          <H5 style={styles.buttonText}>Next</H5>
        </View>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    padding: normalize(10),
  },
  inputGroup: {
    marginTop: normalize(15),
  },
  inputLabel: {
    paddingBottom: normalize(10),
  },
  inputBox: {
    backgroundColor: '#ffffff',
    padding: normalize(10),
    fontSize: normalize(15),
    borderRadius: normalize(10),
  },
  dropdownStyle: {
    borderRadius: normalize(10),
  },
  buttonStyle: {
    width: '100%',
    backgroundColor: '#ffffff',
    padding: normalize(10),
    fontSize: normalize(15),
    borderRadius: normalize(10),
  },
  button: {
    backgroundColor: '#0057FF',
    padding: normalize(10),
    marginVertical: normalize(30),
    borderRadius: normalize(10),
  },
  buttonText: {
    color: '#ffffff',
    textAlign: 'center',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  icon: {
    fontSize: normalize(25),
    color: '#ffffff',
  },
  labelRow: {
    flexDirection: 'row',
    marginBottom: normalize(10),
  },
  labelColumn: {
    color: '#D3D3D3',
    width: '25%',
    textAlign: 'center',
  },
  selectedDisplayRow: {
    flexDirection: 'row',
    alignItems: 'center',
    color: '#000000',
    backgroundColor: '#ffffff',
    borderRadius: normalize(10),
    padding: normalize(10),
  },
  selectedDisplayColumn: {
    textAlign: 'center',
    color: '#000000',
    fontSize: normalize(15),
    width: '25%',
  },
  dateButtonText: {
    color: '#808080',
    fontSize: normalize(15),
    paddingVertical: normalize(4),
    textAlign: 'center',
  },
  dateButton: {
    backgroundColor: '#ffffff',
    padding: normalize(10),
    borderRadius: normalize(10),
  },
});
