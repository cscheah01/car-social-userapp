import React from 'react';
import {StyleSheet, View, TouchableOpacity} from 'react-native';
import {normalize} from '../../../utils/Helper';
import {useNavigation} from '@react-navigation/native';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {H4} from '../../common/Typography';

export default function () {
  const navigation = useNavigation();

  return (
    <View style={styles.wrapper}>
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <View style={(styles.flexRow, styles.backButton)}>
          <Icon name="arrow-left" style={styles.icon} />
        </View>
      </TouchableOpacity>
      <View style={styles.headerLabel}>
        <H4>Event</H4>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#000000',
    padding: normalize(10),
    borderBottomColor: '#ffffff',
    borderBottomWidth: normalize(3),
  },
  backButton: {
    marginRight: normalize(20),
  },
  rightSection: {
    flex: 1,
    alignItems: 'flex-end',
  },
  flexRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  rightSectionItem: {
    marginLeft: normalize(18),
  },
  icon: {
    fontSize: normalize(18),
    color: '#ffffff',
  },
  headerLabel: {
    position: 'absolute',
    left: '46%',
  },
});
