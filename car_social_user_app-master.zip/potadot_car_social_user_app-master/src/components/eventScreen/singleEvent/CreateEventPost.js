import React from 'react';
import {StyleSheet, View, Image} from 'react-native';
import {TouchableOpacity} from 'react-native-gesture-handler';
import {normalize} from '../../../utils/Helper';
import {P} from '../../common/Typography';

const profilePicture =
  'https://img.favpng.com/25/13/19/samsung-galaxy-a8-a8-user-login-telephone-avatar-png-favpng-dqKEPfX7hPbc6SMVUCteANKwj.jpg';

export default function () {
  return (
    <View style={styles.wrapper}>
      <View style={styles.profileSection}>
        <TouchableOpacity>
          <Image
            source={{uri: profilePicture}}
            style={styles.userProfileImage}
          />
        </TouchableOpacity>
      </View>
      <View style={styles.contentSection}>
        <TouchableOpacity style={styles.createPostBox}>
          <P>Write a post...</P>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    flexDirection: 'row',
    backgroundColor: '#000000',
    padding: normalize(10),
  },
  profileSection: {
    width: '12%',
    justifyContent: 'center',
  },
  contentSection: {
    width: '88%',
  },
  userProfileImage: {
    height: normalize(30),
    width: normalize(30),
    borderRadius: normalize(30) / 2,
  },
  createPostBox: {
    backgroundColor: '#1f1f1f',
    padding: normalize(10),
    borderRadius: normalize(10),
  },
});
