import React, {useState, useCallback} from 'react';
import {StyleSheet, View, Image, TouchableWithoutFeedback} from 'react-native';
import {
  normalize,
  getScreenWidth,
  totalCountFormatter,
} from '../../../utils/Helper';
import AntDesignIcon from 'react-native-vector-icons/AntDesign';
import {P, H3, H5} from '../../common/Typography';
import {useNavigation} from '@react-navigation/native';
import moment from 'moment';
import {Country} from 'country-state-city';
import Ionicons from 'react-native-vector-icons/Ionicons';
import FeatherIcon from 'react-native-vector-icons/Feather';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {TouchableOpacity} from 'react-native-gesture-handler';

export default function Group({data}) {
  const startTime = data.start_date;
  const endTime = data.end_date;

  let location = Country.getCountryByCode(data.location);
  const [showSeeMore, setShowSeeMore] = useState(false);
  const [showAllContent, setShowAllContent] = useState(false);
  const onTextLayout = useCallback(e => {
    setShowSeeMore(e.nativeEvent.lines.length >= 4);
  }, []);
  const navigation = useNavigation();

  return (
    <View key={data.id} style={styles.wrapper}>
      {data.cover_image != null ? (
        <>
          <Image
            source={{uri: data.cover_image}}
            style={styles.coverImage}></Image>
        </>
      ) : (
        <>
          <View style={styles.coverImage}></View>
        </>
      )}
      <View style={styles.wrapDetails}>
        <H3 style={styles.blackText}>{data.title}</H3>

        <View style={styles.flexRow}>
          <MaterialCommunityIcons name="timer" style={styles.antDesignIcon} />
          <P style={styles.duration}>
            {moment(data.start_date).format('LLLL')}
          </P>
        </View>
        <View style={styles.flexRow}>
          <MaterialCommunityIcons
            name="timer-off"
            style={styles.antDesignIcon}
          />
          <P style={styles.duration}>{moment(data.end_date).format('LLLL')}</P>
        </View>
        <View style={styles.flexRow}>
          <Ionicons name="location-outline" style={styles.ionicons} />
          <P style={styles.blackText}>{location.name}</P>
        </View>
        <TouchableWithoutFeedback
          onPress={() => setShowAllContent(!showAllContent)}>
          <View style={styles.flexRowDescription}>
            <FeatherIcon name="edit-3" style={styles.editIcon} />
            <P
              style={styles.description}
              onTextLayout={onTextLayout}
              numberOfLines={showAllContent ? undefined : 2}>
              {data.description}
            </P>
          </View>
        </TouchableWithoutFeedback>
        <View style={styles.wrapRow}>
          <View style={styles.leftColumn}>
            <View style={styles.flexRow}>
              <AntDesignIcon name="user" style={styles.antDesignIcon} />
              <P style={styles.blackText}>Event By {data.event_by}</P>
            </View>
          </View>
          <View style={styles.rightColumn}>
            <TouchableOpacity>
              <View style={styles.flexRow}>
                <P style={styles.blackText}>
                  {totalCountFormatter(data.total_member)} Members
                </P>
                <FeatherIcon name="chevron-right" style={styles.featherIcon} />
              </View>
            </TouchableOpacity>
          </View>
        </View>
        <View style={styles.buttonWrapper}>
          <TouchableOpacity style={styles.button}>
            <View style={styles.buttonBlue}>
              <H5 style={styles.buttonText}>Invite</H5>
            </View>
          </TouchableOpacity>
          {data.is_admin == null ? (
            <TouchableOpacity style={styles.button}>
              <View style={styles.buttonBlue}>
                <H5 style={styles.buttonText}>Join</H5>
              </View>
            </TouchableOpacity>
          ) : data.is_admin == false ? (
            <TouchableOpacity style={styles.button}>
              <View style={styles.buttonJoined}>
                <H5 style={styles.buttonText}>Joined</H5>
              </View>
            </TouchableOpacity>
          ) : (
            <>
              <TouchableOpacity
                style={styles.button}
                onPress={() => {
                  navigation.navigate('Manage', {
                    eventName: data.name,
                    eventId: data.id,
                  });
                }}>
                <View style={styles.buttonBlue}>
                  <H5 style={styles.buttonText}>Manage</H5>
                </View>
              </TouchableOpacity>
            </>
          )}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    marginBottom: normalize(10),
  },
  coverImage: {
    width: getScreenWidth(),
    height: normalize(200),
    resizeMode: 'cover',
  },
  buttonWrapper: {
    marginTop: normalize(5),
    flexDirection: 'row',
    justifyContent: 'center',
  },
  buttonBlue: {
    backgroundColor: '#0057FF',
    borderRadius: normalize(10),
    paddingVertical: normalize(10),
    paddingHorizontal: normalize(30),
  },
  buttonJoined: {
    backgroundColor: '#192563',
    borderRadius: normalize(10),
    padding: normalize(10),
  },
  buttonText: {
    textAlign: 'center',
  },
  button: {
    marginRight: normalize(10),
  },
  date: {
    color: '#000000',
    textTransform: 'uppercase',
  },
  wrapDetails: {
    marginTop: normalize(-60),
    width: '95%',
    backgroundColor: '#ffffff',
    padding: normalize(10),
    borderRadius: normalize(10),
    alignSelf: 'center',
  },
  flexRow: {
    flexDirection: 'row',
    marginVertical: normalize(10),
    alignItems: 'center',
  },
  flexRowDescription: {
    flexDirection: 'row',
    marginVertical: normalize(5),
    alignItems: 'center',
  },
  rightColumn: {
    width: '43%',
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  leftColumn: {
    width: '47%',
  },
  wrapRow: {
    marginTop: normalize(10),
    flexDirection: 'row',
    width: getScreenWidth(),
  },
  duration: {
    color: '#000000',
    marginLeft: normalize(5),
    marginRight: normalize(5),
  },
  description: {
    width: '90%',
    color: '#000000',
    textAlign: 'justify',
  },
  textBold: {
    fontWeight: 'bold',
  },
  ionicons: {
    fontSize: normalize(22),
    color: '#000000',
    marginRight: normalize(6),
  },
  antDesignIcon: {
    color: '#000000',
    fontSize: normalize(22),
    marginRight: normalize(5),
  },
  featherIcon: {
    color: '#000000',
    alignSelf: 'center',
    fontSize: normalize(18),
  },
  editIcon: {
    color: '#000000',
    fontSize: normalize(22),
    marginRight: normalize(5),
    marginTop: normalize(5),
  },
  blackText: {
    color: '#000000',
  },
});
