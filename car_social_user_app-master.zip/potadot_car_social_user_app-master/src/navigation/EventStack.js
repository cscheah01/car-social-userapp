import * as React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import {getFocusedRouteNameFromRoute} from '@react-navigation/native';
import {createMaterialTopTabNavigator} from '@react-navigation/material-top-tabs';
import MyEvent from '../screens/event/MyEvent';
import NearMe from '../screens/event/NearMe';
import {normalize} from '../utils/Helper';
import CreateEventScreenOne from '../screens/event/CreateEventScreenOne';
import CreateEventScreenTwo from '../screens/event/CreateEventScreenTwo';
import SingleEvent from '../screens/event/SingleEvent';

const Stack = createStackNavigator();
const Tab = createMaterialTopTabNavigator();

function HomeStack() {
  return (
    <Tab.Navigator
      initialRouteName="MyEvent"
      screenOptions={{
        tabBarLabelStyle: {
          color: '#ffffff',
          fontSize: normalize(12),
          textTransform: 'none',
        },
        tabBarStyle: {
          backgroundColor: '#000000',
        },
        tabBarIndicatorStyle: {
          backgroundColor: '#ffffff',
        },
      }}>
      <Tab.Screen
        name="MyEvent"
        component={MyEvent}
        options={{
          tabBarLabel: 'My Event',
        }}
      />
      <Tab.Screen
        name="NearMe"
        component={NearMe}
        options={{
          tabBarLabel: 'Near Me',
        }}
      />
      <Tab.Screen
        name="CreateEvent"
        component={CreateEventStack}
        options={{
          tabBarLabel: 'Create Event',
        }}
      />
    </Tab.Navigator>
  );
}

function CreateEventStack() {
  return (
    <Stack.Navigator initialRouteName="CreateEventScreenOne">
      <Stack.Screen
        name="CreateEventScreenOne"
        component={CreateEventScreenOne}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="CreateEventScreenTwo"
        component={CreateEventScreenTwo}
        options={{
          headerShown: false,
        }}
      />
    </Stack.Navigator>
  );
}
export default function EventStack({navigation, route}) {
  const tabHiddenRoutes = [];

  if (tabHiddenRoutes.includes(getFocusedRouteNameFromRoute(route))) {
    navigation.setOptions({tabBarStyle: {display: 'none'}});
  } else {
    navigation.setOptions({tabBarStyle: {display: 'flex'}});
  }

  return (
    <Stack.Navigator initialRouteName="Home">
      <Stack.Screen
        name="Home"
        component={HomeStack}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="SingleEvent"
        component={SingleEvent}
        options={{
          headerShown: false,
        }}
      />
    </Stack.Navigator>
  );
}
