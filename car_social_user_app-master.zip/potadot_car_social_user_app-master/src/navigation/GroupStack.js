import * as React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import {getFocusedRouteNameFromRoute} from '@react-navigation/native';
import {createMaterialTopTabNavigator} from '@react-navigation/material-top-tabs';
import NearMe from '../screens/group/NearMe';
import MyGroup from '../screens/group/MyGroup';
import InviteMember from '../screens/group/InviteMember';
import CreateGroupScreenOne from '../screens/group/CreateGroupScreenOne';
import CreateGroupScreenTwo from '../screens/group/CreateGroupScreenTwo';
import SingleGroup from '../screens/group/SingleGroup';
import {normalize} from '../utils/Helper';
import InviteMemberHeader from '../components/groupScreen/inviteMember/Header';
import Manage from '../screens/group/Manage';
import MemberRequest from '../screens/group/MemberRequest';
import GroupSetting from '../screens/group/GroupSetting';
import EditName from '../screens/group/EditName';
import EditDescription from '../screens/group/EditDescription';
import EditCountry from '../screens/group/EditCountry';
import EditPrivacy from '../screens/group/EditPrivacy';

const Stack = createStackNavigator();
const Tab = createMaterialTopTabNavigator();

function HomeTab() {
  return (
    <Tab.Navigator
      initialRouteName="NearMe"
      screenOptions={{
        tabBarLabelStyle: {
          color: '#ffffff',
          fontSize: normalize(12),
          textTransform: 'none',
        },
        tabBarStyle: {
          backgroundColor: '#000000',
        },
        tabBarIndicatorStyle: {
          backgroundColor: '#ffffff',
        },
      }}>
      <Tab.Screen
        name="MyGroup"
        component={MyGroup}
        options={{
          tabBarLabel: 'My Group',
        }}
      />
      <Tab.Screen
        name="NearMe"
        component={NearMe}
        options={{
          tabBarLabel: 'Near Me',
        }}
      />
      <Tab.Screen
        name="CreateGroup"
        component={CreateGroupStack}
        options={{
          tabBarLabel: 'Create Group',
        }}
      />
    </Tab.Navigator>
  );
}

function CreateGroupStack() {
  return (
    <Stack.Navigator initialRouteName="CreateGroupScreenOne">
      <Stack.Screen
        name="CreateGroupScreenOne"
        component={CreateGroupScreenOne}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="CreateGroupScreenTwo"
        component={CreateGroupScreenTwo}
        options={{
          headerShown: false,
        }}
      />
    </Stack.Navigator>
  );
}

export default function GroupStack({navigation, route}) {
  const tabHiddenRoutes = ['CreateGroupScreenTwo'];

  if (tabHiddenRoutes.includes(getFocusedRouteNameFromRoute(route))) {
    navigation.setOptions({tabBarStyle: {display: 'none'}});
  } else {
    navigation.setOptions({tabBarStyle: {display: 'flex'}});
  }

  return (
    <Stack.Navigator initialRouteName="Home">
      <Stack.Screen
        name="Home"
        component={HomeTab}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="SingleGroup"
        component={SingleGroup}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="InviteMember"
        component={InviteMember}
        options={{header: InviteMemberHeader}}
      />
      <Stack.Screen
        name="Manage"
        component={Manage}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="MemberRequest"
        component={MemberRequest}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="GroupSetting"
        component={GroupSetting}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="EditName"
        component={EditName}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="EditDescription"
        component={EditDescription}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="EditCountry"
        component={EditCountry}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="EditPrivacy"
        component={EditPrivacy}
        options={{
          headerShown: false,
        }}
      />
    </Stack.Navigator>
  );
}
