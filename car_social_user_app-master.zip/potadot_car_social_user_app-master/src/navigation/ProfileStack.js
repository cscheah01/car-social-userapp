import * as React from 'react';
import Home from '../screens/profile/Home';
import Follower from '../screens/profile/Follower';
import Following from '../screens/profile/Following';
import {createStackNavigator} from '@react-navigation/stack';
import {getFocusedRouteNameFromRoute} from '@react-navigation/native';
import {createMaterialTopTabNavigator} from '@react-navigation/material-top-tabs';
import FollowingAndFollowerHeader from '../components/profileScreen/followerAndFollowing/Header';
import ProfileDetailsHeader from '../components/profileScreen/details/Header';
import Details from '../screens/profile/Details';
import {normalize} from '../utils/Helper';
import {Tabs, MaterialTabBar} from 'react-native-collapsible-tab-view';
import Garages from '../screens/profile/Garages';
import Posts from '../screens/profile/Posts';
import AddVehicleScreenOne from '../screens/profile/AddVehicleScreenOne';
import AddVehicleScreenTwo from '../screens/profile/AddVehicleScreenTwo';
import AddVehicleHeader from '../components/profileScreen/garages/Header';
import EditUsername from '../screens/profile/EditUsername';
import EditPhoneNumber from '../screens/profile/EditPhoneNumber';
import EditDateOfBirth from '../screens/profile/EditBirthday';
import EditBio from '../screens/profile/EditBio';

const Stack = createStackNavigator();
const Tab = createMaterialTopTabNavigator();

function FollowerAndFollowingStack() {
  return (
    <Tab.Navigator
      initialRouteName="Following"
      screenOptions={{
        tabBarLabelStyle: {
          color: '#ffffff',
          fontSize: normalize(12),
          textTransform: 'none',
        },
        tabBarStyle: {
          backgroundColor: '#000000',
        },
        tabBarIndicatorStyle: {
          backgroundColor: '#ffffff',
        },
      }}>
      <Tab.Screen
        name="Following"
        component={Following}
        options={{
          tabBarLabel: 'Following',
        }}
      />
      <Tab.Screen
        name="Follower"
        component={Follower}
        options={{
          tabBarLabel: 'Follower',
        }}
      />
    </Tab.Navigator>
  );
}

const tabBar = props => (
  <MaterialTabBar
    {...props}
    indicatorStyle={{backgroundColor: '#ffffff'}}
    style={{backgroundColor: '#000000'}}
    labelStyle={{
      fontWeight: 'bold',
      textTransform: 'capitalize',
      fontSize: normalize(14),
    }}
    activeColor="#ffffff"
    inactiveColor="#ffffff"
  />
);

export function GaragesAndPostsTab() {
  return (
    <Tabs.Container revealHeaderOnScroll renderTabBar={tabBar}>
      <Tabs.Tab name="Garages">
        <Garages />
      </Tabs.Tab>
      <Tabs.Tab name="Posts">
        <Posts />
      </Tabs.Tab>
    </Tabs.Container>
  );
}

function AddVehicle() {
  return (
    <Stack.Navigator initialRouteName="AddVehicleScreenOne">
      <Stack.Screen
        name="AddVehicleScreenOne"
        component={AddVehicleScreenOne}
        options={{header: AddVehicleHeader}}
      />
      <Stack.Screen
        name="AddVehicleScreenTwo"
        component={AddVehicleScreenTwo}
        options={{header: AddVehicleHeader}}
      />
    </Stack.Navigator>
  );
}

function Profile() {
  return (
    <Stack.Navigator initialRouteName="Details">
      <Stack.Screen
        name="Details"
        component={Details}
        options={{header: ProfileDetailsHeader}}
      />
      <Stack.Screen
        name="EditUsername"
        component={EditUsername}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="EditPhoneNumber"
        component={EditPhoneNumber}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="EditDateOfBirth"
        component={EditDateOfBirth}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="EditBio"
        component={EditBio}
        options={{
          headerShown: false,
        }}
      />
    </Stack.Navigator>
  );
}

export default function ProfileStack({navigation, route}) {
  const tabHiddenRoutes = ['FollowerAndFollowing', 'Details'];

  if (tabHiddenRoutes.includes(getFocusedRouteNameFromRoute(route))) {
    navigation.setOptions({tabBarStyle: {display: 'none'}});
  } else {
    navigation.setOptions({tabBarStyle: {display: 'flex'}});
  }
  return (
    <Stack.Navigator initialRouteName="Home">
      <Stack.Screen
        name="Home"
        component={Home}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="FollowerAndFollowing"
        component={FollowerAndFollowingStack}
        options={{header: FollowingAndFollowerHeader}}
      />
      <Stack.Screen
        name="Details"
        component={Profile}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="AddVehicle"
        component={AddVehicle}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="EditBio"
        component={EditBio}
        options={{
          headerShown: false,
        }}
      />
    </Stack.Navigator>
  );
}
