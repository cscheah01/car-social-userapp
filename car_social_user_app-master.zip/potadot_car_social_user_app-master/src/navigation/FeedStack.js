import React from 'react';
import {StyleSheet} from 'react-native';
import {createStackNavigator} from '@react-navigation/stack';
import {createMaterialTopTabNavigator} from '@react-navigation/material-top-tabs';
import {getFocusedRouteNameFromRoute} from '@react-navigation/native';
import Home from '../screens/feed/Home';
import Follow from '../screens/feed/Follow';
import SinglePost from '../screens/feed/SinglePost';
import CreatePost from '../screens/feed/CreatePost';
import ChatList from '../screens/chat/ChatList';
import ChatRoom from '../screens/chat/ChatRoom';
import HomeHeader from '../components/feedScreen/home/HomeHeader';
import SinglePostHeader from '../components/feedScreen/singlePost/SinglePostHeader';
import {normalize} from '../utils/Helper';
import SearchUser from '../screens/chat/SearchUser';

const Stack = createStackNavigator();
const Tab = createMaterialTopTabNavigator();

function ChatStack() {
  return (
    <Stack.Navigator initialRouteName="ChatList">
      <Stack.Screen
        name="ChatList"
        component={ChatList}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="ChatRoom"
        component={ChatRoom}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="SearchUser"
        component={SearchUser}
        options={{
          headerShown: false,
        }}
      />
    </Stack.Navigator>
  );
}

function HomeTab() {
  return (
    <Tab.Navigator
      style={styles.tabNavigator}
      initialRouteName="Explore"
      screenOptions={{
        tabBarLabelStyle: {
          color: '#ffffff',
          fontSize: normalize(12),
          textTransform: 'none',
          fontWeight: 'bold',
          padding: normalize(0),
        },
        tabBarStyle: {
          backgroundColor: '#000000',
          width: '40%',
        },
        tabBarIndicatorStyle: {
          backgroundColor: '#ffffff',
        },
      }}>
      <Tab.Screen
        name="Explore"
        component={Home}
        options={{
          tabBarLabel: 'Explore',
        }}
      />
      <Tab.Screen
        name="Follow"
        component={Follow}
        options={{
          tabBarLabel: 'Follow',
        }}
      />
    </Tab.Navigator>
  );
}

export default function FeedStack({navigation, route}) {
  const tabHiddenRoutes = ['SinglePost', 'CreatePost', 'Chat'];

  if (tabHiddenRoutes.includes(getFocusedRouteNameFromRoute(route))) {
    navigation.setOptions({tabBarStyle: {display: 'none'}});
  } else {
    navigation.setOptions({tabBarStyle: {display: 'flex'}});
  }

  return (
    <Stack.Navigator initialRouteName="Home">
      <Stack.Screen
        name="Home"
        component={HomeTab}
        options={{header: HomeHeader}}
      />
      <Stack.Screen
        name="SinglePost"
        component={SinglePost}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="CreatePost"
        component={CreatePost}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="Chat"
        component={ChatStack}
        options={{headerShown: false}}
      />
    </Stack.Navigator>
  );
}

const styles = StyleSheet.create({
  tabNavigator: {
    backgroundColor: '#000000',
  },
});
