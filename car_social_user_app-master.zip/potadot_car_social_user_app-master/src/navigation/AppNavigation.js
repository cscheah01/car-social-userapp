import React from 'react';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import FeedStack from './FeedStack';
import GroupStack from './GroupStack';
import ProfileStack from './ProfileStack';
import EventStack from './EventStack';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import FontAwesome from 'react-native-vector-icons/FontAwesome';

const BottomTab = createBottomTabNavigator();
export default function AppNavigation() {
  return (
    <BottomTab.Navigator
      initialRouteName="FeedStack"
      screenOptions={{
        tabBarShowLabel: false,
        tabBarLabelPosition: 'below-icon',
      }}>
      <BottomTab.Screen
        name="FeedStack"
        component={FeedStack}
        options={{
          headerShown: false,
          tabBarIcon: () => (
            <FontAwesome5 name="home" size={25} color={'#000000'} />
          ),
        }}
      />
      <BottomTab.Screen
        name="GroupStack"
        component={GroupStack}
        options={{
          headerShown: false,
          tabBarIcon: () => (
            <FontAwesome5 name="users" size={25} color={'#000000'} />
          ),
        }}
      />
      <BottomTab.Screen
        name="EventStack"
        component={EventStack}
        options={{
          headerShown: false,
          tabBarIcon: () => (
            <FontAwesome name="flag" size={25} color={'#000000'} />
          ),
        }}
      />
      <BottomTab.Screen
        name="ProfileStack"
        component={ProfileStack}
        options={{
          headerShown: false,
          tabBarIcon: () => (
            <FontAwesome5 name="bars" size={25} color={'#000000'} />
          ),
        }}
      />
    </BottomTab.Navigator>
  );
}
