import {Dimensions, Platform, PixelRatio} from 'react-native';

const {width: SCREEN_WIDTH, height: SCREEN_HEIGHT} = Dimensions.get('window');

const scale = SCREEN_WIDTH / 320;

export function normalize(size) {
  const newSize = size * scale;
  if (Platform.OS === 'ios') {
    return Math.round(PixelRatio.roundToNearestPixel(newSize));
  } else {
    return Math.round(PixelRatio.roundToNearestPixel(newSize)) - 2;
  }
}

export function getScreenWidth() {
  return SCREEN_WIDTH;
}

export function getScreenHeight() {
  return SCREEN_HEIGHT;
}

export function totalCountFormatter(total) {
  const lookup = [
    {value: 1, symbol: ''},
    {value: 1e3, symbol: 'k'},
    {value: 1e6, symbol: 'M'},
  ];

  let result = lookup
    .slice()
    .reverse()
    .find(function (item) {
      return total >= item.value;
    });

  return result
    ? Number((total / result.value).toString().match(/^\d+(?:\.\d{0,1})?/)) +
        result.symbol
    : '0';
}
