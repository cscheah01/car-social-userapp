import React, {useReducer, useEffect, useMemo} from 'react';
import 'react-native-gesture-handler';
import EncryptedStorage from 'react-native-encrypted-storage';
import {SafeAreaProvider} from 'react-native-safe-area-context';
import {AuthContext} from './src/contexts/AuthContext';
import {NavigationContainer} from '@react-navigation/native';
import AppNavigation from './src/navigation/AppNavigation';
import AuthNavigation from './src/navigation/AuthNavigation';
import {StatusBar} from 'react-native';
import {PortalProvider} from '@gorhom/portal';

export default function App() {
  const [state, dispatch] = useReducer(
    (prevState, action) => {
      switch (action.type) {
        case 'RESTORE_TOKEN':
          return {
            ...prevState,
            userToken: action.token,
            isLoading: false,
          };
        case 'SIGN_IN':
          return {
            ...prevState,
            isSignout: false,
            userToken: action.token,
          };
        case 'SIGN_OUT':
          return {
            ...prevState,
            isSignout: true,
            userToken: null,
          };
      }
    },
    {
      isLoading: true,
      isSignout: false,
      userToken: null,
    },
  );

  useEffect(() => {
    const bootstrapAsync = async () => {
      let userToken;

      try {
        userToken = await EncryptedStorage.getItem('userToken');
      } catch (e) {
        // Restoring token failed
      }

      // After restoring token, we may need to validate it in production apps

      // This will switch to the App screen or Auth screen and this loading
      // screen will be unmounted and thrown away.
      dispatch({type: 'RESTORE_TOKEN', token: userToken});
    };

    bootstrapAsync();
  }, []);

  const authContext = useMemo(
    () => ({
      handleLogin: async (token, userId) => {
        await EncryptedStorage.setItem('userToken', token);
        await EncryptedStorage.setItem('userId', '' + userId);
        dispatch({type: 'SIGN_IN', token: token});
      },
      handleLogout: async () => {
        await EncryptedStorage.removeItem('userToken');
        dispatch({type: 'SIGN_OUT'});
      },
      handleSignup: async (token, userId) => {
        await EncryptedStorage.setItem('userToken', token);
        await EncryptedStorage.setItem('userId', '' + userId);
        dispatch({type: 'SIGN_IN', token: token});
      },
    }),
    [],
  );

  return (
    <AuthContext.Provider value={authContext}>
      <SafeAreaProvider>
        <StatusBar backgroundColor="#000000" />
        <PortalProvider>
          <NavigationContainer>
            {state.userToken == null ? <AuthNavigation /> : <AppNavigation />}
          </NavigationContainer>
        </PortalProvider>
      </SafeAreaProvider>
    </AuthContext.Provider>
  );
}
